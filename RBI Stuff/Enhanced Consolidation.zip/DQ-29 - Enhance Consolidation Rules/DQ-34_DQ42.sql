select c.contactid, c.ConsolidationID, c2.ConsolidationID,
 c.EmailAddress, c.title, c.FirstName, c.LastName, c.MATCHED_CONTACT_ID, c.DUPE_REASON, c2.EmailAddress, c2.FirstName, c2.LastName
 from Consolidated_Staging.db.Contact c
 inner join Consolidated_Staging.db.contact c2
 on c2.contactid = c.MATCHED_CONTACT_ID
 where c.MATCHED_CONTACT_ID = 194610

 select c.contactid, c.EmailAddress, c.title, c.FirstName, c.LastName, c.MATCHED_CONTACT_ID, c.DUPE_REASON
 from Consolidated_Staging.db.Contact c
 left join Consolidated_Staging.db.contact c2
 on c2.contactid = c.MATCHED_CONTACT_ID
 where c2.ContactID is null
 and c.MATCHED_CONTACT_ID is not null


 -- different ConsolidationID

select c.contactid, c.ConsolidationID, c2.ConsolidationID,
c.EmailAddress, c.title, c.FirstName, c.LastName, c.MATCHED_CONTACT_ID, c.DUPE_REASON, c2.EmailAddress, c2.FirstName, c2.LastName
from Consolidated_Staging.db.Contact c
inner join Consolidated_Staging.db.contact c2
on c2.contactid = c.MATCHED_CONTACT_ID
where c.ConsolidationID <> c2.ConsolidationID


select *
from Consolidated_Staging.db.Contact
where MATCHED_CONTACT_ID = 194610

select *
from Consolidated_Staging.db.contact where contactid = 194610

-- contact records within consolidationID that have different matched_contact_id

select ConsolidationID,count(distinct MATCHED_CONTACT_ID)
from Consolidated_Staging.db.contact
where MATCHED_CONTACT_ID is not null
group by ConsolidationID
having count(distinct MATCHED_CONTACT_ID) > 1
order by 2 desc

select contactid, title, FirstName, LastName, MATCHED_CONTACT_ID, EmailAddress,DUPE_REASON
from Consolidated_Staging.db.contact
where ConsolidationID = '108601'
order by 5
-- contact records that have potentially been over-matched

select *
from 