use base


CREATE NONCLUSTERED INDEX x_ContactConsolidatedIDs
ON [DB].[ContactConsolidatedIDs] ([EmailAddress],[ConsolidationGroupID])

CREATE NONCLUSTERED INDEX x_ContactConsolidatedIDs2
ON [DB].[ContactConsolidatedIDs] ([ConsolidationGroupID])
INCLUDE ([Source],[MarketCode],[SourceContactID],[CreateDate],[LastUpdateDate],[FirstName],[LastName],[EmailAddress],[ContactAddress1],[ContactPostCode],[Telephone])


go

IF EXISTS (select 1 FROM INFORMATION_SCHEMA.Columns WHERE TABLE_name = 'ContactConsolidatedIDs' and column_name = 'SourceCreateDate')
ALTER TABLE DB.ContactConsolidatedIDs DROP COLUMN SourceCreateDate

ALTER TABLE DB.ContactConsolidatedIDs add SourceCreateDate datetime

IF EXISTS (select 1 FROM INFORMATION_SCHEMA.Columns WHERE TABLE_name = 'ContactConsolidatedIDs' and column_name = 'SourceLastUpdateDate')
ALTER TABLE db.ContactConsolidatedIDs DROP COLUMN SourceLastUpdateDate

ALTER TABLE DB.ContactConsolidatedIDs add SourceLastUpdateDate datetime

use Consolidated

IF EXISTS (select 1 FROM INFORMATION_SCHEMA.Columns WHERE TABLE_name = 'Contact' and column_name = 'ParentContactID')
ALTER TABLE DB.Contact DROP COLUMN ParentContactID

ALTER TABLE DB.Contact ADD ParentContactID INT

use Consolidated_Staging


IF EXISTS (select 1 FROM INFORMATION_SCHEMA.Columns WHERE TABLE_name = 'Contact' and column_name = 'IgnoreBeyondContactMatching')
ALTER TABLE db.Contact DROP COLUMN IgnoreBeyondContactMatching

ALTER TABLE DB.Contact add IgnoreBeyondContactMatching int

IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME='ContactIgnoreBeyondContactMatching')
DROP TABLE db.ContactIgnoreBeyondContactMatching

CREATE TABLE [DB].ContactIgnoreBeyondContactMatching(
	[Source] [nvarchar](100) NULL,
	SourceContactID [nvarchar] (50) NULL,
	[MarketCode] [nvarchar] (50) NULL,
	C_ContactID int)

IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME='Contact')
DROP TABLE db.Contact

CREATE TABLE [DB].[Contact](
	[ContactID] [int] identity(1,1) NOT NULL,
	[Source] [nvarchar](100) NULL,
	[SourceID] [int] NULL,
	[MarketCode] [nvarchar](3) NULL,
	[MarketID] [int] NULL,
	[SourceContactID] [nvarchar](50) NULL,
	[EmailAddress] [nvarchar](255) NULL,
	[CompanyName] [nvarchar](200) NULL,
	[ContactAddress1] [nvarchar](255) NULL,
	[ContactAddress2] [nvarchar](130) NULL,
	[ContactAddress3] [nvarchar](130) NULL,
	[ContactAddress4] [nvarchar](130) NULL,
	[ContactTown] [nvarchar](130) NULL,
	[ContactCounty] [nvarchar](130) NULL,
	[ContactPostCode] [nvarchar](130) NULL,
	[ContactCountryCode] [nvarchar](10) NULL,
	[ContactCountryName] [nvarchar](130) NULL,
	[Salutation] [nvarchar](10) NULL,
	[FirstName] [nvarchar](255) NULL,
	[LastName] [nvarchar](255) NULL,
	[Telephone] [nvarchar](128) NULL,
	[JobTitle] [nvarchar](500) NULL,
	[CreateDate] [datetime] NULL,
	[LastUpdateDate] [datetime] NULL,
	[Password] [nvarchar](128) NULL,
	[ValidEmailAddress] [nvarchar](5) NULL,
	[HTMLCapable] [nvarchar](5) NULL,
	[SoftBounceCount] [int] NULL,
	[HardBounceCount] [int] NULL,
	[LastBounced] [datetime] NULL,
	[MobileNumber] [nvarchar](50) NULL,
	[UserName] [nvarchar](255) NULL,
	[GroupName] [nvarchar](255) NULL,
	[Title] [nvarchar](100) NULL,
	[C_ContactAddressID] [int] NULL,
	[C_SourceEmailID] [int] NULL,
	[C_PreviousContactID] [int] NULL,
	[C_ContactID] [int] NULL,
	[C_ContactUsernameID] [int] NULL,
	[ConsolidationID] [varchar](20) NULL,
	[C_AddressID] [int] NULL,
	[C_ContactCompanyID] [int] NULL,
	[GreatestDate] [datetime] NULL,
	[AddressType] [nvarchar](100) NULL,
	[CompletnessID] [int] NULL,
	[SMSMobile] [nvarchar](50) NULL,
	[Fax] [nvarchar](128) NULL,
	[C_ContactTelephoneIDFax] [int] NULL,
	[C_ContactTelephoneIDTelephone] [int] NULL,
	[C_ContactTelephoneIDMobile] [int] NULL,
	[C_ContactTelephoneIDSMSMobile] [int] NULL,
	[Department] [nvarchar](200) NULL,
	[AddressQuality] [int] NULL,
	[TelephoneQuality] [int] NULL,
	[MobileQuality] [int] NULL,
	[SMSQuality] [int] NULL,
	[CountryCleaned] [nvarchar](100) NULL,
	[IsValidEmail] [bit] NULL,
	[DoNotUseEmail] [bit] NULL,
	[DoNotUseMobile] [bit] NULL,
	[DoNotUseTelephone] [bit] NULL,
	[DoNotUseSMSMobile] [bit] NULL,
	[DoNotUseAddress] [bit] NULL,
	[DoNotUseName] [bit] NULL,
	[C_ContactEmailID] [int] NULL,
	[C_PreviousContactEmailID] [int] NULL,
	[Status] [nvarchar](50) NULL,
	[ViperGUID] [nvarchar](200) NULL,
	[CreatedContact] [bit] NULL,
	[ParentMarketID] [int] NULL,
	[BaseDetail] [varchar](30) NULL,
	[SourceTable] [nvarchar](255) NULL,
	[LeadSourceMostRecent] [nvarchar](255) NULL,
	[OriginalLeadSource] [nvarchar](255) NULL,
	[ConvertedDate] [datetime] NULL,
	[ConvertedSourceContactID] [nvarchar](255) NULL,
	[SourceOpportunityID] [nvarchar](255) NULL,
	[CreatedBySourceOwnerID] [nvarchar](255) NULL,
	[ReasonForLoss] [nvarchar](255) NULL,
	[AccountID] [nvarchar](255) NULL,
	[OriginalSurName] [nvarchar](255) NULL,
	[OriginalFirstName] [nvarchar](255) NULL,
	[SourceOwnerID] [nvarchar](255) NULL,
	[C_CompanyID] [int] NULL,
	[ContactRole] [nvarchar](30) NULL,
	[EmailOwner] [int] NULL,
	[MasterScore] [int] NULL,
	[C_MasterRecord] [varchar](20) NULL,
	[Consolidated_ContactID] [int] NULL,
	[ThirdParty] [nvarchar](400) NULL
) ON [PRIMARY]
SET ANSI_PADDING OFF
ALTER TABLE [DB].[Contact] ADD [Gender] [char](1) NULL
ALTER TABLE [DB].[Contact] ADD [LastLogin] [datetime] NULL
SET ANSI_PADDING ON
ALTER TABLE [DB].[Contact] ADD [KeyDecisionMaker] [varchar](1) NULL
ALTER TABLE [DB].[Contact] ADD [ConsolidationGroupID] [int] NULL
ALTER TABLE [DB].[Contact] ADD [MasterLevel] [int] NULL
ALTER TABLE [DB].[Contact] ADD [ParentContactID] [int] NULL
ALTER TABLE [DB].[Contact] ADD [ParentContactID_Old] [int] NULL
ALTER TABLE [DB].[Contact] ADD [ComparisonFlag] [bit] NULL
ALTER TABLE [DB].[Contact] ADD [Matches] [int] NULL
PRIMARY KEY CLUSTERED 
(	[ContactID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]





-- update new fields

drop table #base

select *
into #base
from
(select source, sourcecontactid, marketcode, EmailAddress, FirstName,LastName,ContactAddress1,ContactPostCode,Telephone,CreateDate,LastUpdateDate
	, ROW_NUMBER() over(partition by source, sourcecontactid, marketcode order by auditdate desc) rowno
from base.db.contact(nolock)) x
where x.rowno = 1

update base.db.ContactConsolidatedIDs
set CreateDate = b.CreateDate,
LastUpdateDate = b.LastUpdateDate
from base.db.ContactConsolidatedIDs cc
inner join #base b
on cc.source = b.Source
and cc.SourceContactID = b.SourceContactID
and cc.MarketCode = b.MarketCode

--

USE [Consolidated_Staging]
GO

ALTER PROCEDURE [DB].[up_Base]

AS

--- Contacts
/*
 For Contact records that have created/updated Consolidated, add the 
record into Base as an Audit record (BaseType A)
*/

INSERT INTO Base.db.Contact 
(	Source,
	MarketCode, 
	SourceContactID, 
	EmailAddress, 
	CompanyName, 
	ContactAddress1, 
	ContactAddress2, 
	ContactAddress3, 
	ContactAddress4, 
	ContactTown, 
	ContactCounty, 
	ContactPostCode, 
	ContactCountryCode, 
	ContactCountryName, 
	Salutation, 
	FirstName,
	LastName, 
	Telephone, 
	JobTitle, 
	CreateDate, 
	LastUpdateDate, 
	Password, 
	ValidEmailAddress, 
	HTMLCapable, 
	SoftBounceCount,
	HardBounceCount, 
	LastBounced, 
	MobileNumber, 
	UserName, 
	GroupName, 
	Title, 
	SMSMobile,
	Department,
	AuditDate,
	C_ContactID,
	Status,
	ViperGUID,
	BaseDetail,
	ContactType,
	OrigSourceAccountID,
	OrigSourceOwnerID,
	ContactRole,
	Consolidated_ContactID,
    ThirdParty,
	LastLogin
)
SELECT DISTINCT 
	Source, 
	MarketCode, 
	SourceContactID, 
	EmailAddress, 
	CompanyName, 
	left(ContactAddress1,130), 
	ContactAddress2, 
	ContactAddress3, 
	ContactAddress4, 
	ContactTown, 
	ContactCounty, 
	ContactPostCode, 
	ContactCountryCode, 
	ContactCountryName, 
	Salutation, 
	FirstName,
	LastName, 
	Telephone, 
	JobTitle, 
	CreateDate, 
	LastUpdateDate, 
	Password, 
	ValidEmailAddress, 
	HTMLCapable, 
	SoftBounceCount,
	HardBounceCount, 
	LastBounced, 
	MobileNumber, 
	UserName, 
	GroupName, 
	Title, 
	SMSMobile,
	Department,
	GETDATE(),
	C_ContactID,
	Status,
	ViperGUID,
	BaseDetail,
	SourceTable,
	AccountID,
	SourceOwnerID,
	ContactRole,
	Consolidated_ContactID,
    ThirdParty,
	LastLogin
FROM 
	consolidated_staging.DB.Contact
WHERE 
	C_ContactAddressID IS NOT NULL 
	OR C_SourceEmailID IS NOT NULL
	OR C_ContactUsernameID IS NOT NULL
	OR C_ContactCompanyID IS NOT NULL
	OR C_ContactTelephoneIDFax IS NOT NULL
	OR C_ContactTelephoneIDTelephone IS NOT NULL
	OR C_ContactTelephoneIDMobile IS NOT NULL
	OR C_ContactTelephoneIDSMSMobile IS NOT NULL
	--OR C_ContactEmailID IS NOT NULL
	or CreatedContact = 1


/* for contact records that haven't updated Consolidated, look for an existing R 
record in Base. If it exists then update it if any field has changed and if the
source create/last update date is later */


/* Privacy
*/

INSERT INTO Base.DB.Privacy
(
	MarketCode, 
	Source, 
	FeedName, 
	DPAValue, 
	EmailAddress, 
	CreateDate, 
	LastUpdateDate, 
	IsGlobal, 
	C_ContactDPASettingID,
	SourceContactID,
	BaseDetail
	,ProxyName
	,ProxyRelationship
	,ProxyCompany
	,ProxyMethod
	,ProxyDate
	)
SELECT DISTINCT 
	ce.SourceMarketCode, 
	ce.Source, 
	ce.FeedName, 
	DPAValue, 
	EmailAddress, 
	CreateDate, 
	LastUpdateDate, 
	IsGlobal, 
	C_ContactDPASettingID,
	ce.SourceContactID,
	BaseDetail
	,ProxyName
	,ProxyRelationship
	,ProxyCompany
	,ProxyMethod
	,ProxyDate
FROM Consolidated_Staging.DB.Privacy_Consolidated_Email ce
WHERE C_ContactDPASettingID IS NOT NULL


	
/* Membership
*/

-- Add any membership that have created or updated Membership records. Get this from MembershipConsolidated. Don't
-- add any that have come from Demographics

INSERT INTO Base.db.Membership 
(
	Source, 
	MarketCode, 
	SourceContactID, 
	ProductCode, 
	Status,
	StartDate, 
	EndDate, 
	SubscriptionType, 
	FormSourceTracking, 
	CreateDate, 
	LastUpdateDate, 
	Description,
	LastIssueSent,
	EndIssueCode,
	ReaderType,
	SubEndDate,
	AgeDate,
	DespatchMethod,
	Promocode,
	C_MembershipID,
	ParentProductCode,
	BaseDetail,
	SourceMembershipID,
	AuditDate
)
SELECT DISTINCT 
	mc.Source, 
	mc.MarketCode, 
	mc.SourceContactID, 
	mc.ProductCode, 
	MembershipStatus,
	StartDate, 
	EndDate, 
	MembershipType, 
	FormSourceTracking, 
	CreateDate, 
	LastUpdateDate, 
	Description,
	LastIssueSent,
	EndIssueCode,
	ReaderType,
	SubEndDate,
	AgeDate,
	DespatchMethod,
	Promocode,
	C_MembershipID,
	ParentProductCode,
	BaseDetail,
	SourceMembershipID,
	Getdate()
FROM 
	db.MembershipConsolidated mc
WHERE 
	C_MembershipID IS NOT NULL AND DemographicID IS NULL



/*
	Update the table Base.DB.ContactConsolidatedIDs
	- if a record exists then update it
	- otherwise insert it
*/	

-- first, remove the C_IDs from any existing ContactConsolidatedIDs records

UPDATE Base.DB.ContactConsolidatedIDs
SET C_ContactAddressID = NULL
FROM Base.DB.ContactConsolidatedIDs cc
INNER JOIN Consolidated_Staging.DB.Contact c
ON c.C_ContactAddressID = cc.C_ContactAddressID

UPDATE Base.DB.ContactConsolidatedIDs
SET C_ContactCompanyID = NULL
FROM Base.DB.ContactConsolidatedIDs cc
INNER JOIN Consolidated_Staging.DB.Contact c
ON c.C_ContactCompanyID = cc.C_ContactCompanyID

UPDATE Base.DB.ContactConsolidatedIDs
SET C_ContactTelephoneIDFax = NULL
FROM Base.DB.ContactConsolidatedIDs cc
INNER JOIN Consolidated_Staging.DB.Contact c
ON c.C_ContactTelephoneIDFax = cc.C_ContactTelephoneIDFax

UPDATE Base.DB.ContactConsolidatedIDs
SET C_ContactTelephoneIDMobile = NULL
FROM Base.DB.ContactConsolidatedIDs cc
INNER JOIN Consolidated_Staging.DB.Contact c
ON c.C_ContactTelephoneIDMobile = cc.C_ContactTelephoneIDMobile

UPDATE Base.DB.ContactConsolidatedIDs
SET C_ContactTelephoneIDSMSMobile = NULL
FROM Base.DB.ContactConsolidatedIDs cc
INNER JOIN Consolidated_Staging.DB.Contact c
ON c.C_ContactTelephoneIDSMSMobile = cc.C_ContactTelephoneIDSMSMobile

UPDATE Base.DB.ContactConsolidatedIDs
SET C_ContactTelephoneIDTelephone = NULL
FROM Base.DB.ContactConsolidatedIDs cc
INNER JOIN Consolidated_Staging.DB.Contact c
ON c.C_ContactTelephoneIDTelephone = cc.C_ContactTelephoneIDTelephone

UPDATE Base.DB.ContactConsolidatedIDs
SET C_SourceEmailID = NULL
FROM Base.DB.ContactConsolidatedIDs cc
INNER JOIN Consolidated_Staging.DB.Contact c
ON c.C_SourceEmailID = cc.C_SourceEmailID

UPDATE Base.DB.ContactConsolidatedIDs
SET C_ContactUsernameID = NULL
FROM Base.DB.ContactConsolidatedIDs cc
INNER JOIN Consolidated_Staging.DB.Contact c
ON c.C_ContactUsernameID = cc.C_ContactUsernameID

UPDATE Base.DB.ContactConsolidatedIDs
SET C_ContactEmailID = NULL
FROM Base.DB.ContactConsolidatedIDs cc
INNER JOIN Consolidated_Staging.DB.Contact c
ON c.C_ContactEmailID = cc.C_ContactEmailID

-- then update existing ContactConsolidatedIDs records

UPDATE	
	Base.DB.ContactConsolidatedIDs
SET		
	C_SourceEmailID = CASE WHEN a.C_SourceEmailID IS NOT NULL THEN a.C_SourceEmailID ELSE b.C_SourceEmailID END,
	C_ContactCompanyID = CASE WHEN a.C_ContactCompanyID IS NOT NULL THEN a.C_ContactCompanyID ELSE b.C_ContactCompanyID END,
	C_ContactID = CASE WHEN a.C_ContactID IS NOT NULL THEN a.C_ContactID ELSE b.C_ContactID END,
	C_ContactTelephoneIDFax = CASE WHEN a.C_ContactTelephoneIDFax IS NOT NULL THEN a.C_ContactTelephoneIDFax ELSE b.C_ContactTelephoneIDFax END,
	C_ContactTelephoneIDMobile = CASE WHEN a.C_ContactTelephoneIDMobile IS NOT NULL THEN a.C_ContactTelephoneIDMobile ELSE b.C_ContactTelephoneIDMobile END,
	C_ContactTelephoneIDSMSMobile = CASE WHEN a.C_ContactTelephoneIDSMSMobile IS NOT NULL THEN a.C_ContactTelephoneIDSMSMobile ELSE b.C_ContactTelephoneIDSMSMobile END,
	C_ContactTelephoneIDTelephone = CASE WHEN a.C_ContactTelephoneIDTelephone IS NOT NULL THEN a.C_ContactTelephoneIDTelephone ELSE b.C_ContactTelephoneIDTelephone END,
	C_ContactAddressID=CASE	WHEN a.C_ContactAddressID IS NOT NULL THEN a.C_ContactAddressID ELSE b.C_ContactAddressID END,
	C_ContactEmailID=CASE WHEN a.C_ContactEmailID	IS NOT NULL THEN a.C_ContactEmailID ELSE b.C_ContactEmailID END,
	EmailAddress = a.EmailAddress,
	FirstName = a.FirstName,
	LastName = a.LastName,
	ContactAddress1 = a.ContactAddress1,
	ContactPostCode = a.ContactPostCode,
	Telephone = a.Telephone,
	SourceCreateDate = a.CreateDate,
	SourceLastUpdateDate = a.LastUpdateDate,
	--ConsolidationGroupID=CASE WHEN a.ConsolidationGroupID	IS NOT NULL THEN a.ConsolidationGroupID ELSE b.ConsolidationGroupID END,
	LastUpdateDate=GETDATE()
FROM DB.Contact a
	INNER JOIN Base.DB.ContactConsolidatedIDs b 
	ON a.Source=b.Source
	AND	a.MarketCode=b.MarketCode
	AND	a.SourceContactID=b.SourceContactID

-- update any that were loaded originally from ContactConsolidatedIDs

update 
	base.db.ContactConsolidatedIDs
	set c_contactid = a.C_ContactID
from db.ContactIgnoreBeyondContactMatching a
	INNER JOIN Base.DB.ContactConsolidatedIDs b 
	ON a.Source=b.Source
	AND	a.MarketCode=b.MarketCode
	AND	a.SourceContactID=b.SourceContactID
 where a.C_ContactID <> b.C_ContactID



INSERT INTO ETL_Staging.ETL.Audit (AuditCategoryID,Action,Type,ActionDate)
VALUES (5,'Success','Start - up_ConsolidationGroupID',getdate())


Exec Consolidated_Staging.db.up_ConsolidationGroupID

INSERT INTO ETL_Staging.ETL.Audit (AuditCategoryID,Action,Type,ActionDate)
VALUES (5,'Success','End - up_ConsolidationGroupID',getdate())



INSERT INTO Base.DB.ContactConsolidatedIDs(
	Source
	,MarketCode
	,SourceContactID
	,C_ContactUsernameID  
	,C_ContactAddressID  
	,C_SourceEmailID  
	,C_ContactID
	,C_ContactCompanyID  
	,C_ContactTelephoneIDFax  
	,C_ContactTelephoneIDTelephone  
	,C_ContactTelephoneIDMobile  
	,C_ContactTelephoneIDSMSMobile 
	,CreateDate
	,C_ContactEmailID
	,ConsolidationGroupID
	,Title
	,FirstName
	,LastName
	,EmailAddress
	,ContactAddress1
	,ContactPostCode
	,Telephone
	,MobileNumber
	,SourceCreateDate
	,SourceLastUpdateDate)
SELECT	DISTINCT 
	a.Source
	,a.MarketCode
	,a.SourceContactID
	,a.C_ContactUsernameID  
	,a.C_ContactAddressID  
	,a.C_SourceEmailID  
	,a.C_ContactID
	,a.C_ContactCompanyID  
	,a.C_ContactTelephoneIDFax  
	,a.C_ContactTelephoneIDTelephone  
	,a.C_ContactTelephoneIDMobile  
	,a.C_ContactTelephoneIDSMSMobile 
	,GETDATE()
	,a.C_ContactEmailID
	,a.ConsolidationGroupID
	,a.Title
	,a.FirstName
	,a.LastName
	,a.EmailAddress
	,a.ContactAddress1
	,a.ContactPostCode
	,a.Telephone
	,a.MobileNumber
	,a.CreateDate
	,a.LastUpdateDate
FROM	
	db.Contact a
	LEFT JOIN Base.DB.ContactConsolidatedIDs b 
	ON a.Source=b.Source 
	AND	a.MarketCode=b.MarketCode
	AND	a.SourceContactID=b.SourceContactID
WHERE	
	b.SourceContactID IS NULL
	AND	b.Source IS NULL
	AND	b.MarketCode IS NULL
	AND
	(a.C_ContactAddressID IS NOT NULL 
	OR a.C_SourceEmailID IS NOT NULL
	OR a.C_ContactUsernameID IS NOT NULL
	OR a.C_ContactCompanyID IS NOT NULL
	OR a.C_ContactTelephoneIDFax IS NOT NULL
	OR a.C_ContactTelephoneIDTelephone IS NOT NULL
	OR a.C_ContactTelephoneIDMobile IS NOT NULL
	OR a.C_ContactTelephoneIDSMSMobile IS NOT NULL
	OR a.C_ContactEmailID IS NOT NULL
	OR a.ConsolidationGroupID IS NOT NULL
	OR a.CreatedContact = 1)

/*
	Update the table Base.DB.MembershipConsolidatedIDs
	- if a record exists then update it
	- otherwise insert it
*/	

-- first, remove the C_IDs from any existing ContactConsolidatedIDs records

UPDATE Base.DB.MembershipConsolidatedIDs
SET C_MembershipID = NULL
FROM Base.DB.MembershipConsolidatedIDs cc
INNER JOIN Consolidated_Staging.DB.MembershipConsolidated c
ON cc.C_MembershipID = c.C_MembershipID

UPDATE	
	Base.DB.MembershipConsolidatedIDs
SET		
	C_MembershipID=a.C_MembershipID,
	LastUpdateDate= GETDATE(),
	IsDemographic = CASE WHEN a.Demographicid IS NOT NULL THEN 1 END
FROM	
	DB.MembershipConsolidated a
	INNER JOIN Base.DB.MembershipConsolidatedIDs b ON a.Source=b.Source
	AND	a.MarketCode=b.MarketCode
	AND	a.SourceContactID=b.SourceContactID
	AND	a.ProductCode=b.ProductCode
WHERE a.C_MembershipID IS NOT NULL




INSERT INTO 
	Base.DB.MembershipConsolidatedIDs
SELECT DISTINCT 
	a.Source
	,a.MarketCode
	,a.SourceContactID
	,a.ProductCode
	,a.C_MembershipID
	,GETDATE()
	,NULL
	,CASE WHEN a.Demographicid IS NOT NULL THEN 1 END
FROM	
	Consolidated_Staging.db.MembershipConsolidated a
	LEFT JOIN Base.DB.MembershipConsolidatedIDs b ON a.Source=b.Source
	AND	a.MarketCode=b.MarketCode
	AND	a.SourceContactID=b.SourceContactID
	AND	a.ProductCode=b.ProductCode
WHERE	
	b.Source IS NULL
	AND	b.MarketCode IS NULL
	AND	b.SourceContactID IS NULL
	AND	b.ProductCode IS NULL
	AND	a.C_MembershipID IS NOT NULL
	


IF OBJECT_ID('tempdb..#Demographic') IS NOT NULL 
	DROP TABLE #Demographic

SELECT SourceAccountID
	,DemographicID
	,DemographicCode
	,DemographicValue
	,OrigSourceAccountID
	,Source
	,MarketCode
	,CreateDate
	,LastUpdateDate
	,SourceID
INTO #Demographic
FROM
	(SELECT DISTINCT sa.SourceAccountID
		,dc.DemographicID
		,d.DemographicCode
		,d.DemographicValue
		,d.OrigSourceAccountID
		,d.Source
		,d.MarketCode
		,d.CreateDate
		,d.LastUpdateDate
		,s.SourceID
		,ROW_NUMBER() over (partition by SourceAccountID, DemographicID, DemographicValue, s.SourceID  order by isnull(d.lastupdatedate, d.createdate) desc ) rowno
	FROM ETL_Staging.etl.SourceAccountDemographic d 
	INNER JOIN Consolidated.db.Market m
	ON m.MarketCode = d.MarketCode
	INNER JOIN Consolidated.db.DemographicCode dc
	ON d.DemographicCode = dc.DemographicCode
	AND m.MarketID = dc.MarketID 
	INNER JOIN Consolidated.db.SourceAccount sa
	ON d.OrigSourceAccountID = sa.OrigSourceAccountID
	AND sa.MarketID = m.MarketID
	INNER JOIN Consolidated.db.Source s
	ON d.Source = s.SourceCode) x
WHERE rowno = 1

GO


ALTER PROCEDURE [DB].[up_ConsolidatedGetContactID]

AS



/*This procedure attempts to find the existing ContactIDs that the SourceContacts match to */

--select ConsolidationID, ParentContactID, MasterLevel, EmailAddress, firstname, lastname from Consolidated_Staging.db.Contact


--update Consolidated_Staging.db.Contact
--set ConsolidationID = ConsolidationID + '|' + cast(ParentContactID as varchar(5))


-- Updating C_ContactID. If a ContactID is being supplied in the ETL table then always use that

;WITH ccid as 
(
SELECT ConsolidationID,MAX(Consolidated_ContactID) MaxID FROM Consolidated_Staging.db.Contact
WHERE Consolidated_ContactID is not null 
GROUP BY ConsolidationID
)
UPDATE c2
SET c2.C_ContactID= c1.MaxID
FROM ccid c1
INNER JOIN Consolidated_Staging.db.Contact c2
ON c1.ConsolidationID = c2.ConsolidationID


IF OBJECT_ID('tempdb..#ContactQuality1') IS NOT NULL DROP TABLE #ContactQuality1

SELECT c.FirstName
	,c.LastName
	,c.MobileNumber
	,c.Telephone
	,c.SMSMobile
	,ETL_STAGING.ETL.fnNumbersOnly(c.MobileNumber) MobileNumber_C
	,ETL_STAGING.ETL.fnNumbersOnly(c.Telephone) Telephone_C
	,ETL_STAGING.ETL.fnNumbersOnly(c.SMSMobile) SMSMobile_C
	,c.ContactAddress1
	,c.ContactPostCode
	,c.ContactID
	,c.ConsolidationID
	,DoNotUseTelephone
	,DoNotUseMobile
	,DoNotUseSMSMobile
	,DoNotUseAddress
INTO #ContactQuality1
FROM DB.Contact c
WHERE DoNotUseName IS NULL
OR EmailAddress IS NOT NULL


-- match on email



IF OBJECT_ID('tempdb..#EmailParentContactID') IS NOT NULL DROP TABLE #EmailParentContactID

select EmailAddress, parentcontactid, consolidationid
into #EmailParentContactID
from
(select EmailAddress, parentcontactid , consolidationid, ROW_NUMBER() over(partition by emailaddress, consolidationid order by masterlevel) rowno
from Consolidated_Staging.db.Contact
where DoNotUseEmail is null
and IsValidEmail = 1) x
where rowno = 1


update db.Contact
set c_contactid = ce.ContactID
FROM db.Contact c
INNER JOIN Consolidated.DB.ContactEmail ce
ON ce.EmailAddress = c.EmailAddress
inner join #EmailParentContactID e
on c.EmailAddress = e.EmailAddress
and c.ParentContactID = e.ParentContactID
and c.ConsolidationID = e.ConsolidationID

-- match on telephone. match on the best record left in the consolidation group ie the one with the hightest MasterLevel
-- don't update the C_ContactID to any C_ContactIDs already matched


IF OBJECT_ID('tempdb..#TelephoneParentContactID') IS NOT NULL DROP TABLE #TelephoneParentContactID

select FirstName, LastName, Telephone, ParentContactID,ConsolidationID
into #TelephoneParentContactID
from
(select FirstName, LastName, Telephone, ParentContactID, ConsolidationID
	, ROW_NUMBER() over(partition by FirstName, LastName, Telephone, ConsolidationID order by masterlevel) rowno
from Consolidated_Staging.db.Contact
WHERE TelephoneQuality =1
and DoNotUseName is null
and DoNotUseTelephone is null
and c_contactid is null) x
where rowno = 1

update db.Contact
set c_contactid = cn.ContactID
FROM db.Contact c
INNER JOIN Consolidated.DB.ContactTelephone ct
on c.Telephone = ct.Number
inner join Consolidated.db.contact cn
on ct.contactid = cn.contactid
and cn.firstname = c.firstname
and cn.surname = c.LastName
inner join #TelephoneParentContactID t
on t.ConsolidationID = c.ConsolidationID
and t.parentcontactid = c.parentcontactid
LEFT JOIN (SELECT DISTINCT C_CONTACTID FROM db.Contact) c_c
on c_c.C_ContactID = cn.ContactID
where c_c.C_ContactID is null

-- match on address. match on the best record left in the consolidation group ie the one with the hightest MasterLevel
-- don't update the C_ContactID to any C_ContactIDs already matched


IF OBJECT_ID('tempdb..#AddressParentContactID') IS NOT NULL DROP TABLE #AddressParentContactID

select FirstName, LastName, ContactAddress1,ContactPostCode, ParentContactID,ConsolidationID
into #AddressParentContactID
from
(select FirstName, LastName, ContactAddress1, ContactPostCode, ParentContactID, ConsolidationID
	, ROW_NUMBER() over(partition by FirstName, LastName, ContactAddress1,ContactPostCode, ConsolidationID order by masterlevel) rowno
from Consolidated_Staging.db.Contact
WHERE DoNotUseName is null
and DoNotUseAddress is null
and c_contactid is null) x
where rowno = 1


update db.Contact
set c_contactid = cc.ContactID
FROM Consolidated.DB.Contact cc
INNER JOIN Consolidated.db.ContactAddress ca
on cc.ContactID = ca.ContactID
inner join Consolidated.db.Address a
on a.AddressID = ca.AddressID
inner join db.Contact c
on c.FirstName = cc.Firstname
and c.LastName = cc.Surname
and a.AddressLine1 = c.ContactAddress1
and a.Postcode = c.ContactPostCode
inner join #AddressParentContactID ap
on ap.ConsolidationID = c.ConsolidationID
and ap.parentcontactid = c.parentcontactid
LEFT JOIN (SELECT DISTINCT C_CONTACTID FROM db.Contact) c_c
on c_c.C_ContactID = cc.ContactID
where c_c.C_ContactID is null



-- if Contact record still doesn't have a c_contactid then update it to the previous value but 
-- only if the C_ContactID hasn't been given to another ParentContactID

update Consolidated_Staging.db.contact 
set c_contactid = c.C_PreviousContactID
from Consolidated_Staging.db.contact c
left join (select C_ContactID from Consolidated_Staging.db.contact) c2
on c.C_PreviousContactID = c2.C_ContactID
where c.c_contactid is null
and c.C_PreviousContactID is not null 
and c2.C_ContactID is null

-- update the contact details from the best contactID

IF OBJECT_ID('tempdb..#UpdateContact') IS NOT NULL DROP TABLE #UpdateContact

select *
into #UpdateContact
from
(select FirstName, LastName, Title,C_ContactID,OriginalFirstname,originalsurname, 
ROW_NUMBER() over(partition by C_ContactID order by masterscore desc, isnull(lastupdatedate,createdate) desc) rowno
from Consolidated_Staging.db.Contact) x
where rowno = 1

update Consolidated.db.Contact
set Firstname = cc.FirstName,
Surname = cc.LastName,
Title = cc.Title,
OriginalFirstname = cc.OriginalFirstname,
originalsurname = cc.originalsurname
from Consolidated.db.Contact c
inner join #UpdateContact cc
on C_ContactID = c.ContactID
where isnull(c.firstname,'') <> isnull(cc.firstname,'')
or isnull(c.Surname,'') <> isnull(cc.LastName,'')
or isnull(c.Title,'') <> isnull(cc.Title,'')


go



ALTER PROCEDURE [DB].[up_ConsolidatedCreateContactID]


AS

-- Update the existing Contact if it's Source

--IF OBJECT_ID('tempdb..#ContactBestWhenExists') IS NOT NULL 
--	DROP TABLE #ContactBestWhenExists

--SELECT Title, FirstName, LastName Surname, CreateDate, LastUpdateDate, C_ContactID, OriginalFirstName, Originalsurname,
--	 ROW_NUMBER() OVER (PARTITION BY C_ContactID
--						ORDER BY db.higherdate(LastUpdateDate, CreateDate) DESC) AS RowNo
--INTO #ContactBestWhenExists
--FROM db.contact
--WHERE FirstName IS NOT NULL AND LastName IS NOT NULL
--and c_contactid is not null


--UPDATE Consolidated.db.Contact
--SET title = cm.Title,
--FirstName = cm.FirstName,
--Surname = cm.Surname,
--OriginalFirstName = cm.OriginalFirstName,
--OriginalSurname = cm.OriginalSurname,
--SourceCreateDate = cm.CreateDate,
--SourceLastUpdateDate = cm.LastUpdateDate,
--LastUpdateDate = GETDATE() 
--FROM Consolidated.db.Contact ct
--INNER JOIN
--	(SELECT * FROM #ContactBestWhenEXISTS WHERE RowNo = 1) cm
--ON ct.ContactID = cm.C_ContactID
--AND db.higherdate(cm.LastUpdateDate, cm.CreateDate) 
--> db.higherdate(ct.SourceLastUpdateDate, ct.SourceCreateDate)
--AND (ISNULL(ct.FirstName,'') <> ISNULL(cm.FirstName,'')
--OR ISNULL(ct.Surname,'') <> ISNULL(cm.Surname,'')
--OR ISNULL(ct.title,'') <> ISNULL(cm.title,''))

update Consolidated.db.Contact
set ConsolidationID = null, ParentContactID = null
where ConsolidationID is not null or ParentContactID is not null

while (select count(*) from db.Contact WHERE c_ContactID IS NULL) > 0
begin

IF OBJECT_ID('tempdb..#ContactBestWhenNotExists') IS NOT NULL 
	DROP TABLE #ContactBestWhenNotExists

SELECT Title, FirstName, LastName Surname,CreateDate, LastUpdateDate , ConsolidationID, OriginalFirstName, Originalsurname,ParentContactid,
ROW_NUMBER() OVER (PARTITION BY ConsolidationID
							ORDER BY isnull(masterscore,0) desc, db.higherdate(LastUpdateDate, CreateDate) DESC) AS RowNo
	INTO #ContactBestWhenNotExists
	FROM db.Contact
	WHERE c_ContactID IS NULL



INSERT INTO Consolidated.db.Contact 
	(Title
	,Firstname
	,Surname
	,SourceCreateDate
	,SourceLastUpdateDate
	,ConsolidationID
	,OriginalFirstName
	, Originalsurname
	,ParentContactID)
SELECT Title
	,Firstname
	,Surname
	,CreateDate
	,LastUpdateDate
	,ConsolidationID 
	,OriginalFirstName
	, Originalsurname
	,ParentContactID
FROM #ContactBestWhenNotExists
WHERE RowNo = 1

--select * from Consolidated.db.Contact order by createdate desc

-- update the C_ContactID from the ContactID of the record just created

UPDATE db.Contact
SET C_ContactID = c.ContactID,
	CreatedContact = 1
FROM db.Contact cr
INNER JOIN Consolidated.db.Contact c
ON cr.ConsolidationID = c.ConsolidationID
and cr.ParentContactID = c.ParentContactID
WHERE cr.C_ContactID IS NULL

--select c_contactid, ConsolidationID, parentcontactid from Consolidated_Staging.db.contact 
--select top 3 ConsolidationID, parentcontactid, createdate from Consolidated.db.Contact order by createdate desc

update Consolidated.db.Contact
set ConsolidationID = null, ParentContactID = null
where ConsolidationID is not null or ParentContactID is not null

end


GO

ALTER PROCEDURE [DB].[up_CreateUpdateEmail]

AS


/*This procedure creates and updates Contact, ContactEmail and SourceEmail records */

-- get a single row per Email. Always select the row with the highest highest master level

IF OBJECT_ID('tempdb..#ContactEmailBest') IS NOT NULL 
	DROP TABLE #ContactEmailBest

SELECT C_ContactID
	,EmailAddress
	,CreateDate
	,LastUpdateDate
	,IsValidEmail
	,ContactID
	,ViperGuid
INTO #ContactEmailBest
FROM
	(SELECT C_ContactID
		,EmailAddress
		,CreateDate
		,LastUpdateDate
		,IsValidEmail
		,ContactID
		,ViperGuid
		,ROW_NUMBER() OVER (PARTITION BY EmailAddress 
			ORDER BY isnull(masterlevel,2000), EmailOwner desc, isnull(LastUpdateDate,CreateDate) DESC) AS RowNo
	FROM db.Contact 
	WHERE EmailAddress IS NOT NULL) x
WHERE RowNo = 1


-- update ContactEmail if the ContactID has changed

UPDATE Consolidated.db.ContactEmail
SET ContactID = ceb.C_ContactID
,LastUpdateDate = GETDATE()
FROM Consolidated.db.ContactEmail ce
INNER JOIN #ContactEmailBest ceb
ON ce.EmailAddress = ceb.EmailAddress
WHERE ce.ContactID <> ceb.C_ContactID

-- remove IgnoreBeyondContactMatching records 

-- update ContactEmail if GUID has changed but don't update it to a null

--UPDATE Consolidated.db.ContactEmail
--SET ViperGUID = ceb.ViperGUID
--,LastUpdateDate = GETDATE()
--FROM Consolidated.db.ContactEmail ce
--INNER JOIN #ContactEmailBest ceb
--ON ce.EmailAddress = ceb.EmailAddress
--WHERE (ceb.ViperGUID IS NOT NULL AND ce.ViperGUID IS NOT NULL) OR ceb.ViperGUID <> ce.ViperGUID

-- create new ContactEmail records where the EmailAddress doesn't already exist.

INSERT INTO Consolidated.db.ContactEmail 
(ContactID
,EmailAddress
,SourceCreateDate
,SourceLastUpdateDate
,IsValid
,ViperGUID
,C_ContactID)
SELECT c.C_ContactID
		,c.EmailAddress
		,c.CreateDate
		,c.LastUpdateDate
		,c.IsValidEmail
		,c.ViperGUID
		,c.ContactID
FROM #ContactEmailBest c
LEFT JOIN Consolidated.db.ContactEmail ce
ON c.EmailAddress = ce.EmailAddress
WHERE ce.EmailAddress IS NULL

-- get the current ContactEmailID by joining on the email

UPDATE Consolidated_Staging.DB.Contact
SET C_ContactEmailID = ce.ContactEmailID
FROM Consolidated_Staging.DB.Contact c
INNER JOIN Consolidated.DB.ContactEmail ce
ON c.EmailAddress = ce.EmailAddress

-- put those records that were loaded from Base.db.ContactConsolidatedIDs into a separate table but only if the C_ContactID has changed 
-- (the only thing that can change.)

truncate table Consolidated_Staging.db.ContactIgnoreBeyondContactMatching

insert into Consolidated_Staging.db.ContactIgnoreBeyondContactMatching (SourceContactID, MarketCode, Source, C_ContactID)
select SourceContactID, MarketCode, Source, C_ContactID from Consolidated_Staging.db.Contact
where c_contactid <> C_PreviousContactID

-- then delete them.

 delete from Consolidated_Staging.db.Contact where IgnoreBeyondContactMatching = 1

 -- is the new ContactEmailID different from the old ContactEmailID and has it been updated more recents? If so, update its Membership
-- records to the new ContactEmailID

UPDATE Consolidated.DB.Membership
SET ContactEmailID = c.C_ContactEmailID,
LastUpdateDate = GETDATE(),
EmailLastUpdateDate = GETDATE()
FROM db.Contact c
INNER JOIN Consolidated.DB.Membership m
ON C_PreviousContactEmailID = m.ContactEmailID
WHERE c.C_ContactEmailID <> c.C_PreviousContactEmailID
AND M.SourceID = c.SourceID

-- duplidates will be deleted by up_ConsolidatedMembership


/* for each source Contact record with an email, find the values required by the SourceEmail record
 this and C_SourceEmailID (unless there are more than one existing SourceContact records already, in which all should be.)
 */

 -- at this point remove all records that are IgnoreBeyondContactMatching



TRUNCATE TABLE db.SourceEmail

INSERT INTO Consolidated_Staging.DB.SourceEmail
           (SourceID
           ,ContactEmailID
           ,MarketID
           ,HardBounceCount
           ,SoftBounceCount
           ,IsValid
           ,SourceCreateDate
           ,SourceLastUpdateDate
           ,SourceEmailID
           ,S_ContactID
           ,GreatestDate
           ,Status
           ,ThirdParty )
SELECT SourceID
	,ContactEmailID
	,CASE WHEN ParentMarketID IS NULL THEN MarketID ELSE ParentMarketID END MarketID
	,HardBounceCount
	,SoftBounceCount
	,CASE WHEN SourceID not in (1,56) THEN NULL ELSE ValidEmailAddress END
	,cr.CreateDate
	,cr.LastUpdateDate
	,cr.C_SourceEmailID
	,cr.ContactID S_ContactID
	,GreatestDate
	,cr.Status
	,cr.ThirdParty
FROM db.Contact cr
LEFT JOIN Consolidated.db.ContactEmail ce
ON cr.EmailAddress = ce.EmailAddress
WHERE cr.EmailAddress IS NOT NULL OR C_SourceEmailID IS NOT NULL

-- if the ContactEmailID is null then that means the source record no longer has an email

DELETE Consolidated.db.SourceEmail
FROM db.SourceEmail s
INNER JOIN Consolidated.db.SourceEmail se
ON s.SourceEmailID = se.SourceEmailID
WHERE db.higherdate(s.SourceCreateDate, s.SourceLastUpdatedate) > 
db.higherdate(se.SourceCreateDate, se.SourceLastUpdateDate)
AND s.ContactEmailID IS NULL

-- if the source Contact record has created a SourceEmail record before then update this record but only if 
-- any of the values are different (except SourceLastUpdateDate) and the record has been updated more recently in the source system
-- any records that have been updated get the ContactID of the contact record that updated it

UPDATE Consolidated.db.SourceEmail
SET SourceID = se.SourceID, 
ContactEmailID = se.ContactEmailID, 
MarketID = se.MarketID,
HardBounceCount = se.HardBounceCount, 
SoftBounceCount = se.SoftBounceCount, 
IsValid = se.IsValid,
SourceCreateDate = se.SourceCreateDate, 
SourceLastUpDateDate = se.SourceLastUpdateDate,
LastUpdateDate = GETDATE(), 
S_ContactID = se.S_ContactID,
Status = se.Status,
ThirdPartyID = Tp.ThirdPartyID  
FROM Consolidated.db.SourceEmail cse
INNER JOIN db.SourceEmail se
ON cse.SourceEmailID = se.SourceEmailID
Left Join Consolidated.db.ThirdParty Tp On se.ThirdParty = Tp.Name  
WHERE (cse.SourceID <> se.SourceID
or cse.ContactEmailID <> se.ContactEmailID
or cse.MarketID <> se.MarketID
or ISNULL(cse.HardBounceCount,'') <> ISNULL(se.HardBounceCount,'')
or ISNULL(cse.SoftBounceCount,'') <> ISNULL(se.SoftBounceCount,'')
or ISNULL(cse.IsValid,'') <> ISNULL(se.IsValid,'')
or ISNULL(cse.SourceCreateDate,'') <> ISNULL(se.SourceCreateDate,'')
or ISNULL(cse.ThirdPartyID,'') <> ISNULL(Tp.ThirdPartyID,''))
AND GreatestDate >= isnull( cse.SourceLastUpdateDate,cse.SourceCreateDate)
AND se.ContactEmailID IS NOT NULL

-- delete any duplicates that this update has created

IF OBJECT_ID('tempdb..#SourceEmailDelete') IS NOT NULL 
	DROP TABLE #SourceEmailDelete

SELECT x.SourceEmailID
INTO #SourceEmailDelete
FROM 
	(SELECT c.SourceEmailID, ROW_NUMBER() over(partition by se.ContactEmailID, se.MarketID, se.SourceID
	ORDER BY isnull(c.SourceLastUpdateDate, c.SourceCreateDate) desc) rowno
	FROM (SELECT DISTINCT contactemailid, marketid, sourceid from db.SourceEmail) se
	INNER JOIN Consolidated.DB.SourceEmail c
	ON SE.ContactEmailID = c.ContactEmailID
	AND SE.MarketID = C.MarketID
	AND se.SourceID = c.SourceID) x
WHERE ROWNO <> 1

DELETE Consolidated.DB.SourceEmail 
FROM Consolidated.DB.SourceEmail se
INNER JOIN #SourceEmailDelete sed
ON se.SourceEmailID = sed.SourceEmailID

		
-- consolidate the SourceEmail records

TRUNCATE TABLE db.SourceEmailConsolidated

INSERT INTO db.SourceEmailConsolidated (SourceID
	,ContactEmailID
	,MarketID
	,HardBounceCount
	,SoftBounceCount
	,IsValid
	,SourceCreateDate
	,SourceLastUpdateDate
	,S_ContactID
	,GreatestDate
	,Status
	,ThirdParty )
SELECT se.SourceID
	,se.ContactEmailID
	,se.MarketID
	,se.HardBounceCount
	,se.SoftBounceCount
	,se.IsValid
	,se.SourceCreateDate
	,se.SourceLastUpdateDate
	,S_ContactID
	,GreatestDate
	,Status
	,se.ThirdParty
FROM db.SourceEmail se
INNER JOIN
	(SELECT MAX(S_ContactID) MaxS_ContactID
	FROM db.SourceEmail se
	INNER JOIN
		(SELECT SourceID, MarketID, ContactEmailID, MAX(GreatestDate) MaxGreatestDate
		FROM db.SourceEmail
		WHERE SourceEmailID IS NULL
		GROUP BY SourceID, MarketID, ContactEmailID) sem
	ON se.SourceID = sem.SourceID
	AND se.MarketID = sem.MarketID
	AND se.ContactEmailID = sem.ContactEmailID
	AND se.GreatestDate = sem.MaxGreatestDate
	WHERE SourceEmailID IS NULL
	GROUP BY se.SourceID, se.MarketID, se.ContactEmailID) sem
ON se.S_ContactID = sem.MaxS_ContactID

-- if the ContactEmailID/SourceID/MarketID already exists, then update this record, but only if any field has changed except update date

UPDATE Consolidated.db.SourceEmail
SET HardBounceCount = sec.HardBounceCount,
SoftBounceCount = sec.SoftBounceCount,
IsValid = sec.IsValid,
SourceCreateDate = sec.SourceCreateDate,
SourceLastUpdateDate = sec.SourceLastUpdateDate,
LastUpdateDate = GETDATE(),
S_ContactID = sec.S_ContactID,
Status = sec.Status
FROM Consolidated.db.SourceEmail se
INNER JOIN db.SourceEmailConsolidated sec
ON se.ContactEmailID = sec.ContactEmailID
AND se.MarketID = sec.MarketID
AND se.SourceID = sec.SourceID
Left Join Consolidated.db.ThirdParty Tp on sec.ThirdParty = tp.Name
WHERE sec.GreatestDate > ISNULL(se.SourceLastUpdatedate, se.SourceCreateDate) 
AND (ISNULL(sec.HardBounceCount,'') <> ISNULL(se.HardBounceCount,'')
OR ISNULL(sec.SoftBounceCount,'') <> ISNULL(se.SoftBounceCount,'')
OR ISNULL(sec.IsValid,'') <> ISNULL(se.IsValid,'') )


-- Update ThirdPartyID

UPDATE Consolidated.db.SourceEmail
SET ThirdPartyID = Tp.ThirdPartyID
FROM Consolidated.db.SourceEmail se
INNER JOIN db.SourceEmailConsolidated sec
ON se.ContactEmailID = sec.ContactEmailID
AND se.MarketID = sec.MarketID
AND se.SourceID = sec.SourceID
Left Join Consolidated.db.ThirdParty Tp on sec.ThirdParty = tp.Name
WHERE ISNULL(se.ThirdPartyID,'') <> ISNULL(Tp.ThirdPartyID,'')

-- insert new records into SourceEmail table

INSERT INTO Consolidated.db.SourceEmail (SourceID
	,ContactEmailID
	,MarketID
	,HardBounceCount
	,SoftBounceCount
	,IsValid
	,SourceCreateDate
	,SourceLastUpdateDate
	,S_ContactID
	,Status
	,ThirdPartyID )
SELECT sec.SourceID
	,sec.ContactEmailID
	,sec.MarketID
	,sec.HardBounceCount
	,sec.SoftBounceCount
	,sec.IsValid
	,sec.SourceCreateDate
	,sec.SourceLastUpdateDate
	,sec.S_ContactID
	,sec.Status
	,Tp.ThirdPartyID
FROM db.SourceEmailConsolidated sec
LEFT JOIN Consolidated.db.SourceEmail se
ON se.ContactEmailID = sec.ContactEmailID
AND se.MarketID = sec.MarketID
AND se.SourceID = sec.SourceID
Left Join Consolidated.db.ThirdParty Tp on sec.ThirdParty = tp.Name
WHERE se.SourceEmailID IS NULL


-- remove the C_SourceEmailID values from the Contact table. They will get repopulated in a bit from the SourceEmail table

UPDATE db.Contact
SET C_SourceEmailID = NULL
WHERE C_SourceEmailID IS NOT NULL

-- get the SourceEmailID just created and update the Source contact record that created it

UPDATE db.Contact
SET C_SourceEmailID = s.SourceEmailID
FROM db.Contact c
INNER JOIN Consolidated.db.SourceEmail s
ON c.ContactID = s.S_ContactID

-- remove the S_ContactIDs, they have served their purpose

UPDATE Consolidated.db.SourceEmail
SET S_ContactID = NULL
WHERE S_ContactID IS NOT NULL

-- remove the ConsolidationID from the Contact record, it has served its purpose

UPDATE Consolidated.db.Contact SET ConsolidationID = NULL WHERE ConsolidationID IS NOT NULL

-- load suppressions

INSERT INTO Consolidated.DB.SuppressEmail (Status
	,SuppressEmail
	,CreateDate
	,UserName
	,SuppressReasonID)
SELECT Status
	,EmailAddress
	,CreateDate
	,Source
	,SuppressReasonID
FROM
	(SELECT 'y' Status
		,S.EmailAddress
		,GETDATE() CreateDate
		,s.Source
		,sr.SuppressReasonID
		,ROW_NUMBER() OVER(PARTITION BY s.EmailAddress ORDER BY sr.SuppressReasonID desc) RowNo
	FROM ETL_Staging.ETL.Suppression s
	LEFT JOIN Consolidated.DB.SuppressEmail se
	ON S.EmailAddress = SE.SuppressEmail
	LEFT JOIN Consolidated.DB.SuppressReason sr
	ON sr.SuppressReason = s.SuppressReason
	WHERE se.SuppressEmail IS NULL) x
WHERE RowNo = 1

UPDATE Consolidated.DB.SuppressEmail 
SET Status = 'y'
,UserName = s.Source
,SuppressReasonID = sr.SuppressReasonID
FROM ETL_Staging.ETL.Suppression s
INNER JOIN Consolidated.DB.SuppressEmail se
ON S.EmailAddress = SE.SuppressEmail
LEFT JOIN Consolidated.DB.SuppressReason sr
	ON sr.SuppressReason = s.SuppressReason
WHERE se.Status <> 'Y'




GO


ALTER PROCEDURE [DB].[up_ConsolidateContacts]


AS

-- Load JobTitle into the Demographic etl_staging table

INSERT INTO ETL_Staging.ETL.Demographic (Source, MarketCode, SourceContactID, DemographicCode,
DemographicValue, CreateDate, LastUPDATEDate)
SELECT Source, MarketCode, SourceContactID, 'JOBTITLE' DemographicCode, JobTitle, CreateDate, LastUPDATEDate 
FROM ETL_Staging.ETL.Contact WHERE JobTitle IS NOT NULL


IF OBJECT_ID('tempdb..#es') IS NOT NULL DROP TABLE #es

select EmailAddress
into #es
from ETL_Staging.etl.Contact
where EmailAddress is not null
group by EmailAddress

IF OBJECT_ID('tempdb..#d') IS NOT NULL DROP TABLE #d

select distinct cc.ConsolidationGroupID
into #d
from #es c
inner join base.db.ContactConsolidatedIDs cc
on c.EmailAddress = cc.EmailAddress
where cc.ConsolidationGroupID is not null

--select c.source
--	,c.SourceContactID
--	,c.MarketCode
--	,c.EmailAddress
--	,c.FirstName
--	,c.LastName
--	,c.ContactAddress1
--	,c.ContactPostCode
--	,c.Telephone
--	,c.CreateDate
--	,c.LastUpdateDate
--into 
--from base.db.ContactConsolidatedIDs c
--left join ETL_Staging.etl.contact cc
--on c.Source = cc.Source
--and c.MarketCode = cc.MarketCode
--and c.SourceContactID = cc.SourceContactID
--inner join #d d
--on d.ConsolidationGroupID = c.ConsolidationGroupID









-- dedupe on SourceContactID, Source and Market



IF OBJECT_ID('tempdb..#ContactDupes') IS NOT NULL 
	DROP TABLE #ContactDupes
	
SELECT *, 0 IgnoreBeyondContactMatching,
ROW_NUMBER() OVER 
(PARTITION BY Source, SourceContactID, MarketCode
        ORDER BY Consolidated_staging.db.HigherDate(CreateDate,LastUPDATEDate) desc) RowNo
	INTO #ContactDupes
FROM ETL_Staging.ETL.Contact  

insert into #ContactDupes
(source
	,SourceContactID
	,MarketCode
	,EmailAddress
	,FirstName
	,LastName
	,ContactAddress1
	,ContactPostCode
	,Telephone
	,CreateDate
	,LastUpdateDate
	,IgnoreBeyondContactMatching
	,Rowno)
select c.source
	,c.SourceContactID
	,c.MarketCode
	,c.EmailAddress
	,c.FirstName
	,c.LastName
	,c.ContactAddress1
	,c.ContactPostCode
	,c.Telephone
	,c.CreateDate
	,c.LastUpdateDate
	,1 IgnoreBeyondContactMatching
	,1 Rowno
from base.db.ContactConsolidatedIDs c
left join ETL_Staging.etl.contact cc
on c.Source = cc.Source
and c.MarketCode = cc.MarketCode
and c.SourceContactID = cc.SourceContactID
inner join #d d
on d.ConsolidationGroupID = c.ConsolidationGroupID
where cc.Source is null


-- clean the name up

-- find firstname/last name combinations that don't already exist

IF OBJECT_ID('tempdb..#DistinctNamesETLStaging') IS NOT NULL 
	DROP TABLE #DistinctNamesETLStaging

select distinct FirstName, LastName 
into #DistinctNamesETLStaging 
from #ContactDupes

IF OBJECT_ID('tempdb..#DistinctNamesConsolidated') IS NOT NULL 
	DROP TABLE #DistinctNamesConsolidated

select distinct OriginalFirstName, OriginalSurName 
into #DistinctNamesConsolidated 
from Consolidated.db.Contact


IF OBJECT_ID('tempdb..#CleanedName') IS NOT NULL 
	DROP TABLE #CleanedName

SELECT c.FirstName, c.LastName 
INTO #CleanedName
FROM #DistinctNamesETLStaging c 
LEFT JOIN #DistinctNamesConsolidated cc 
ON isnull(c.FirstName,'') = isnull(cc.OriginalFirstName,'') 
AND isnull(c.LastName,'') = isnull(cc.OriginalSurName,'')
WHERE cc.OriginalFirstName is null

ALTER TABLE #CleanedName add 
CleanedFirstName nvarchar(255),
CleanedSurname nvarchar(255)



exec Consolidated_Staging.db.up_CleanName '#CleanedName','FirstName','CleanedFirstName','LastName','CleanedSurname'

IF OBJECT_ID('tempdb..#DistinctNamesConsolidated') IS NOT NULL 
	DROP TABLE #DistinctNamesConsolidated


/*load Contact file to Contact. Also lookup the SourceID and MarketID. If the record has
no CreateDate or LastDate then use a dummy date
Shuffle AddressLines along in cases where AddressLine1 is null and AddressLine2 is not null */

-- union 

IF OBJECT_ID('tempdb..#Contact') IS NOT NULL 
	DROP TABLE #Contact

select ContactID
,Source
,MarketCode
,SourceContactID
,EmailAddress
,CompanyName
,REPLACE(REPLACE(ContactAddress1,CHAR(10),''),CHAR(13),'') ContactAddress1
,REPLACE(REPLACE(ContactAddress2,CHAR(10),''),CHAR(13),'') ContactAddress2
,REPLACE(REPLACE(ContactAddress3,CHAR(10),''),CHAR(13),'') ContactAddress3
,REPLACE(REPLACE(ContactAddress4,CHAR(10),''),CHAR(13),'') ContactAddress4
,REPLACE(REPLACE(ContactTown,CHAR(10),''),CHAR(13),'') ContactTown
,REPLACE(REPLACE(ContactCounty,CHAR(10),''),CHAR(13),'') ContactCounty
,REPLACE(REPLACE(ContactPostCode,CHAR(10),''),CHAR(13),'') ContactPostCode
,REPLACE(REPLACE(ContactCountryCode,CHAR(10),''),CHAR(13),'') ContactCountryCode
,REPLACE(REPLACE(ContactCountryName,CHAR(10),''),CHAR(13),'') ContactCountryName
,Salutation
,FirstName
,LastName
,Telephone
,JobTitle
,Password
,ValidEmailAddress
,HTMLCapable
,SoftBounceCount
,HardBounceCount
,LastBounced
,MobileNumber
,UserName
,GroupName
,Title
,Status
,AddressType
,Fax
,SMSMobile
,Department
,ViperGUID
,BaseDetail
,CreateDate
,LastUpdateDate
,ContactType
,LeadSourceMostRecent
,OriginalLeadSource
,ConvertedDate
,ConvertedSourceContactID
,SourceOpportunityID
,CreatedBySourceOwnerID
,ReasonForLoss
,OrigSourceAccountID
,OrigSourceOwnerID
,ContactRole
,Consolidated_ContactID
,ThirdParty
,LastLogin
,KeyDecisionMaker
,IgnoreBeyondContactMatching
into #Contact 
from #ContactDupes 
WHERE RowNo = 1 
AND (ContactAddress1 IS NOT NULL 
OR ContactAddress2 IS NULL) 
union
select ContactID
,Source
,MarketCode
,SourceContactID
,EmailAddress
,CompanyName
,REPLACE(REPLACE(ContactAddress2,CHAR(10),''),CHAR(13),'')
,REPLACE(REPLACE(ContactAddress3,CHAR(10),''),CHAR(13),'')
,REPLACE(REPLACE(ContactAddress4,CHAR(10),''),CHAR(13),'')
,null
,REPLACE(REPLACE(ContactTown,CHAR(10),''),CHAR(13),'')
,REPLACE(REPLACE(ContactCounty,CHAR(10),''),CHAR(13),'')
,REPLACE(REPLACE(ContactPostCode,CHAR(10),''),CHAR(13),'')
,REPLACE(REPLACE(ContactCountryCode,CHAR(10),''),CHAR(13),'')
,REPLACE(REPLACE(ContactCountryName,CHAR(10),''),CHAR(13),'')
,Salutation
,FirstName
,LastName
,Telephone
,JobTitle
,Password
,ValidEmailAddress
,HTMLCapable
,SoftBounceCount
,HardBounceCount
,LastBounced
,MobileNumber
,UserName
,GroupName
,Title
,Status
,AddressType
,Fax
,SMSMobile
,Department
,ViperGUID
,BaseDetail
,CreateDate
,LastUpdateDate
,ContactType
,LeadSourceMostRecent
,OriginalLeadSource
,ConvertedDate
,ConvertedSourceContactID
,SourceOpportunityID
,CreatedBySourceOwnerID
,ReasonForLoss
,OrigSourceAccountID
,OrigSourceOwnerID 
,ContactRole
,Consolidated_ContactID
,ThirdParty
,LastLogin
,KeyDecisionMaker
,IgnoreBeyondContactMatching
from #ContactDupes 
WHERE RowNo = 1 
AND ContactAddress1 IS NULL 
AND ContactAddress2 IS NOT NULL
-- join

IF OBJECT_ID('tempdb..#CleanName') IS NOT NULL 
	DROP TABLE #CleanName

SELECT FirstName, LastName, MAX(CleanedFirstName) CleanedFirstName, MAX(CleanedSurname) CleanedSurname
into #CleanName
        FROM	
                (SELECT isnull(FirstName,'?%�5tt?Ee')FirstName, isnull(LastName,'?%�5tt?Ee')LastName, CleanedFirstName, CleanedSurname
		   FROM #CleanedName
		   --where CleanedSurname = 'Hinchley'
		   UNION
		   SELECT isnull(OriginalFirstName,'?%�5tt?Ee'), isnull(OriginalSurName,'?%�5tt?Ee') , Firstname, Surname
		   FROM Consolidated.db.Contact
		   --where surname = 'Hinchley'
		   ) X
	       GROUP BY firstName, LastName

		
---- combined #CleanedName and Consolidated.db.contact

--IF OBJECT_ID('tempdb..#CleanedName2') IS NOT NULL 
--	DROP TABLE #CleanedName2

--select firstname, lastname, max(cleanedfirstname) cleanedfirstname, max(cleanedsurname) cleanedsurname
--into #CleanedName2
--from
--(select firstname, lastname, cleanedfirstname, cleanedsurname
--from #CleanedName
--union
--select OriginalFirstname, OriginalSurname,Firstname, Surname
--from Consolidated.db.Contact) x
--group by firstname, lastname


IF OBJECT_ID('tempdb..#Contact2') IS NOT NULL 
	DROP TABLE #Contact2

select distinct ContactID
        ,c.Source
        ,SourceID
        ,c.MarketCode
        ,MarketID
        ,SourceContactID
        ,EmailAddress
        ,CompanyName
     	,ContactAddress1
        ,ContactAddress2
        ,ContactAddress3
        ,ContactAddress4
        ,ContactTown
        ,ContactCounty
        ,ContactPostCode
	,ContactCountryCode
        ,ContactCountryName
        ,Salutation
        ,CleanedFirstName
        ,CleanedSurname
        ,Telephone
        ,JobTitle	
	,CASE WHEN CreateDate IS NULL AND LastUPDATEDate IS NULL THEN '19500101' ELSE CreateDate END CreateDate
	,LastUPDATEDate
        ,Password
        ,ValidEmailAddress
        ,HTMLCapable
        ,SoftBounceCount
        ,HardBounceCount
        ,LastBounced
	,MobileNumber
        ,GroupName
        ,UserName
        ,Title
        ,CreateDate CreateDateForHigherDate
        ,LastUpdateDate LastUpdateDateForHigherDate
        ,AddressType
        ,SMSMobile, Fax, Department
        ,CASE WHEN v.ValueToIgnore1 IS NOT NULL OR v2.ValueToIgnore1 IS NOT NULL THEN 1 END DoNotUseEmail
	,vNameFirstOnly.ValueToIgnore1 ValueToIgnore1NameFirstOnly
	,CASE WHEN vTelephone.ValueToIgnore1 IS NOT NULL THEN 1 END DoNotUseTelephone
	,CASE WHEN vMobile.ValueToIgnore1 IS NOT NULL THEN 1 END DoNotUseMobile
	,CASE WHEN vSMSMobile.ValueToIgnore1 IS NOT NULL THEN 1 END DoNotUseSMSMobile
	,CASE WHEN vAddress.ValueToIgnore1 IS NOT NULL THEN 1 END DoNotUseAddress
	,c.Status
        ,ViperGUID
        ,ParentMarketID
        ,BaseDetail
        ,ContactType
    ,LeadSourceMostRecent
    ,OriginalLeadSource
    ,ConvertedDate
    ,ConvertedSourceContactID
    ,SourceOpportunityID
    ,CreatedBySourceOwnerID
    ,ReasonForLoss
    ,OrigSourceAccountID
         ,c.FirstName
         ,c.LastName
         ,OrigSourceOwnerID
		 ,ContactRole
		 ,Consolidated_ContactID
		 ,ThirdParty
		 ,LastLogin
		 ,KeyDecisionMaker
		 ,IgnoreBeyondContactMatching
into #Contact2
from #Contact c
INNER JOIN Consolidated.db.Market m 
ON c.Marketcode = m.MarketCode
INNER JOIN Consolidated.db.Source s 
ON c.Source = s.SourceCode
LEFT JOIN DB.ValuesToIgnoreInConsolidation v 
ON v.ValueToIgnore1 = c.EmailAddress 
AND v.TypeOfValue = 'e'
LEFT JOIN DB.ValuesToIgnoreInConsolidation v2 
ON v2.ValueToIgnore1 = case when charindex('@',c.EmailAddress) > 1 then substring(c.EmailAddress,1,charindex('@',c.EmailAddress)-1) end 
AND v2.TypeOfValue = 'r'
LEFT JOIN (SELECT DISTINCT ValueToIgnore1 FROM db.ValuesToIgnoreInConsolidation WHERE TypeOfValue = 'n') vNameFirstOnly 
ON c.FirstName = vNameFirstOnly.ValueToIgnore1
LEFT JOIN DB.ValuesToIgnoreInConsolidation vTelephone 
ON vTelephone.ValueToIgnore1 = c.Telephone 
AND vTelephone.TypeOfValue = 't'
LEFT JOIN DB.ValuesToIgnoreInConsolidation vMobile 
ON vMobile.ValueToIgnore1 = c.MobileNumber 
AND vMobile.TypeOfValue = 't'
LEFT JOIN DB.ValuesToIgnoreInConsolidation vSMSMobile 
ON vSMSMobile.ValueToIgnore1 = c.SMSMobile 
AND vSMSMobile.TypeOfValue = 't'
LEFT JOIN DB.ValuesToIgnoreInConsolidation vAddress 
ON vAddress.ValueToIgnore1 = c.ContactAddress1 
AND vAddress.ValueToIgnore2 = c.ContactPostCode 
AND vAddress.TypeOfValue = 'a'
LEFT JOIN 
        #CleanName cleanname 
ON cleanname.FirstName = isnull(c.FirstName,'?%�5tt?Ee') 
AND cleanname.LastName = isnull(c.LastName,'?%�5tt?Ee')


IF OBJECT_ID('tempdb..#Contact') IS NOT NULL 
	DROP TABLE #Contact

-- apply functions

TRUNCATE TABLE DB.Contact


INSERT INTO DB.Contact (Source
,SourceID
,MarketCode
,MarketID
,SourceContactID
,EmailAddress
,CompanyName
,ContactAddress1
,ContactAddress2
,ContactAddress3
,ContactAddress4
,ContactTown
,ContactCounty
,ContactPostCode
,ContactCountryCode
,ContactCountryName
,Salutation
,FirstName
,LastName
,Telephone
,JobTitle
,CreateDate
,LastUpdateDate
,Password
,ValidEmailAddress
,HTMLCapable
,SoftBounceCount
,HardBounceCount
,LastBounced
,MobileNumber
,GroupName
,UserName
,Title
,GreatestDate
,AddressType
,SMSMobile
,Fax
,Department
,AddressQuality
,TelephoneQuality
,MobileQuality
,SMSQuality
,IsValidEmail
,DoNotUseEmail
,DoNotUseName
,DoNotUseTelephone
,DoNotUseMobile
,DoNotUseSMSMobile
,DoNotUseAddress
,Status
,ViperGUID
,ParentMarketID
,BaseDetail
,[SourceTable]
,[LeadSourceMostRecent]
,[OriginalLeadSource]
,[ConvertedDate]
,[ConvertedSourceContactID]
,[SourceOpportunityID]
,[CreatedBySourceOwnerID]
,[ReasonForLoss]
,[AccountID]
,OriginalFirstName
,OriginalSurname
,SourceOwnerID
,ContactRole
,Consolidated_ContactID
,ThirdParty
,LastLogin
,KeyDecisionMaker
,IgnoreBeyondContactMatching
)
select Source
,SourceID
,MarketCode
,MarketID
,SourceContactID
,EmailAddress
,CompanyName
,ContactAddress1
,ContactAddress2
,ContactAddress3
,ContactAddress4
,ContactTown
,ContactCounty
,ContactPostCode
,ContactCountryCode
,ContactCountryName
,left(Salutation,10)
,CleanedFirstName
,CleanedSurname
,Telephone
,JobTitle
,CreateDate
,LastUPDATEDate
,Password
,ValidEmailAddress
,HTMLCapable
,SoftBounceCount
,HardBounceCount
,LastBounced
,MobileNumber
,GroupName
,UserName
,Title
,ISNULL(db.higherdate(CreateDateForHigherDate,LastUpdateDateForHigherDate),'19500101')
,AddressType
,SMSMobile, Fax, Department
,null
,db.fn_GetTelephoneQualityScore(Telephone) TelephoneQuality
,db.fn_GetTelephoneQualityScore(MobileNumber) MobileQuality
,db.fn_GetTelephoneQualityScore(SMSMobile) SMSQuality
,Presentation_Staging.DB.fn_EmailValidation(EmailAddress
        	,ISNULL(ISNULL(LastUpdateDate,CreateDate),GETDATE())) IsValidEmail
                , DoNotUseEmail
                ,CASE 
                        WHEN ValueToIgnore1NameFirstOnly IS NOT NULL OR
                        (FirstName IS NULL AND LastName IS NULL) OR 
                        LEN(FirstName) <> LEN( db.fn_RemoveNonAlpha(FirstName)) OR
                        LEN(REPLACE(FirstName,'.','')) < 2 OR
                        LEN(REPLACE(LastName,'.','')) < 2
                        THEN 1 END DoNotUseName
           , DoNotUseTelephone
           , DoNotUseMobile
           , DoNotUseSMSMobile
           , DoNotUseAddress
           ,Status
           ,ViperGUID
           ,ParentMarketID
           ,BaseDetail
           ,ContactType
           ,LeadSourceMostRecent
           ,OriginalLeadSource
           ,ConvertedDate
           ,ConvertedSourceContactID
           ,SourceOpportunityID
           ,CreatedBySourceOwnerID
           ,ReasonForLoss
           ,OrigSourceAccountID
           ,FirstName
           ,LastName
           ,OrigSourceOwnerID
		   ,ContactRole
		   ,Consolidated_ContactID
		   ,ThirdParty
		   ,LastLogin
		   ,KeyDecisionMaker
		   ,IgnoreBeyondContactMatching
from #Contact2

IF OBJECT_ID('tempdb..#Contact2') IS NOT NULL 
	DROP TABLE #Contact2

--ALTER INDEX x_contact_lastname_telephone ON DB.Contact REBUILD

Exec DB.up_EmailOwner 'Consolidated_Staging.DB.Contact','EmailAddress','FirstName','LastName','EmailOwner'

UPDATE Consolidated_Staging.DB.Contact SET MasterScore = CASE WHEN ISNULL(EmailOwner,0) > 0 THEN ISNULL(EmailOwner,0)+30 ELSE ISNULL(EmailOwner,0) END+
														 CASE WHEN len(ISNULL(OriginalFirstName,'')) > 1 THEN 3 ELSE 0 END+
														 CASE WHEN len(ISNULL(OriginalSurName,'')) > 1 THEN  3 ELSE 0 END+
														 CASE WHEN len(ISNULL(ContactAddress1,'')) > 0 and len(ISNULL(ContactPostCode,'')) > 0 THEN 1 ELSE 0  END+
														 CASE WHEN TelephoneQuality = 1 THEN 1 ELSE 0 END 
														 FROM Consolidated_Staging.DB.Contact 


-- Load records into channel tables -----------------

TRUNCATE TABLE DB.Channel_Email

INSERT INTO DB.Channel_Email
SELECT DISTINCT EmailAddress
FROM DB.Contact
WHERE EmailAddress IS NOT NULL
AND DoNotUseEmail IS NULL
AND IsValidEmail = 1

TRUNCATE TABLE DB.Channel_Telephone

INSERT INTO DB.Channel_Telephone (Telephone, LastName, FirstName)
SELECT DISTINCT Telephone, LastName, FirstName
FROM DB.Contact
WHERE Telephone IS NOT NULL
AND DoNotUseTelephone IS NULL
AND TelephoneQuality = 1
AND DoNotUseName IS NULL
UNION
SELECT DISTINCT MobileNumber, LastName, FirstName
FROM DB.Contact
WHERE MobileNumber IS NOT NULL
AND DoNotUseMobile IS NULL
AND DoNotUseName IS NULL
AND MobileQuality = 1
UNION
SELECT DISTINCT SMSMobile, LastName, FirstName
FROM DB.Contact
WHERE SMSMobile IS NOT NULL
AND DoNotUseSMSMobile IS NULL
AND DoNotUseName IS NULL
AND SMSQuality = 1

TRUNCATE TABLE DB.Channel_Address

INSERT INTO DB.Channel_Address (AddressKey,FirstName,LastName)
SELECT DISTINCT ContactAddress1 + '|' + ContactPostCode, FirstName, LastName
FROM DB.Contact
WHERE len(ContactAddress1) >3  AND len(ContactPostCode)>3
AND LastName IS NOT NULL AND FirstName IS NOT NULL
AND DoNotUseName IS NULL
AND DoNotUseAddress IS NULL


-- load records into Channel_Contact tables ----------------------------------

TRUNCATE TABLE DB.Channel_EmailContact

INSERT INTO DB.Channel_EmailContact
SELECT ContactID, EmailID
FROM DB.Contact c
INNER JOIN DB.Channel_Email ce
ON c.EmailAddress = ce.Email

TRUNCATE TABLE DB.Channel_TelephoneContact

INSERT INTO DB.Channel_TelephoneContact
SELECT c.ContactID, t.TelephoneID
FROM DB.Contact c
INNER JOIN DB.Channel_Telephone t
ON c.LastName = t.LastName
AND c.Telephone = t.Telephone
AND c.FirstName = t.FirstName
UNION
SELECT c.ContactID, t.TelephoneID
FROM DB.Contact c
INNER JOIN DB.Channel_Telephone t
ON c.LastName = t.LastName
AND c.MobileNumber = t.Telephone
AND c.FirstName = t.FirstName
UNION
SELECT c.ContactID, t.TelephoneID
FROM DB.Contact c
INNER JOIN DB.Channel_Telephone t
ON c.LastName = t.LastName
AND c.SMSMobile = t.Telephone
AND c.FirstName = t.FirstName

TRUNCATE TABLE DB.Channel_AddressContact

INSERT INTO DB.Channel_AddressContact
SELECT Contactid, Addressid
FROM DB.Contact c
INNER JOIN DB.Channel_Address a
ON ContactAddress1 + '|' + ContactPostCode = addresskey
AND c.FirstName = a.FirstName
AND c.lastname = a.LastName

/* populate Contact_Channel_Consolidation
This will be used to identify which contacts share the same channels 
Exclude BASubs emails because they are 'account' emails ie the same email is used across multiple emails*/

TRUNCATE TABLE DB.Contact_Channel_Consolidation

INSERT INTO DB.Contact_Channel_Consolidation (Contactid, EmailID, TelephoneID, AddressID,SourceContactID)
SELECT c.ContactID, EmailID, TelephoneID, AddressID, Source + SourceContactID
FROM DB.Contact c
LEFT JOIN DB.Channel_EmailContact ce
ON c.ContactID = ce.ContactID
LEFT JOIN DB.Channel_TelephoneContact tc
ON tc.ContactID = c.ContactID
LEFT JOIN DB.Channel_AddressContact ca
ON c.ContactID = ca.ContactID

EXEC db.up_Consolidation


UPDATE DB.Contact_Channel_Consolidation
SET ConsolidationID = CONVERT(VARCHAR(10),cc.ConsolidationID)+'_'+CONVERT(VARCHAR(10),ps.contactwithinconsolidationID)
FROM DB.Contact_Channel_Consolidation cc
inner join db.Contact c
on cc.ContactID = c.ContactID
INNER JOIN ETL_Staging.etl.ProspectSoftConsolidation ps
ON c.SourceContactID = ps.SourceContactID
and c.source = 'prospectsoft crm'


update [DB].[Contact_Channel_Consolidation] 
set ConsolidationID = d.ConsolidationID + '_1'
from [DB].[Contact_Channel_Consolidation] d
inner join
       (select distinct left(consolidationid,CHARINDEX('_',consolidationid)-1) ConsolidationID
       from [DB].[Contact_Channel_Consolidation]
       where consolidationid like '%[_]1') x
on d.ConsolidationID = x.ConsolidationID
where d.ConsolidationID not like '%[_]%'

-- UPDATE the Contact with the ConsolidationID

UPDATE DB.Contact
SET ConsolidationID = cc.ConsolidationID
FROM DB.Contact c
INNER JOIN DB.Contact_Channel_Consolidation cc
ON c.ContactID = cc.ContactID


--DQ - 31 
update m2 set C_MasterRecord =  m1.ConsolidationID from 
(select ConsolidationID,max(MasterScore) m_score from DB.Contact
group by ConsolidationID) m1,
(select * from (select C_MasterRecord,contactid,MasterScore,ConsolidationID,
                       DENSE_RANK() over (partition by MasterScore,ConsolidationID 
                                          order by MasterScore,coalesce(LastUpdateDate,CreateDate) desc) rec_order   
          from DB.Contact) m3
where rec_order = 1) m2
where m1.ConsolidationID = m2.ConsolidationID and m1.m_score = m2.MasterScore


--DQ - 35


Update C set Gender = G.Gender from Consolidated_Staging.DB.Contact C
Inner Join Consolidated_Staging.DB.Gender G
ON C.Title = G.Name 
Where C.Title is not null and G.MatchedOn = 'Title'
and C.Gender is null  --461260

Update C set Gender = G.Gender from Consolidated_Staging.DB.Contact C
Inner Join Consolidated_Staging.DB.Gender G
ON C.OriginalFirstName = G.Name 
Where C.OriginalFirstName is not null and G.MatchedOn = 'FirstName'
and C.Gender is null --15406065

--Step 1
Update C set Gender = G.Gender from Consolidated_Staging.DB.Contact C
Inner Join Consolidated_Staging.DB.Gender G
ON C.OriginalFirstName = G.Name 
Where C.OriginalFirstName is not null and G.MatchedOn = 'Title'
and C.Gender is null --2016

--Step 2
Update C set Gender = 'M' from Consolidated_Staging.DB.Contact C
where Gender is null and OriginalFirstName like 'Mr[ .]%'

--Step 3
Update C set Gender = 'F' from Consolidated_Staging.DB.Contact C
where Gender is null and OriginalFirstName like 'Mrs[ .]%'

--Step 4
Update C set Gender = G.Gender from Consolidated_Staging.DB.Contact C
Inner Join Consolidated_Staging.DB.Gender G
ON LEFT(FirstName,PATINDEX('% %',C.FirstName)) = G.Name 
Where C.FirstName is not null and C.Gender is null and C.FirstName like '% %' 

--Step 4
Update C set Gender = G.Gender from Consolidated_Staging.DB.Contact C
Inner Join Consolidated_Staging.DB.Gender G
ON LEFT(OriginalFirstName,PATINDEX('% %',C.OriginalFirstName)) = G.Name 
Where C.OriginalFirstName is not null and C.Gender is null and C.OriginalFirstName like '% %' 


--Step 5
Update C set Gender = G.Gender from Consolidated_Staging.DB.Contact C
Inner Join Consolidated_Staging.DB.Gender G
ON SUBSTRING(C.OriginalFirstName,PATINDEX('% %',C.OriginalFirstName)+1,LEN(C.OriginalFirstName)) = G.Name 
Where C.OriginalFirstName is not null and C.Gender is null and C.OriginalFirstName like '% %'
AND LEN(LEFT(OriginalFirstName,PATINDEX('% %',C.OriginalFirstName))) < 3

--Step 6
Update C set Gender = G.Gender from Consolidated_Staging.DB.Contact C
Inner Join Consolidated_Staging.DB.Gender G
ON LEFT(OriginalFirstName,PATINDEX('%.%',C.OriginalFirstName)-1) = G.Name 
Where C.OriginalFirstName is not null and C.Gender is null and C.OriginalFirstName like '%.%' 


--Step 7
Update C set Gender = G.Gender from Consolidated_Staging.DB.Contact C
Inner Join Consolidated_Staging.DB.Gender G
ON SUBSTRING(C.OriginalFirstName,PATINDEX('%.%',C.OriginalFirstName)+1,LEN(C.OriginalFirstName)) = G.Name 
Where C.OriginalFirstName is not null and C.Gender is null and C.OriginalFirstName like '%.%'
AND LEN(LEFT(OriginalFirstName,PATINDEX('%.%',C.OriginalFirstName))) < 3

--Step 8
Update C set Gender = G.Gender from Consolidated_Staging.DB.Contact C
Inner Join Consolidated_Staging.DB.Gender G
ON LEFT(OriginalFirstName,PATINDEX('%-%',C.OriginalFirstName)-1) = G.Name 
Where C.OriginalFirstName is not null and C.Gender is null and C.OriginalFirstName like '%-%' 

--SELECT LEFT('Kim-Soon',PATINDEX('%-%','Kim-Soon')-1) 

--Step 9
Update C set Gender = G.Gender from Consolidated_Staging.DB.Contact C
Inner Join Consolidated_Staging.DB.Gender G
ON SUBSTRING(C.OriginalFirstName,PATINDEX('%-%',C.OriginalFirstName)+1,LEN(C.OriginalFirstName)) = G.Name 
Where C.OriginalFirstName is not null and C.Gender is null and C.OriginalFirstName like '%-%'
AND LEN(LEFT(OriginalFirstName,PATINDEX('%-%',C.OriginalFirstName))) < 3





GO

