

IF OBJECT_ID('tempdb..##ContactIDs') IS NOT NULL 
	DROP TABLE ##ContactIDs


create table ##ContactIDs
(ContactID int)

IF OBJECT_ID('tempdb..##SourceContacts') IS NOT NULL 
	DROP TABLE ##SourceContacts

create table ##SourceContacts
(Source varchar(20),
SourceContactID varchar(100),
MarketCode varchar(3))

-- get ContactIDs for ProspectSoft re-consolidation

insert into ##ContactIDs

select distinct C_ContactID
from base.db.ContactConsolidatedIDs c
inner join ##SourceContactIDs sc
on c.SourceContactID = sc.sourcecontactid
and c.source = 'prospectsoft crm'



-- seed the ContactID

--insert into ##ContactIDs 
--values (3974270),
--(47806581),
--(61431455),
--(68004715),
--(69071168),
--(71023367),
--(72343951),
--(72456453),
--(72748928),
--(72748976),
--(72748980),
--(72748988),
--(72749000),
--(72749005),
--(72749020),
--(72749037),
--(72749038),
--(72749066),
--(72749073),
--(72749086),
--(72749116),
--(72749160),
--(72749174),
--(72749181),
--(72749184),
--(72749204),
--(72749209),
--(72749230),
--(72749241),
--(72749247),
--(72749255),
--(72749256),
--(72749266),
--(72749271),
--(72749300),
--(72749335),
--(72749359),
--(72749365),
--(72749403),
--(72749412),
--(72749413),
--(72749442),
--(72749449),
--(72749487),
--(72749881),
--(72749937),
--(72749947),
--(72749958),
--(72749982),
--(72750005),
--(72750008),
--(72750109),
--(72750133),
--(72750201),
--(72750230),
--(72750239),
--(72750270),
--(72750275),
--(72750302),
--(72750312),
--(72750321),
--(72750330),
--(72750428),
--(72750439),
--(72750459),
--(72750473),
--(72750474),
--(72750477),
--(72750491),
--(72750503),
--(72750547),
--(72750588),
--(72750591),
--(72750614),
--(72750630),
--(72750631),
--(72750645),
--(72750646),
--(72750668),
--(72750684),
--(72750730),
--(72750761),
--(72750768),
--(72750820),
--(72750861),
--(72750890),
--(72750894),
--(72750927),
--(72750947),
--(72750955),
--(72750981),
--(72750994),
--(72751043),
--(72751050),
--(72751073),
--(72751091),
--(72751117),
--(72751135),
--(72751405),
--(72751576)


declare @RowCount1 int
--declare @RowCount2 int

set @RowCount1 = 1

while not (@RowCount1 = 0 )

-- do while at least one SQL statement has updated



BEGIN

--insert into ReconsolidationAudit (AuditDate, CurrentCount)
select getdate(), (select count(*) from ##SourceContacts)

SET @RowCount1 = 0

-- get all the SourceContacts that has the ContactID

-- get them from the C_ContactID in ContactConsolidatedIDs

insert into ##SourceContacts
select distinct cc.Source, cc.SourceContactID, cc.MarketCode
from base.DB.ContactConsolidatedIDs cc
inner join ##ContactIDs ci
on cc.C_ContactID = ci.ContactID
left join ##SourceContacts sc
on sc.MarketCode = cc.MarketCode
and sc.SourceContactID = cc.SourceContactID
and sc.Source = cc.Source
where sc.SourceContactID is null

IF @@ROWCOUNT > 0 BEGIN SET @RowCount1 = 1 END

-- get them from the C_SourceEmailID in ContactConsolidatedIDs

insert into ##SourceContacts
select distinct cc.Source, cc.SourceContactID, cc.MarketCode
from base.DB.ContactConsolidatedIDs cc
inner join Consolidated.DB.SourceEmail se
on cc.C_SourceEmailID = se.SourceEmailID
inner join Consolidated.DB.ContactEmail ce
on ce.ContactEmailID = se.ContactEmailID
inner join ##ContactIDs ci
on ce.ContactID = ci.ContactID
left join ##SourceContacts sc
on sc.MarketCode = cc.MarketCode
and sc.SourceContactID = cc.SourceContactID
and sc.Source = cc.Source
where sc.SourceContactID is null

IF @@ROWCOUNT > 0 BEGIN SET @RowCount1 = 1 END

insert into ##SourceContacts
select distinct cc.Source, cc.SourceContactID, cc.MarketCode
from base.DB.ContactConsolidatedIDs cc
inner join Consolidated.DB.ContactTelephone ct
on cc.C_ContactTelephoneIDTelephone = ct.ContactTelephoneID
inner join ##ContactIDs ci
on ct.ContactID = ci.ContactID
left join ##SourceContacts sc
on sc.MarketCode = cc.MarketCode
and sc.SourceContactID = cc.SourceContactID
and sc.Source = cc.Source
where sc.SourceContactID is null

IF @@ROWCOUNT > 0 BEGIN SET @RowCount1 = 1 END

insert into ##SourceContacts
select distinct cc.Source, cc.SourceContactID, cc.MarketCode
from base.DB.ContactConsolidatedIDs cc
inner join Consolidated.DB.ContactTelephone ct
on cc.C_ContactTelephoneIDMobile = ct.ContactTelephoneID
inner join ##ContactIDs ci
on ct.ContactID = ci.ContactID
left join ##SourceContacts sc
on sc.MarketCode = cc.MarketCode
and sc.SourceContactID = cc.SourceContactID
and sc.Source = cc.Source
where sc.SourceContactID is null

IF @@ROWCOUNT > 0 BEGIN SET @RowCount1 = 1 END

insert into ##SourceContacts
select distinct cc.Source, cc.SourceContactID, cc.MarketCode
from base.DB.ContactConsolidatedIDs cc
inner join Consolidated.DB.ContactTelephone ct
on cc.C_ContactTelephoneIDSMSMobile = ct.ContactTelephoneID
inner join ##ContactIDs ci
on ct.ContactID = ci.ContactID
left join ##SourceContacts sc
on sc.MarketCode = cc.MarketCode
and sc.SourceContactID = cc.SourceContactID
and sc.Source = cc.Source
where sc.SourceContactID is null

IF @@ROWCOUNT > 0 BEGIN SET @RowCount1 = 1 END

insert into ##SourceContacts
select distinct cc.Source, cc.SourceContactID, cc.MarketCode
from base.DB.ContactConsolidatedIDs cc
inner join Consolidated.DB.ContactAddress ct
on cc.C_ContactAddressID = ct.ContactAddressID
inner join ##ContactIDs ci
on ct.ContactID = ci.ContactID
left join ##SourceContacts sc
on sc.MarketCode = cc.MarketCode
and sc.SourceContactID = cc.SourceContactID
and sc.Source = cc.Source
where sc.SourceContactID is null

IF @@ROWCOUNT > 0 BEGIN SET @RowCount1 = 1 END

insert into ##SourceContacts
select distinct cc.Source, cc.SourceContactID, cc.MarketCode
from base.DB.ContactConsolidatedIDs cc
inner join Consolidated.DB.ContactCompany ct
on cc.C_ContactCompanyID = ct.ContactCompanyID
inner join ##ContactIDs ci
on ct.ContactID = ci.ContactID
left join ##SourceContacts sc
on sc.MarketCode = cc.MarketCode
and sc.SourceContactID = cc.SourceContactID
and sc.Source = cc.Source
where sc.SourceContactID is null

IF @@ROWCOUNT > 0 BEGIN SET @RowCount1 = 1 END

insert into ##SourceContacts
select distinct cc.Source, cc.SourceContactID, cc.MarketCode
from base.DB.ContactConsolidatedIDs cc
inner join Consolidated.DB.ContactEmail ct
on cc.C_ContactEmailID = ct.ContactEmailID
inner join ##ContactIDs ci
on ct.ContactID = ci.ContactID
left join ##SourceContacts sc
on sc.MarketCode = cc.MarketCode
and sc.SourceContactID = cc.SourceContactID
and sc.Source = cc.Source
where sc.SourceContactID is null

IF @@ROWCOUNT > 0 BEGIN SET @RowCount1 = 1 END

insert into ##SourceContacts
select distinct mc.Source, mc.SourceContactID, mc.MarketCode
from base.DB.MembershipConsolidatedIDs mc
inner join Consolidated.DB.Membership m
on mc.C_MembershipID = m.MembershipID
inner join ##ContactIDs ci
on m.ContactID = ci.ContactID
left join ##SourceContacts sc
on sc.MarketCode = mc.MarketCode
and sc.SourceContactID = mc.SourceContactID
and sc.Source = mc.Source
where sc.SourceContactID is null

IF @@ROWCOUNT > 0 BEGIN SET @RowCount1 = 1 END

insert into ##SourceContacts
select distinct mc.Source, mc.SourceContactID, mc.MarketCode
from base.DB.MembershipConsolidatedIDs mc
inner join Consolidated.DB.Membership m
on mc.C_MembershipID = m.MembershipID
inner join Consolidated.DB.ContactEmail ce
on ce.ContactEmailID = m.ContactEmailID
inner join ##ContactIDs ci
on ce.ContactID = ci.ContactID
left join ##SourceContacts sc
on sc.MarketCode = mc.MarketCode
and sc.SourceContactID = mc.SourceContactID
and sc.Source = mc.Source
where sc.SourceContactID is null

IF @@ROWCOUNT > 0 BEGIN SET @RowCount1 = 1 END

insert into ##SourceContacts
select distinct p.Source, p.SourceContactID, p.MarketCode
from base.db.privacy p
inner join consolidated.db.contactdpasettingemail dpa
on p.c_contactdpasettingid = dpa.contactdpasettingid
inner join consolidated.db.contactemail ce
on dpa.contactemailid = ce.contactemailid
inner join ##ContactIDs ci
on ce.ContactID = ci.ContactID
left join ##SourceContacts sc
on sc.MarketCode = p.MarketCode
and sc.SourceContactID = p.SourceContactID
and sc.Source = p.Source
where sc.SourceContactID is null
and p.MarketCode is not null
and p.SourceContactID is not null

IF @@ROWCOUNT > 0 BEGIN SET @RowCount1 = 1 END

insert into ##SourceContacts
select distinct d.Source, d.SourceContactID, d.MarketCode
from base.db.Demographic d
inner join consolidated.db.ContactDemographic cd
on d.C_ContactDemographicID = cd.ContactDemographicID
inner join ##ContactIDs ci
on cd.ContactID = ci.ContactID
left join ##SourceContacts sc
on sc.MarketCode = d.MarketCode
and sc.SourceContactID = d.SourceContactID
and sc.Source = d.Source
where sc.SourceContactID is null

IF @@ROWCOUNT > 0 BEGIN SET @RowCount1 = 1 END

insert into ##SourceContacts
select distinct SourceCode, m.SourceContactID, mk.MarketCode
from Consolidated.DB.Membership m
inner join ##ContactIDs c
on m.ContactID = c.ContactID
inner join Consolidated.DB.Product p
on p.ProductID = m.ProductID
inner join Consolidated.DB.Market mk
on p.MarketID = mk.MarketID
inner join Consolidated.DB.Source s
on s.SourceID = m.SourceID
left join ##SourceContacts sc
on sc.MarketCode = mk.MarketCode
and sc.SourceContactID = m.SourceContactID
and sc.Source = s.SourceCode
where m.SourceContactID is not null
and sc.SourceContactID is null

IF @@ROWCOUNT > 0 BEGIN SET @RowCount1 = 1 END

insert into ##ContactIDs
select distinct x.ContactID
from 
(select Source, SourceContactID, MarketCode, ContactID
from base.DB.ContactConsolidatedIDs cc
inner join Consolidated.DB.ContactAddress ca
on cc.C_ContactAddressID = ca.ContactAddressID
union
select Source, SourceContactID, MarketCode, ContactID
from base.DB.ContactConsolidatedIDs cc
inner join Consolidated.DB.SourceEmail se
on cc.C_SourceEmailID = se.SourceEmailID
inner join Consolidated.DB.ContactEmail ce
on ce.ContactEmailID = se.ContactEmailID) x
inner join ##SourceContacts sc
on x.Source = sc.Source
and x.MarketCode = sc.MarketCode
and x.sourcecontactid = sc.SourceContactID
left join ##ContactIDs c
on c.ContactID = x.ContactID
where c.ContactID is null
and x.ContactID is not null

IF @@ROWCOUNT > 0 BEGIN SET @RowCount1 = 1 END

insert into ##ContactIDs
select distinct x.ContactID
from 
(select Source, SourceContactID, MarketCode, ContactID
from base.DB.ContactConsolidatedIDs cc
inner join Consolidated.DB.ContactTelephone ct
on cc.C_ContactTelephoneIDTelephone = ct.ContactTelephoneID
union
select Source, SourceContactID, MarketCode, ContactID
from base.DB.ContactConsolidatedIDs cc
inner join Consolidated.DB.ContactTelephone ct
on cc.C_ContactTelephoneIDMobile = ct.ContactTelephoneID
union
select Source, SourceContactID, MarketCode, ContactID
from base.DB.ContactConsolidatedIDs cc
inner join Consolidated.DB.ContactTelephone ct
on cc.C_ContactTelephoneIDSMSMobile = ct.ContactTelephoneID) x
inner join ##SourceContacts sc
on x.Source = sc.Source
and x.MarketCode = sc.MarketCode
and x.sourcecontactid = sc.SourceContactID
left join ##ContactIDs c
on c.ContactID = x.ContactID
where c.ContactID is null
and x.ContactID is not null

IF @@ROWCOUNT > 0 BEGIN SET @RowCount1 = 1 END

insert into ##ContactIDs
select distinct x.ContactID
from 
(select Source, SourceContactID, MarketCode, ContactID
from base.DB.ContactConsolidatedIDs cc
inner join Consolidated.DB.ContactEmail ce
on cc.C_ContactEmailID = ce.ContactEmailID
union
select Source, SourceContactID, MarketCode, contactid
from base.DB.ContactConsolidatedIDs cc
inner join Consolidated.DB.ContactCompany c
on cc.C_ContactCompanyID = c.ContactCompanyID
union
select Source, mc.SourceContactID, MarketCode, contactid
from base.DB.MembershipConsolidatedIDs mc
inner join Consolidated.DB.Membership m
on mc.C_MembershipID = m.MembershipID
where m.ContactID is not null) x
inner join ##SourceContacts sc
on x.Source = sc.Source
and x.MarketCode = sc.MarketCode
and x.sourcecontactid = sc.SourceContactID
left join ##ContactIDs c
on c.ContactID = x.ContactID
where c.ContactID is null
and x.ContactID is not null

IF @@ROWCOUNT > 0 BEGIN SET @RowCount1 = 1 END

insert into ##ContactIDs
select distinct x.ContactID
from 
(select Source, SourceContactID, MarketCode, contactid
from base.db.Demographic d
inner join consolidated.db.ContactDemographic cd
on d.C_ContactDemographicID = cd.ContactDemographicID
union
select Source, SourceContactID, MarketCode, ce.contactid
from base.db.Privacy d
inner join consolidated.db.ContactDPASettingEmail dpa
on d.C_ContactDPASettingID = dpa.ContactDPASettingID
inner join Consolidated.DB.ContactEmail ce
on dpa.ContactEmailID = ce.ContactEmailID) x
inner join ##SourceContacts sc
on x.Source = sc.Source
and x.MarketCode = sc.MarketCode
and x.sourcecontactid = sc.SourceContactID
left join ##ContactIDs c
on c.ContactID = x.ContactID
where c.ContactID is null
and x.ContactID is not null

IF @@ROWCOUNT > 0 BEGIN SET @RowCount1 = 1 END

insert into ##ContactIDs
select distinct x.ContactID
from 
(select Source, m.SourceContactID, mk.MarketCode, m.ContactID
from Consolidated.DB.Membership m
inner join Consolidated.DB.Product p
on p.ProductID = m.ProductID
inner join Consolidated.DB.Market mk
on p.MarketID = mk.MarketID
inner join Consolidated.DB.Source s
on s.SourceID = m.SourceID
inner join ##SourceContacts sc
on sc.MarketCode = mk.MarketCode
and sc.SourceContactID = m.SourceContactID
and sc.Source = s.SourceCode
where m.SourceContactID is not null) x
inner join ##SourceContacts sc
on x.Source = sc.Source
and x.MarketCode = sc.MarketCode
and x.sourcecontactid = sc.SourceContactID
left join ##ContactIDs c
on c.ContactID = x.ContactID
where c.ContactID is null
and x.ContactID is not null

IF @@ROWCOUNT > 0 BEGIN SET @RowCount1 = 1 END

end



IF OBJECT_ID('tempdb..##SourceContactsWithLatestEmail') IS NOT NULL 
	DROP TABLE ##SourceContactsWithLatestEmail


select Source, SourceContactID, MarketCode, EmailAddress
into ##SourceContactsWithLatestEmail
from 
	(select sc.*, c.emailaddress, ROW_NUMBER() over(partition by sc.sourcecontactid, sc.marketcode, sc.source order by c.auditdate desc) rowno
	from ##SourceContacts sc
	left join base.DB.Contact c
	on sc.MarketCode = c.MarketCode
	and sc.Source = c.Source
	and sc.SourceContactID = c.SourceContactID) x
where rowno = 1

