
-- DQ-53 Remove all Consolidated data associated with ProspectSoft source

Use ETL_Staging
go

If exists (select 1 from INFORMATION_SCHEMA.TABLES where TABLE_NAME='ToBeReConsolidated' and TABLE_SCHEMA='ETL')
  drop table ETL.ToBeReConsolidated
go

Create table ETL.ToBeReConsolidated(
      Source Nvarchar(100),
      SourceContactID Nvarchar(50),
      MarketCode Nvarchar(3),
      ContactID int
      )      
      
If Object_Id('Tempdb..##ProspectSoftAssociatedContactIDs') is not null
        Drop table ##ProspectSoftAssociatedContactIDs

select contactid
into ##ProspectSoftAssociatedContactIDs
from Consolidated.db.SourceEmail se
inner join Consolidated.db.ContactEmail ce
on se.ContactEmailID = ce.ContactEmailID
where sourceid = 74
union
select contactid
from Consolidated.db.ContactAddress
where sourceid = 74
union
select contactid
from Consolidated.db.SourceTelephone st
inner join Consolidated.db.ContactTelephone ct
on st.ContactTelephoneID = ct.ContactTelephoneID
where sourceid = 74
union
select c_contactid
from base.db.ContactConsolidatedIDs
where source = 'prospectsoft crm' --61066

-- Insert data into ETL_Staging.ETL.ToBeReConsolidated object

Insert ETL_Staging.ETL.ToBeReConsolidated (Source,SourceContactID,MarketCode,ContactID)
select source, SourceContactID, MarketCode, p.ContactID
from ##ProspectSoftAssociatedContactIDs p
inner join base.db.ContactConsolidatedIDs c
on p.ContactID = C_ContactID  --198291
go 

-- Remove all Consolidated data associated with ProspectSoft source
 
delete from Consolidated.db.SourceOpportunityContact 
where SourceContactID in 
( select sc.sourceContactID from Consolidated.db.SourceContact sc 
  inner join ETL_Staging.ETL.ToBeReConsolidated tbrc
  on sc.ContactID = tbrc.ContactID )  --68827
go

delete from Consolidated.db.SourceContact 
where ContactID in ( select ContactID from ETL_Staging.ETL.ToBeReConsolidated ) --50302
go

delete from Consolidated.db.ContactAddress 
where ContactID in ( select ContactID from ETL_Staging.ETL.ToBeReConsolidated ) --100130
go

delete from Consolidated.db.ContactCompany 
where ContactID in ( select ContactID from ETL_Staging.ETL.ToBeReConsolidated ) --84548
go

delete from Consolidated.db.ContactDemographic 
where ContactID in ( select ContactID from ETL_Staging.ETL.ToBeReConsolidated ) --673494
go

delete from Consolidated.DB.MembershipAttributeValue 
where MembershipID in (
  select MembershipID from Consolidated.db.Membership m
  inner join Consolidated.db.ContactEmail c 
  on m.ContactEmailID = c.ContactEmailID
  inner join ETL_Staging.ETL.ToBeReConsolidated tbrc
  on c.ContactID = tbrc.ContactID )  --2501
go
	
delete from Consolidated.db.Membership 
where ContactEmailID in 
( select ContactEmailID from Consolidated.db.ContactEmail c 
  inner join ETL_Staging.ETL.ToBeReConsolidated tbrc
  on c.ContactID = tbrc.ContactID ) --165847
go

delete from Consolidated.db.SourceEmail 
where ContactEmailID in 
( select ContactEmailID from Consolidated.db.ContactEmail c 
  inner join ETL_Staging.ETL.ToBeReConsolidated tbrc
  on c.ContactID = tbrc.ContactID ) --178647
go
  
delete from Consolidated.db.ContactDPASettingEmail 
where ContactEmailID in 
( select ContactEmailID from Consolidated.db.ContactEmail c 
  inner join ETL_Staging.ETL.ToBeReConsolidated tbrc
  on c.ContactID = tbrc.ContactID ) --141449 
go
  
delete from Consolidated.db.EmailSourceLastLoginDate 
where ContactEmailID in 
( select ContactEmailID from Consolidated.db.ContactEmail c 
  inner join ETL_Staging.ETL.ToBeReConsolidated tbrc
  on c.ContactID = tbrc.ContactID ) --1588
go

delete from Consolidated.db.ContactEmail 
where ContactID in ( select ContactID from ETL_Staging.ETL.ToBeReConsolidated ) --31585
go

delete from Consolidated.DB.ContactDPASettingEmail
where ContactTelephoneID in (
 select ContactTelephoneID from Consolidated.db.ContactTelephone ct 
 inner join ETL_Staging.ETL.ToBeReConsolidated tbrc 
 on ct.ContactID = tbrc.ContactID ) --1332
go

delete from Consolidated.db.ContactTelephone 
where ContactID in ( select ContactID from ETL_Staging.ETL.ToBeReConsolidated ) --41992
go

delete from Consolidated.db.SuppressAddress 
where ContactID in ( select ContactID from ETL_Staging.ETL.ToBeReConsolidated ) --0
go

delete from Consolidated.db.ContactDPASettingEmail 
where ContactID in ( select ContactID from ETL_Staging.ETL.ToBeReConsolidated ) --2166
go

delete from Consolidated.DB.MembershipAttributeValue 
where MembershipID in (
  select MembershipID from Consolidated.db.Membership m
  inner join ETL_Staging.ETL.ToBeReConsolidated tbrc
  on m.ContactID = tbrc.ContactID )  --112
go

delete from Consolidated.db.Membership 
where ContactID in ( select ContactID from ETL_Staging.ETL.ToBeReConsolidated ) --14917
go

delete from Consolidated.db.Contact 
where ContactID in ( select ContactID from ETL_Staging.ETL.ToBeReConsolidated ) --60227
go

delete from Consolidated.db.GetAllSupressAddressByCriteria 
where ContactID in ( select ContactID from ETL_Staging.ETL.ToBeReConsolidated ) --106765
go

delete from Consolidated.db.SourceCampaignMember 
where ContactID in ( select cast(ContactID as nvarchar(255)) from ETL_Staging.ETL.ToBeReConsolidated ) --0 
go

delete from Consolidated.db.SuppressTelemarketing 
where ContactID in ( select ContactID from ETL_Staging.ETL.ToBeReConsolidated ) --0   25:35 min
go

-- remove all ConsolidatedIDs from ContactConsolidatedIDs table 

use base
go

update base.db.ContactConsolidatedIDs
set C_ContactEmailID = null,
    C_ContactID = null,
    C_SourceEmailID = null,    
    C_ContactAddressID = null,
    C_ContactCompanyID = null,     
    C_ContactUsernameID = null,	   
	C_ContactTelephoneIDFax = null, 
	C_ContactTelephoneIDTelephone = null,
	C_ContactTelephoneIDMobile = null,  
	C_ContactTelephoneIDSMSMobile = null,
	ConsolidationGroupID = null
from base.db.ContactConsolidatedIDs c
left join Consolidated.db.ContactEmail ce
on c.C_ContactEmailID = ce.ContactEmailID
where ce.ContactEmailID is null
and c.C_ContactEmailID is not null  --638  00:21 sec
go


