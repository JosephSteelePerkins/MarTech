
-- with including DQ-57,68,BAU518,498


use base
GO

IF NOT EXISTS (select 1 FROM base.INFORMATION_SCHEMA.Columns WHERE TABLE_name = 'ContactConsolidatedIDs' and column_name = 'SourceCreateDate')
BEGIN
	ALTER TABLE DB.ContactConsolidatedIDs add SourceCreateDate datetime
END
GO

IF NOT EXISTS (select 1 FROM base.INFORMATION_SCHEMA.Columns WHERE TABLE_name = 'ContactConsolidatedIDs' and column_name = 'SourceLastUpdateDate')
BEGIN
	ALTER TABLE DB.ContactConsolidatedIDs add SourceLastUpdateDate datetime
END
GO

IF NOT EXISTS (SELECT 1 FROM Base.sys.indexes WHERE Name = 'x_ContactConsolidatedIDs')
BEGIN	
	CREATE NONCLUSTERED INDEX x_ContactConsolidatedIDs ON [DB].[ContactConsolidatedIDs] ([EmailAddress],[ConsolidationGroupID])
END	

GO

IF NOT EXISTS (SELECT 1 FROM Base.sys.indexes WHERE Name = 'x_ContactConsolidatedIDs2')
BEGIN	
	CREATE NONCLUSTERED INDEX x_ContactConsolidatedIDs2 ON [DB].[ContactConsolidatedIDs] ([ConsolidationGroupID]) INCLUDE ([Source],[MarketCode],[SourceContactID],[CreateDate],[LastUpdateDate],[FirstName],[LastName],[EmailAddress],[ContactAddress1],[ContactPostCode],[Telephone])
END	

GO

use Consolidated
GO
IF NOT EXISTS (select 1 FROM Consolidated.INFORMATION_SCHEMA.Columns WHERE TABLE_name = 'Contact' and column_name = 'ParentContactID')
  BEGIN
	 ALTER TABLE DB.Contact ADD ParentContactID INT
  END
GO

use Consolidated_Staging
GO

IF EXISTS (SELECT 1 FROM Consolidated_Staging.INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME='ContactIgnoreBeyondContactMatching')
	BEGIN
		DROP TABLE db.ContactIgnoreBeyondContactMatching
	END
GO
CREATE TABLE [DB].ContactIgnoreBeyondContactMatching(
	[Source] [nvarchar](100) NULL,
	SourceContactID [nvarchar] (50) NULL,
	[MarketCode] [nvarchar] (50) NULL,
	C_ContactID int)
GO



IF EXISTS (SELECT 1 FROM Consolidated_Staging.INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME='Contact')
DROP TABLE db.Contact
GO

CREATE TABLE [DB].[Contact](
	[ContactID] [int] identity(1,1) NOT NULL,
	[Source] [nvarchar](100) NULL,
	[SourceID] [int] NULL,
	[MarketCode] [nvarchar](3) NULL,
	[MarketID] [int] NULL,
	[SourceContactID] [nvarchar](50) NULL,
	[EmailAddress] [nvarchar](255) NULL,
	[CompanyName] [nvarchar](200) NULL,
	[ContactAddress1] [nvarchar](255) NULL,
	[ContactAddress2] [nvarchar](130) NULL,
	[ContactAddress3] [nvarchar](130) NULL,
	[ContactAddress4] [nvarchar](130) NULL,
	[ContactTown] [nvarchar](130) NULL,
	[ContactCounty] [nvarchar](130) NULL,
	[ContactPostCode] [nvarchar](130) NULL,
	[ContactCountryCode] [nvarchar](10) NULL,
	[ContactCountryName] [nvarchar](130) NULL,
	[Salutation] [nvarchar](10) NULL,
	[FirstName] [nvarchar](255) NULL,
	[LastName] [nvarchar](255) NULL,
	[Telephone] [nvarchar](128) NULL,
	[JobTitle] [nvarchar](500) NULL,
	[CreateDate] [datetime] NULL,
	[LastUpdateDate] [datetime] NULL,
	[Password] [nvarchar](128) NULL,
	[ValidEmailAddress] [nvarchar](5) NULL,
	[HTMLCapable] [nvarchar](5) NULL,
	[SoftBounceCount] [int] NULL,
	[HardBounceCount] [int] NULL,
	[LastBounced] [datetime] NULL,
	[MobileNumber] [nvarchar](50) NULL,
	[UserName] [nvarchar](255) NULL,
	[GroupName] [nvarchar](255) NULL,
	[Title] [nvarchar](100) NULL,
	[C_ContactAddressID] [int] NULL,
	[C_SourceEmailID] [int] NULL,
	[C_PreviousContactID] [int] NULL,
	[C_ContactID] [int] NULL,
	[C_ContactUsernameID] [int] NULL,
	[ConsolidationID] [varchar](20) NULL,
	[C_AddressID] [int] NULL,
	[C_ContactCompanyID] [int] NULL,
	[GreatestDate] [datetime] NULL,
	[AddressType] [nvarchar](100) NULL,
	[CompletnessID] [int] NULL,
	[SMSMobile] [nvarchar](50) NULL,
	[Fax] [nvarchar](128) NULL,
	[C_ContactTelephoneIDFax] [int] NULL,
	[C_ContactTelephoneIDTelephone] [int] NULL,
	[C_ContactTelephoneIDMobile] [int] NULL,
	[C_ContactTelephoneIDSMSMobile] [int] NULL,
	[Department] [nvarchar](200) NULL,
	[AddressQuality] [int] NULL,
	[TelephoneQuality] [int] NULL,
	[MobileQuality] [int] NULL,
	[SMSQuality] [int] NULL,
	[CountryCleaned] [nvarchar](100) NULL,
	[IsValidEmail] [bit] NULL,
	[DoNotUseEmail] [bit] NULL,
	[DoNotUseMobile] [bit] NULL,
	[DoNotUseTelephone] [bit] NULL,
	[DoNotUseSMSMobile] [bit] NULL,
	[DoNotUseAddress] [bit] NULL,
	[DoNotUseName] [bit] NULL,
	[C_ContactEmailID] [int] NULL,
	[C_PreviousContactEmailID] [int] NULL,
	[Status] [nvarchar](50) NULL,
	[ViperGUID] [nvarchar](200) NULL,
	[CreatedContact] [bit] NULL,
	[ParentMarketID] [int] NULL,
	[BaseDetail] [varchar](30) NULL,
	[SourceTable] [nvarchar](255) NULL,
	[LeadSourceMostRecent] [nvarchar](255) NULL,
	[OriginalLeadSource] [nvarchar](255) NULL,
	[ConvertedDate] [datetime] NULL,
	[ConvertedSourceContactID] [nvarchar](255) NULL,
	[SourceOpportunityID] [nvarchar](255) NULL,
	[CreatedBySourceOwnerID] [nvarchar](255) NULL,
	[ReasonForLoss] [nvarchar](255) NULL,
	[AccountID] [nvarchar](255) NULL,
	[OriginalSurName] [nvarchar](255) NULL,
	[OriginalFirstName] [nvarchar](255) NULL,
	[SourceOwnerID] [nvarchar](255) NULL,
	[C_CompanyID] [int] NULL,
	[ContactRole] [nvarchar](30) NULL,
	[EmailOwner] [int] NULL,
	[MasterScore] [int] NULL,
	[C_MasterRecord] [varchar](20) NULL,
	[Consolidated_ContactID] [int] NULL,
	[ThirdParty] [nvarchar](400) NULL,
	[MoreThan100] BIT,
	[IgnoreBeyondContactMatching] int
) ON [PRIMARY]
SET ANSI_PADDING OFF
ALTER TABLE [DB].[Contact] ADD [Gender] [char](1) NULL
ALTER TABLE [DB].[Contact] ADD [LastLogin] [datetime] NULL
SET ANSI_PADDING ON
ALTER TABLE [DB].[Contact] ADD [KeyDecisionMaker] [varchar](1) NULL
ALTER TABLE [DB].[Contact] ADD [ConsolidationGroupID] [int] NULL
ALTER TABLE [DB].[Contact] ADD [MasterLevel] [int] NULL
ALTER TABLE [DB].[Contact] ADD [ParentContactID] [int] NULL
ALTER TABLE [DB].[Contact] ADD [ParentContactID_Old] [int] NULL
ALTER TABLE [DB].[Contact] ADD [ComparisonFlag] [bit] NULL
ALTER TABLE [DB].[Contact] ADD [Matches] [int] NULL
PRIMARY KEY CLUSTERED 
(	[ContactID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO




-- update new fields

--drop table #base
GO
select *
into #base
from
(select source, sourcecontactid, marketcode, EmailAddress, FirstName,LastName,ContactAddress1,ContactPostCode,Telephone,CreateDate,LastUpdateDate
	, ROW_NUMBER() over(partition by source, sourcecontactid, marketcode order by auditdate desc) rowno
from base.db.contact(nolock)) x
where x.rowno = 1
GO
update base.db.ContactConsolidatedIDs
set CreateDate = b.CreateDate,
LastUpdateDate = b.LastUpdateDate
from base.db.ContactConsolidatedIDs cc
inner join #base b
on cc.source = b.Source
and cc.SourceContactID = b.SourceContactID
and cc.MarketCode = b.MarketCode
GO


USE Consolidated_Staging
go

If exists (select 1 from sys.procedures where name = 'up_NewContactID')
   drop procedure db.up_NewContactID
go

CREATE procedure [DB].[up_NewContactID] 
as 

SET NOCOUNT ON
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED


DECLARE @$prog VARCHAR(50), 
        @$errno INT, 
        @$errmsg VARCHAR(4000), 
        @$proc_section_nm VARCHAR(50),
        @$row_cnt INT,
        @$error_db_name VARCHAR(50)

SELECT @$errno = 0, 
       @$errmsg = NULL, 
       @$proc_section_nm = NULL,
       @$prog = LEFT(OBJECT_NAME(@@PROCID),50), 
       @$row_cnt = NULL,
       @$error_db_name = DB_NAME()

BEGIN TRY


Declare @NCID int, @Cnt int

select @Cnt = count(*) from Consolidated_Staging.db.Contact where ComparisonFlag = 1
print @Cnt

If @Cnt = 0

Begin

IF OBJECT_ID('tempdb..#NewContact') IS NOT NULL
drop table #NewContact

IF OBJECT_ID('tempdb..#NewContact_I') IS NOT NULL
drop table #NewContact_I


select Title,Firstname,LastName Surname,getdate() CreateDate,getdate() LastUpdateDate,CreateDate SourceCreateDate,
	   LastUpdateDate SourceLastUpdateDate,OriginalFirstName,OriginalSurName, ConsolidationID, ParentContactID, MasterLevel,ContactID,C_Contactid,'N' Flag
	   into #NewContact
from Consolidated_Staging.db.Contact
where MasterLevel > 1 --and FirstName is null and  LastName is null
order by FirstName,LastName

;with ml1 as 
(select ConsolidationID,ParentContactID,C_Contactid,Contactid from Consolidated_Staging.db.Contact where MasterLevel = 1),
ml2 as
(select ConsolidationID,ParentContactID,C_Contactid,Flag,Contactid,Surname from #NewContact)
Update ml2 set flag = 'Y' from ml1
inner join ml2 on ml1.ConsolidationID = ml2.ConsolidationID 
and ml1.ParentContactID = ml2.ParentContactID 
--and ml1.Contactid = ml2.ContactID

Update n set flag = 'E' from Consolidated.db.Contact C
INNER JOIN #NewContact n on c.Firstname = n.FirstName 
and c.Surname = n.Surname

select @NCID = IDENT_CURRENT('Consolidated.db.Contact')--max(ContactID) from Consolidated.db.Contact

Print @NCID

select @NCID+ ROW_NUMBER() OVER (ORDER BY ContactID) AS NContactID,Title,Firstname,Surname,CreateDate,LastUpdateDate,CreateDate SourceCreateDate,
	   LastUpdateDate SourceLastUpdateDate,OriginalFirstName,OriginalSurName, ConsolidationID, ParentContactID, MasterLevel,ContactID,C_Contactid,'N' Flag 
	   into #NewContact_I
from #NewContact where Flag = 'N'
order by ContactID--FirstName,Surname

insert into Consolidated.db.Contact (Title,Firstname,Surname,CreateDate,LastUpdateDate,SourceCreateDate,SourceLastUpdateDate,OriginalFirstName,OriginalSurName)
select Title,Firstname,Surname,CreateDate,LastUpdateDate,SourceCreateDate,SourceLastUpdateDate,OriginalFirstName,OriginalSurName from #NewContact_I
order by NContactID

;with ml1 as 
(select ConsolidationID,ParentContactID,C_Contactid,ContactID,ComparisonFlag
 from Consolidated_Staging.db.Contact),
 --where MasterLevel > 1),
ml2 as
(select ConsolidationID,ParentContactID,C_Contactid,ContactID,NContactID from #NewContact_I)
Update ml1 set --Contactid = ml2.NContactID,
C_ContactID = ml2.NContactID,ComparisonFlag = 1 from ml1
--ParentContactID = ml2.NContactID,ComparisonFlag = 1 from ml1
--inner join ml2 on ml1.ContactID = ml2.ContactID 
inner join ml2 on ml1.ConsolidationID = ml2.ConsolidationID 
and ml1.ParentContactID = ml2.ParentContactID 

End

/*
exec Consolidated_Staging.[DB].[up_NewContactID]

truncate table Consolidated_Staging.DB.Contact

select * from Consolidated_Staging.DB.Contact

insert into Consolidated_Staging.DB.Contact
Select * from [RBIQHSSQLP050\SQLLIVE01].Consolidated_Staging.DB.Contact

select Title,Firstname,LastName Surname,getdate() CreateDate,getdate() LastUpdateDate,Null ConsolidationID,CreateDate SourceCreateDate,
	   LastUpdateDate SourceLastUpdateDate,OriginalFirstName,OriginalSurName, ConsolidationID, ParentContactID
from Consolidated_Staging.db.Contact
where MasterLevel > 1 and FirstName is null and  LastName is null
order by FirstName,LastName


select * from #NewContact where flag = 'Y'

select ContactID,Flag,Title,Firstname,Surname,CreateDate,LastUpdateDate,SourceCreateDate,SourceLastUpdateDate,OriginalFirstName,OriginalSurName from #NewContact
where Firstname = 'Deborah' and Surname = 'Haygreen'


select ContactID,NContactID,Title,Firstname,Surname,CreateDate,LastUpdateDate,SourceCreateDate,SourceLastUpdateDate,OriginalFirstName,OriginalSurName from #NewContact_I
where Firstname = 'Deborah' and Surname = 'Haygreen'

select ContactID,Title,Firstname,Surname,CreateDate,LastUpdateDate,SourceCreateDate,SourceLastUpdateDate,OriginalFirstName,OriginalSurName 
from Consolidated.db.Contact 
where ContactID = 74065309
where Firstname = 'Deborah' and Surname = 'Haygreen'

select ContactID,Title,Firstname,LastName,CreateDate,LastUpdateDate,OriginalFirstName,OriginalSurName,MasterLevel,ParentContactID,ParentContactID_Old,ConsolidationID 
from Consolidated_Staging.db.Contact
where ConsolidationID = '1847409'--Firstname = 'Deborah' and LastName = 'Haygreen'
where Firstname = 'Deborah' and LastName = 'Haygreen'

select max(ContactID) from Consolidated.db.Contact --74067727

DBCC CHECKIDENT ('Consolidated.db.Contact', RESEED,74021241)

select  max(ContactID) from Consolidated.db.Contact --74021241

delete from Consolidated.db.Contact where contactId > 74021241

ALTER TABLE Consolidated.db.Contact NOCHECK CONSTRAINT ALL;
ALTER INDEX ALL ON Consolidated.db.Contact DISABLE;
ALTER INDEX ALL ON Consolidated.db.Contact REBUILD;
ALTER TABLE Consolidated.db.Contact CHECK CONSTRAINT ALL;
*/

End TRY


Begin Catch

	SET @$errmsg = LEFT('Error ' + CASE WHEN @$errno > 0 THEN CAST(@$errno as VARCHAR) 
	                                    ELSE CAST(ERROR_NUMBER() AS VARCHAR)
		                            END + ' in proc ' + ISNULL(@$prog,' ') + ' ' + 
		                           CASE WHEN @$errno > 0 THEN ISNULL(@$errmsg,' ') 
										ELSE ISNULL(@$errmsg,' ') + ISNULL(ERROR_MESSAGE(),'')
								   END ,4000)
	RAISERROR (@$errmsg, 16, 1)
	
	
	SET @$errno = ERROR_NUMBER()

END CATCH

SET NOCOUNT OFF



GO


Use [Consolidated_Staging]
go

If exists (select 1 from sys.procedures where name = 'up_ParentContactIDmt100')
   drop procedure db.up_ParentContactIDmt100
go

/****** Object:  StoredProcedure [DB].[up_ParentContactIDmt100]    Script Date: 11/14/2017 15:06:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [DB].[up_ParentContactIDmt100]
AS
SET NOCOUNT ON
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

DECLARE @$prog VARCHAR(50), 
        @$errno INT, 
        @$errmsg VARCHAR(4000), 
        @$proc_section_nm VARCHAR(50),
        @$row_cnt INT,
        @$error_db_name VARCHAR(50)

SELECT @$errno = 0, 
       @$errmsg = NULL, 
       @$proc_section_nm = NULL,
       @$prog = LEFT(OBJECT_NAME(@@PROCID),50), 
       @$row_cnt = NULL,
       @$error_db_name = DB_NAME()

BEGIN TRY

Declare @PID varchar(20),@SQL1 nvarchar(max)

-- CONTACT RECORDS THAT DON'T HAVE A PARENTCONTACTID, get all ConsolidationID that don't have a ParentContactID 

IF OBJECT_ID('tempdb..#CID') IS NOT NULL 
	DROP TABLE #CID

select distinct ConsolidationID
into #CID
from Consolidated_Staging.db.Contact 
where ParentContactID is null

-- create table to generate ParentContactIDs
If exists (select 1 from tempdb.sys.tables where name='##ParentContactID')
	DROP TABLE ##ParentContactID

set @PID = '1'
Select @PID = max(parentcontactid) from Consolidated_Staging.db.Contact with (nolock)

if @PID is null 
begin
	set @PID = '1'
end 

Set @SQL1 = 'Create table ##ParentContactID(
			 ContactID int,
			 Firstname nvarchar(100),
			 Lastname nvarchar(100),
			 EmailAddress nvarchar(255),
			 ParentContactID int identity('+@PID+', 1))'


exec sp_executesql @SQL1

select * from ##ParentContactID

-- reset
----update Consolidated_Staging.db.Contact
----set ParentContactID = null,
----MoreThan100 = null
----where MoreThan100 is not null

-- if firstname, lastname, email match an existing ParentcontactID then use that, include null first and lastnames
update Consolidated_Staging.db.Contact
set ParentContactID = c2.ParentContactID,
MoreThan100 = 1
from Consolidated_Staging.db.Contact c
inner join (select * from Consolidated_Staging.db.Contact) c2
on c.EmailAddress = c2.EmailAddress
and isnull(c.FirstName,'') = isnull(c2.FirstName,'')
and isnull(c.LastName,'') = isnull(c2.LastName,'')
and c.ConsolidationID = c2.ConsolidationID
where c.ParentContactID is null
and c2.ParentContactID is not null

-- if the record doesn't have a first name or last name then match with any ParentContactID with the email

update Consolidated_Staging.db.Contact
set ParentContactID = c2.ParentContactID,
MoreThan100 = 1
from Consolidated_Staging.db.Contact c
inner join (select * from Consolidated_Staging.db.Contact) c2
on c.EmailAddress = c2.EmailAddress
and c.ConsolidationID = c2.ConsolidationID
and c.FirstName is null
and c.LastName is null
where c.ParentContactID is null
and c2.ParentContactID is not null

-- if contact has a firstname, lastname and emailaddress that hasn't matched yet then create a new ParentContactID

insert into ##ParentContactID (Firstname, lastname, EmailAddress)
select distinct isnull(FirstName,''), isnull(LastName,''), EmailAddress
from Consolidated_Staging.db.Contact
where ParentContactID is null
and emailaddress is not null
and firstname is not null
and LastName is not null

update Consolidated_Staging.db.Contact
set ParentContactID = p.ParentContactID,
morethan100 = 1
from Consolidated_Staging.db.Contact c
inner join ##ParentContactID p
on isnull(c.FirstName,'') = isnull(p.Firstname,'')
and isnull(c.LastName,'') = isnull(p.lastname,'')
and c.EmailAddress = p.EmailAddress
where c.ParentContactID is null

-- everything else, generate a new ParentContactID

insert into ##ParentContactID(ContactID)
select contactid from Consolidated_Staging.db.contact where ParentContactID is null

update Consolidated_Staging.db.Contact
set ParentContactID = p.ParentContactID,
	morethan100 = 1
from Consolidated_Staging.db.contact c
inner join ##ParentContactID p
on c.contactid = p.ContactID

/*
select distinct c.ConsolidationID, 
	   source, 
	   c.FirstName, 
	   c.LastName, 
	   c.EmailAddress, 
	   ParentContactID, 
	   MasterScore, 
	   MoreThan100
from #CId d
inner join Consolidated_Staging.db.Contact c
on d.ConsolidationID = c.ConsolidationID
order by 1,5
*/


END TRY

BEGIN CATCH


	SET @$errmsg = LEFT('Error ' +
		CASE
			WHEN @$errno > 0 THEN 
				CAST(@$errno as VARCHAR)
			ELSE 
				CAST(ERROR_NUMBER() AS VARCHAR)
		END + ' in proc ' + ISNULL(@$prog,' ') + ' ' + 
		CASE 
			WHEN @$errno > 0 THEN 
				ISNULL(@$errmsg,' ') 
			ELSE 
				ISNULL(@$errmsg,' ') + ISNULL(ERROR_MESSAGE(),'')
		END ,4000)


	RAISERROR (@$errmsg, 16, 1)


	EXEC dbo.ERROR_LOG_2005 @ERROR_LOG_PROGRAM_NM = @$prog,  
							@ERROR_LOG_PROGRAM_SECTION_NM = @$proc_section_nm,
							@ERROR_LOG_ERROR_NO = @$errno,  
							@ERROR_LOG_ERROR_DSC = @$errmsg,
							@ERROR_DB_NAME = @$error_db_name
														

	IF(ISNULL(@$errno,0) = 0)
	BEGIN
		SET @$errno = ERROR_NUMBER()
	END

END CATCH

SET NOCOUNT OFF

RETURN  @$errno

GO


--++

USE [Consolidated_Staging]
GO
/****** Object:  StoredProcedure [DB].[up_ConsolidationGroupSplit]    Script Date: 11/02/2017 13:28:34 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

ALTER Procedure [DB].[up_ConsolidationGroupSplit]
as
Begin

--Print '1. ' + convert(varchar(50),Getdate(),120)


Update Consolidated_Staging.db.Contact
Set MasterLevel = 1,
	ParentContactID = c3.ContactID,
	ParentContactID_Old = c3.ContactID
from Consolidated_Staging.db.Contact c3
inner join 
(select ContactID from 
					(select ContactID,ROW_NUMBER() over (partition by ConsolidationID order by MasterScore desc, CreateDate desc) rownum
					from Consolidated_Staging.db.Contact) c1
					where rownum = 1) c2
on c3.ContactID = c2.ContactID

--Print '2. ' + convert(varchar(50),Getdate(),120)

/*
Update Consolidated_Staging.db.Contact
Set ComparisonFlag = 1
from Consolidated_Staging.db.Contact c3
inner join 
(select ContactID from 
					(select ContactID,ROW_NUMBER() over (partition by ConsolidationID order by ContactID) rownum
					from Consolidated_Staging.db.Contact
					where MasterLevel is null 
					and ParentContactID is null) c1
					where rownum = 1) c2
on c3.ContactID = c2.ContactID */

--Print '3. ' + convert(varchar(50),Getdate(),120)

Declare @i int,
		@l int = 0,
		@cnt int,
        @SQLTEXT nvarchar(max),
        @CMID int,
        @sQuery nvarchar(500),
        @wQuery1 nvarchar(500),
        @wQuery2 nvarchar(500),
        @wQuery3 nvarchar(4000)

set @i = isnull((select count(*) from Consolidated_Staging.db.Contact where ParentContactID is null),0)

while @i > 0 and @l <100

Begin

If exists (select 1 from tempdb.sys.tables where name='##contact')
	DROP TABLE ##contact

--Print '4. ' + convert(varchar(50),Getdate(),120)

;With cte1 as 
	(Select ContactID,Source,SourceID,MarketCode,SourceContactID,EmailAddress,Title,FirstName,LastName,Telephone,ContactAddress1,ContactPostcode,ConsolidationID,
		   EmailOwner,MasterScore,MasterLevel,ParentContactID,ParentContactID_Old,1 ComparisonFlag,Matches,ROW_NUMBER()over(partition by consolidationid order by contactid) prtid,Gender
	From  Consolidated_Staging.db.Contact
	where ParentContactID is null
	)
   ,cte2 as 	
    (
	Select ContactID,Source,SourceID,MarketCode,SourceContactID,EmailAddress,Title,FirstName,LastName,Telephone,ContactAddress1,ContactPostcode,ConsolidationID,
		   EmailOwner,MasterScore,MasterLevel,ParentContactID,ParentContactID_Old,1 ComparisonFlag,Matches,Gender
	From  Consolidated_Staging.db.Contact
	where MasterLevel is not null
	)
select ContactID,Source,SourceID,MarketCode,SourceContactID,EmailAddress,Title,FirstName,LastName,Telephone,ContactAddress1,ContactPostcode,ConsolidationID,
		   EmailOwner,MasterScore,MasterLevel,ParentContactID,ParentContactID_Old,ComparisonFlag,Matches,Gender
		   into ##contact
FROM cte2
union all 
select  ContactID,Source,SourceID,MarketCode,SourceContactID,EmailAddress,Title,FirstName,LastName,Telephone,ContactAddress1,ContactPostcode,ConsolidationID,
		   EmailOwner,MasterScore,MasterLevel,ParentContactID,ParentContactID_Old,ComparisonFlag,Matches,Gender
from cte1 
Where prtid = 1

--Print '5. ' + convert(varchar(50),Getdate(),120)

delete from ##contact 
where ConsolidationID not in (select ConsolidationID from Consolidated_Staging.db.Contact
							  where ParentContactID is null
							  group by ConsolidationID)
--select * from ##contact

--Print '5.1 ' + convert(varchar(50),Getdate(),120)

 
alter table ##contact add [rule] int
alter table ##contact add FIRSTNAME_L1 nvarchar(1)
alter table ##contact add EMAILADDRESS_L5 nvarchar(5)
alter table ##contact add TELEPHONE_L5 int
alter table ##contact add TELEPHONE_L8 int

--Print 'Standard Start ' + convert(varchar(50),Getdate(),120)

update ##contact set 
FIRSTNAME_L1 = left(FIRSTNAME,1),
EMAILADDRESS_L5 = left([ETL_Staging].[ETL].[fncharacternumber_Only](EMAILADDRESS),5),
TELEPHONE_L5 = left([ETL_Staging].[ETL].[fnNumbersOnly](TELEPHONE),5),
TELEPHONE_L8 = left([ETL_Staging].[ETL].[fnNumbersOnly](TELEPHONE),8)

--Print 'Standard End ' + convert(varchar(50),Getdate(),120)

Create INDEX IX_TitleFirstNameLastName on temp.dbo.##contact (Title,FIRSTNAME,LASTNAME)
Create INDEX IX_EmailAddress on temp.dbo.##contact (EMAILADDRESS)
Create INDEX IX_ConsolidationID on temp.dbo.##contact (ConsolidationID)
Create INDEX IX_ParentContactID on temp.dbo.##contact (ParentContactID)

--Print '6. ' + convert(varchar(50),Getdate(),120)

DECLARE CMR CURSOR FOR SELECT ContactMatchID,
                              SelectFilter,
                              WhereFilter1,
                              WhereFilter2,
                              WhereFilter3 
					   FROM Consolidated_Staging.db.ContactMatchingRules
					   where MatchingRule = 'Y' ORDER BY ContactMatchID
OPEN CMR
FETCH CMR INTO @CMID,@sQuery,@wQuery1,@wQuery2,@wQuery3
WHILE @@FETCH_STATUS = 0
BEGIN

--Print '7. ' + convert(varchar(50),Getdate(),120)

--SET @SQLTEXT = 'set @cnt = isnull((select count(*) FROM ##contact WHERE '+@wQuery2+' and parentcontactid is null),0)'
--SET @SQLTEXT = 'select '''+@cnt+''' = count(*) FROM ##contact WHERE '+@wQuery2+' and parentcontactid is null'
SET @SQLTEXT = ';with cte1 as 
	(SELECT '+@sQuery+' 
	 FROM ##contact 
	 WHERE '+@wQuery1+'
	 and MasterLevel is not null 
	),
	cte2 as 
	(SELECT * FROM ##contact
	 WHERE '+@wQuery2+'
	 and parentcontactid is null
	)
	select Top 1 c1.* into ##cnt
	from cte2 c2
	INNER JOIN (select * from cte1 where ROW_ID=1) c1 on c1.ConsolidationID=c2.ConsolidationID
	where '+@wQuery3+''
Exec sp_executesql @SQLTEXT 
--Print @SQLTEXT

set @cnt = isnull((select count(*) from ##cnt),0)

--PRINT '@cnt1 ' + convert(varchar(10),@cnt)

if @cnt > 0
BEGIN
	SET @SQLTEXT = ';with cte1 as 
	(SELECT '+@sQuery+' 
	 FROM ##contact 
	 WHERE '+@wQuery1+'
	 and MasterLevel is not null 
	),
	cte2 as 
	(SELECT * FROM ##contact
	 WHERE '+@wQuery2+'
	 and parentcontactid is null
	)
	update c2
	set c2.parentcontactid=c1.parentcontactid,c2.ParentContactID_Old= c1.parentcontactid,c2.[rule] = '+convert(varchar(20),@CMID)+'
	from cte2 c2
	INNER JOIN (select * from cte1 where ROW_ID=1) c1 on c1.ConsolidationID=c2.ConsolidationID
	where '+@wQuery3+''
	Exec sp_executesql @SQLTEXT 
	--Print @SQLTEXT

	--Print '8. ' + convert(varchar(50),Getdate(),120)

	--Print @CMID
END
	
set @cnt = isnull((select count(*) from ##contact where ParentContactID is null),0)

If exists (select 1 from tempdb.sys.tables where name='##cnt')
	DROP TABLE ##cnt

--PRINT '@cnt2 ' + convert(varchar(10),@cnt)

if @cnt = 0 
BEGIN
	--SET @@FETCH_STATUS = 0
	BREAK;
End

FETCH CMR INTO @CMID,@sQuery,@wQuery1,@wQuery2,@wQuery3
END
CLOSE CMR DEALLOCATE CMR

/*
;with cte1 as 
	(SELECT consolidationid,EMAILADDRESS,ParentContactID
	 FROM ##contact
	 WHERE FIRSTNAME IS NOT NULL AND LASTNAME IS NOT NULL AND EMAILADDRESS IS NOT NULL
	 and ParentContactID is not null
	 Group by consolidationid,EMAILADDRESS,ParentContactID
	),
	cte2 as 
	(SELECT ConsolidationID,EmailAddress ,parentcontactid
 	 FROM ##contact
	 WHERE EMAILADDRESS IS NOT NULL
	 AND LASTNAME IS NULL 
	 AND FIRSTNAME IS NULL 
	 AND CONTACTADDRESS1 IS NULL 
	 AND CONTACTPOSTCODE IS NULL 
	 AND TELEPHONE IS NULL
	 and parentcontactid is NULL 
	)
	update c2 set c2.parentcontactid=c1.parentcontactid
	from cte2 c2
	INNER JOIN cte1 c1 on c1.ConsolidationID=c2.ConsolidationID
	where [ETL_Staging].[ETL].[fncharacternumber_Only](C1.EMAILADDRESS)=[ETL_Staging].[ETL].[fncharacternumber_Only](C2.EMAILADDRESS)
*/

--Print '1'

;with masterscore as
(SELECT ConsolidationID,MAX(MasterLevel)+1  MasterLevel
 FROM ##contact
 where MasterLevel is not null 
 group by ConsolidationID
)
update c1
set c1.parentcontactid=c1.contactID,c1.ParentContactID_Old = c1.contactID,c1.MasterLevel=m1.MasterLevel--,c1.Matches = 999--cd.[rule]
from  (select * from ##contact 
	   where parentcontactid is null
	   ) c1
Inner Join masterscore m1 on m1.ConsolidationID=c1.ConsolidationID

--Print '9. ' + convert(varchar(50),Getdate(),120)

Update C SET parentcontactid = cd.parentcontactid,ParentContactID_Old = cd.ParentContactID,MasterLevel = cd.MasterLevel,C.Matches = cd.[rule], ComparisonFlag = null
from ##Contact cd
inner join Consolidated_Staging.db.Contact c on cd.contactID = c.contactID
where c.parentcontactid is null

--Print '10. ' + convert(varchar(50),Getdate(),120)

--If exists (select 1 from tempdb.sys.tables where name='##contact')
--	DROP TABLE ##contact

set @i = isnull((select count(*) from Consolidated_Staging.db.Contact where ParentContactID is null),0)
;with ct as 
(select COUNT(*) total from Consolidated_Staging.db.Contact where ParentContactID is not null group by ConsolidationID) 
select @l = MAX(total) from ct

--Print '11. ' + convert(varchar(50),Getdate(),120)

End

DECLARE MGR CURSOR FOR SELECT ContactMatchID,
                              SelectFilter,
                              WhereFilter1,
                              WhereFilter2
					   FROM Consolidated_Staging.db.ContactMatchingRules
					   where MatchingRule = 'M' 
OPEN MGR
FETCH MGR INTO @CMID,@sQuery,@wQuery1,@wQuery2
WHILE @@FETCH_STATUS = 0
BEGIN

--Print '12. ' + convert(varchar(50),Getdate(),120)

SET @SQLTEXT = ';with mergeParent as
(SELECT '+@sQuery+' 
 FROM Consolidated_Staging.db.Contact 
 WHERE '+@wQuery1+'
)
update c1
set c1.parentcontactid=m1.PID
from Consolidated_Staging.db.Contact c1
'+@wQuery2+''
Exec sp_executesql @SQLTEXT 
--Print @SQLTEXT

--Print '13. ' + convert(varchar(50),Getdate(),120)

--Print @CMID

FETCH MGR INTO @CMID,@sQuery,@wQuery1,@wQuery2
END
CLOSE MGR DEALLOCATE MGR

--Exec Consolidated_Staging.[DB].[up_NewContactID] 
Exec Consolidated_Staging.[DB].[up_ParentContactIDmt100]

End

GO

Truncate table [Consolidated_Staging].[DB].[ContactMatchingRules]

Go

USE [Consolidated_Staging]
GO

/****** Object:  Table [DB].[ContactMatchingRules]    Script Date: 01/02/2018 11:03:18 ******/
SET IDENTITY_INSERT [DB].[ContactMatchingRules] ON
INSERT [DB].[ContactMatchingRules] ([ContactMatchID], [ContactMatchedRule], [SelectFilter], [WhereFilter1], [WhereFilter2], [WhereFilter3], [MatchingRule]) VALUES (1, N'IF BOTH ONLY HAVE AN EMAILADDRESS THEN THEY CAN MATCH', N'ROW_NUMBER() OVER(PARTITION BY consolidationid,EMAILADDRESS ORDER BY masterscore desc) ROW_ID,* ', N'TITLE IS NULL AND  FIRSTNAME IS NULL AND  LASTNAME IS NULL AND  EMAILADDRESS_L5 IS NOT NULL', N'TITLE IS NULL AND  FIRSTNAME IS NULL AND  LASTNAME IS NULL AND  EMAILADDRESS_L5 IS NOT NULL', N'C1.EMAILADDRESS=C2.EMAILADDRESS', N'Y')
INSERT [DB].[ContactMatchingRules] ([ContactMatchID], [ContactMatchedRule], [SelectFilter], [WhereFilter1], [WhereFilter2], [WhereFilter3], [MatchingRule]) VALUES (2, N'EMAILADDRESS AND FIRSTNAME CAN MATCH IF THERE IS NO CONFLICT ON LASTNAME OR GENDER', N'ROW_NUMBER() OVER(PARTITION BY consolidationid,EMAILADDRESS,FIRSTNAME,LASTNAME ORDER BY masterscore desc) ROW_ID,* ', N'TITLE IS NOT NULL AND FIRSTNAME_L1 IS NOT NULL AND  (LASTNAME IS NOT NULL OR GENDER IS NOT NULL) AND  EMAILADDRESS_L5 IS NOT NULL', N'TITLE IS NOT NULL AND FIRSTNAME_L1 IS NOT NULL AND  (LASTNAME IS NOT NULL OR GENDER IS NOT NULL) AND  EMAILADDRESS_L5 IS NOT NULL', N'C1.EMAILADDRESS=C2.EMAILADDRESS AND  C1.FIRSTNAME=C2.FIRSTNAME AND  (C1.LASTNAME=C2.LASTNAME OR C1.GENDER=C2.GENDER)', N'Y')
INSERT [DB].[ContactMatchingRules] ([ContactMatchID], [ContactMatchedRule], [SelectFilter], [WhereFilter1], [WhereFilter2], [WhereFilter3], [MatchingRule]) VALUES (3, N'EXACT MATCH', N'ROW_NUMBER() OVER(PARTITION BY consolidationid,EMAILADDRESS,FIRSTNAME,LASTNAME ORDER BY masterscore desc )ROW_ID,* ', N'FIRSTNAME_L1 IS NOT NULL AND  LASTNAME IS NOT NULL AND  EMAILADDRESS_L5 IS NOT NULL', N'FIRSTNAME_L1 IS NOT NULL AND  LASTNAME IS NOT NULL AND  EMAILADDRESS_L5 IS NOT NULL', N'C1.EMAILADDRESS=C2.EMAILADDRESS AND  C1.FIRSTNAME=C2.FIRSTNAME AND  C1.LASTNAME=C2.LASTNAME AND ISNULL(C1.GENDER,'''') = ISNULL(C2.GENDER,'''')', N'Y')
INSERT [DB].[ContactMatchingRules] ([ContactMatchID], [ContactMatchedRule], [SelectFilter], [WhereFilter1], [WhereFilter2], [WhereFilter3], [MatchingRule]) VALUES (4, N'EMAILADDRESS AND LASTNAME CANNOT MATCH IF NEITHER HAVE AN INITIAL', N'ROW_NUMBER() OVER(PARTITION BY consolidationid,EMAILADDRESS,LASTNAME ORDER BY masterscore desc )ROW_ID,* ', N'TITLE IS NOT NULL AND  FIRSTNAME IS NULL AND  LASTNAME IS NOT NULL AND  EMAILADDRESS_L5 IS NOT NULL', N'TITLE IS NOT NULL AND  FIRSTNAME IS NULL AND  LASTNAME IS NOT NULL AND  EMAILADDRESS_L5 IS NOT NULL', N'C1.EMAILADDRESS=C2.EMAILADDRESS AND  C1.LASTNAME=C2.LASTNAME', N'Y')
INSERT [DB].[ContactMatchingRules] ([ContactMatchID], [ContactMatchedRule], [SelectFilter], [WhereFilter1], [WhereFilter2], [WhereFilter3], [MatchingRule]) VALUES (5, N'EMAILADDRESS AND LASTNAME CANNOT MATCH IF NEITHER HAVE AN INITIAL - TITLE NOT CONSIDERED', N'ROW_NUMBER() OVER(PARTITION BY consolidationid,EMAILADDRESS,LASTNAME ORDER BY masterscore desc )ROW_ID,* ', N'FIRSTNAME IS NULL AND  LASTNAME IS NOT NULL AND  EMAILADDRESS_L5 IS NOT NULL', N'FIRSTNAME IS NULL AND  LASTNAME IS NOT NULL AND  EMAILADDRESS_L5 IS NOT NULL', N'C1.EMAILADDRESS=C2.EMAILADDRESS AND  C1.LASTNAME=C2.LASTNAME', N'N')
INSERT [DB].[ContactMatchingRules] ([ContactMatchID], [ContactMatchedRule], [SelectFilter], [WhereFilter1], [WhereFilter2], [WhereFilter3], [MatchingRule]) VALUES (6, N'ONLY SURNAME, TITLE NOT NULL AND FIRSTNAME LEFT OF 1 ', N'ROW_NUMBER() OVER(PARTITION BY consolidationid,EMAILADDRESS,LASTNAME,FIRSTNAME_L1 ORDER BY masterscore desc )ROW_ID,* ', N'TITLE IS NOT NULL AND  LASTNAME IS NOT NULL AND  EMAILADDRESS_L5 IS NOT NULL', N'TITLE IS NOT NULL AND  LASTNAME IS NOT NULL AND  EMAILADDRESS_L5 IS NOT NULL', N'C1.EMAILADDRESS=C2.EMAILADDRESS AND  C1.FIRSTNAME_L1=C2.FIRSTNAME_L1 AND  C1.LASTNAME=C2.LASTNAME', N'Y')
INSERT [DB].[ContactMatchingRules] ([ContactMatchID], [ContactMatchedRule], [SelectFilter], [WhereFilter1], [WhereFilter2], [WhereFilter3], [MatchingRule]) VALUES (7, N'ONLY SURNAME, EMAILADDRESS AND FIRSTNAME LEFT OF 1', N'ROW_NUMBER() OVER(PARTITION BY consolidationid,EMAILADDRESS,LASTNAME,FIRSTNAME_L1 ORDER BY masterscore desc )ROW_ID,* ', N'FIRSTNAME IS NOT NULL AND  LASTNAME IS NOT NULL AND  EMAILADDRESS_L5 IS NOT NULL', N'LEN(ISNULL(FIRSTNAME,'''')) = 1 AND  LASTNAME IS NOT NULL AND  EMAILADDRESS_L5 IS NOT NULL', N'C1.EMAILADDRESS=C2.EMAILADDRESS AND  C1.FIRSTNAME_L1=C2.FIRSTNAME_L1 AND  C1.LASTNAME=C2.LASTNAME AND  ISNULL(C1.GENDER,'''') = ISNULL(C2.GENDER,'''')', N'Y')
INSERT [DB].[ContactMatchingRules] ([ContactMatchID], [ContactMatchedRule], [SelectFilter], [WhereFilter1], [WhereFilter2], [WhereFilter3], [MatchingRule]) VALUES (8, N'EMAILADDRESS IS NULL AND INITIAL FIRSTNAME AND SURNAME MATCH', N'ROW_NUMBER() OVER(PARTITION BY consolidationid,FIRSTNAME_L1,LASTNAME ORDER BY masterscore desc )ROW_ID,* ', N'LEN(FIRSTNAME) > 1 AND LASTNAME IS NOT NULL AND (EMAILADDRESS_L5 IS NOT NULL OR EMAILADDRESS_L5 IS NULL)', N'LEN(ISNULL(FIRSTNAME,'''')) = 1 AND LASTNAME IS NOT NULL AND (EMAILADDRESS_L5 IS NOT NULL OR EMAILADDRESS_L5 IS NULL)', N'C1.FIRSTNAME_L1=C2.FIRSTNAME_L1 AND C1.LASTNAME=C2.LASTNAME', N'Y')
INSERT [DB].[ContactMatchingRules] ([ContactMatchID], [ContactMatchedRule], [SelectFilter], [WhereFilter1], [WhereFilter2], [WhereFilter3], [MatchingRule]) VALUES (9, N'EMAILADDRESS CAN MATCH IF ONE HAS ONLY AN EMAILADDRESS (SEE ABOVE FOR WHY THIS IS ACCEPTABLE.)', N'ROW_NUMBER() OVER(PARTITION BY consolidationid,EMAILADDRESS  ORDER BY masterscore desc )ROW_ID,* ', N'EMAILADDRESS_L5 IS NOT NULL  AND  TITLE IS NULL AND  FIRSTNAME IS NULL AND  LASTNAME IS NULL', N'EMAILADDRESS_L5 IS NOT NULL  AND  TITLE IS NULL AND  FIRSTNAME IS NULL AND  LASTNAME IS NULL', N'C1.EMAILADDRESS=C2.EMAILADDRESS', N'Y')
INSERT [DB].[ContactMatchingRules] ([ContactMatchID], [ContactMatchedRule], [SelectFilter], [WhereFilter1], [WhereFilter2], [WhereFilter3], [MatchingRule]) VALUES (10, N'EMAILADDRESS CAN MATCH IF ONE HAS ONLY AN EMAILADDRESS (SEE ABOVE FOR WHY THIS IS ACCEPTABLE.) - TITLE NOT CONSIDERED', N'ROW_NUMBER() OVER(PARTITION BY consolidationid,EMAILADDRESS ORDER BY masterscore desc )ROW_ID,* ', N'EMAILADDRESS_L5 IS NOT NULL AND  FIRSTNAME IS NOT NULL AND  LASTNAME IS NOT NULL', N'FIRSTNAME IS NULL AND  LASTNAME IS NULL AND  EMAILADDRESS_L5 IS NOT NULL', N'C1.EMAILADDRESS=C2.EMAILADDRESS', N'Y')
INSERT [DB].[ContactMatchingRules] ([ContactMatchID], [ContactMatchedRule], [SelectFilter], [WhereFilter1], [WhereFilter2], [WhereFilter3], [MatchingRule]) VALUES (11, N'EMAILADDRESS AND LASTNAME CAN MATCH IF ONE HAS AN INITIAL AND THE OTHER DOESN''T (SEE ABOVE FOR WHY THIS IS ACCEPTABLE.)', N'ROW_NUMBER() OVER(PARTITION BY consolidationid,EMAILADDRESS,LASTNAME  ORDER BY masterscore desc )ROW_ID,* ', N'EMAILADDRESS_L5 IS NOT NULL AND  FIRSTNAME IS NOT NULL AND  LASTNAME IS NOT NULL', N'TITLE IS NULL  AND  FIRSTNAME IS NULL AND  LASTNAME IS NOT NULL AND  EMAILADDRESS_L5 IS NOT NULL', N'C1.EMAILADDRESS=C2.EMAILADDRESS AND  C1.LASTNAME=C2.LASTNAME', N'Y')
INSERT [DB].[ContactMatchingRules] ([ContactMatchID], [ContactMatchedRule], [SelectFilter], [WhereFilter1], [WhereFilter2], [WhereFilter3], [MatchingRule]) VALUES (12, N'EMAILADDRESS AND LASTNAME CAN MATCH IF ONE HAS AN INITIAL AND THE OTHER DOESNT (SEE ABOVE FOR WHY THIS IS ACCEPTABLE.)', N'ROW_NUMBER() OVER(PARTITION BY consolidationid,EMAILADDRESS,LASTNAME ORDER BY masterscore desc )ROW_ID,* ', N'EMAILADDRESS_L5 IS NOT NULL AND  FIRSTNAME IS NULL', N'LEN(ISNULL(FIRSTNAME,'''')) = 1  AND  EMAILADDRESS_L5 IS NOT NULL', N'C1.EMAILADDRESS=C2.EMAILADDRESS AND  C1.LASTNAME=C2.LASTNAME', N'Y')
INSERT [DB].[ContactMatchingRules] ([ContactMatchID], [ContactMatchedRule], [SelectFilter], [WhereFilter1], [WhereFilter2], [WhereFilter3], [MatchingRule]) VALUES (13, N'EMAILADDRESS AND FIRSTNAME CAN MATCH IF THERE IS NO CONFLICT ON LASTNAME OR GENDER', N'ROW_NUMBER() OVER(PARTITION BY consolidationid,EMAILADDRESS,FIRSTNAME  ORDER BY masterscore desc )ROW_ID,* ', N'TITLE IS NOT NULL AND  FIRSTNAME_L1 IS NOT NULL AND  (LASTNAME IS NULL OR GENDER IS NOT NULL) AND  EMAILADDRESS_L5 IS NOT NULL', N'TITLE IS NOT NULL AND FIRSTNAME_L1 IS NOT NULL AND  (LASTNAME IS NOT NULL OR GENDER IS NULL)  AND  EMAILADDRESS_L5 IS NOT NULL', N'C1.EMAILADDRESS=C2.EMAILADDRESS  AND  C1.FIRSTNAME =C2.FIRSTNAME', N'Y')
INSERT [DB].[ContactMatchingRules] ([ContactMatchID], [ContactMatchedRule], [SelectFilter], [WhereFilter1], [WhereFilter2], [WhereFilter3], [MatchingRule]) VALUES (14, N'FIRSTNAME, LASTNAME AND TELEPHONE ALWAYS MATCH', N'ROW_NUMBER() OVER(PARTITION BY consolidationid,TELEPHONE,FIRSTNAME,LASTNAME  ORDER BY masterscore desc )ROW_ID,* ', N'FIRSTNAME_L1 IS NOT NULL AND  LASTNAME IS NOT NULL AND  TELEPHONE_L5 IS NOT NULL', N'FIRSTNAME_L1 IS NOT NULL AND  LASTNAME IS NOT NULL AND  TELEPHONE_L5 IS NOT NULL', N'C1.TELEPHONE=C2.TELEPHONE AND  C1.FIRSTNAME =C2.FIRSTNAME AND  C1.LASTNAME=C2.LASTNAME', N'Y')
INSERT [DB].[ContactMatchingRules] ([ContactMatchID], [ContactMatchedRule], [SelectFilter], [WhereFilter1], [WhereFilter2], [WhereFilter3], [MatchingRule]) VALUES (15, N'EMAILADDRESS AND FIRSTNAME CAN MATCH IF THERE IS NO CONFLICT ON LASTNAME OR GENDER', N'ROW_NUMBER() OVER(PARTITION BY consolidationid,EMAILADDRESS,FIRSTNAME  ORDER BY masterscore desc )ROW_ID,* ', N'FIRSTNAME IS NOT NULL AND  LASTNAME IS NOT NULL AND  EMAILADDRESS_L5 IS NOT NULL', N'FIRSTNAME IS NOT NULL AND  LASTNAME IS NULL AND  EMAILADDRESS_L5 IS NOT NULL', N'C1.EMAILADDRESS=C2.EMAILADDRESS  AND  C1.FIRSTNAME =C2.FIRSTNAME', N'Y')
INSERT [DB].[ContactMatchingRules] ([ContactMatchID], [ContactMatchedRule], [SelectFilter], [WhereFilter1], [WhereFilter2], [WhereFilter3], [MatchingRule]) VALUES (16, N'EMAILADDRESS IS NOT NULL AND ALL OTHER FIELDS IS NULL MATCH', N'ROW_NUMBER() OVER(PARTITION BY consolidationid,EMAILADDRESS ORDER BY masterscore desc )ROW_ID,* ', N'FIRSTNAME IS NOT NULL AND LASTNAME IS NOT NULL AND EMAILADDRESS LIKE ''%@%''', N'EMAILADDRESS LIKE ''%@%'' AND FIRSTNAME IS NULL AND LASTNAME IS NULL AND CONTACTADDRESS1 IS NULL AND CONTACTPOSTCODE IS NULL AND TELEPHONE IS NULL', N'replace([ETL_Staging].[ETL].[fncharacternumber_Only](LEFT(C1.EMAILADDRESS,PATINDEX(''%@%'',C1.EMAILADDRESS)-1)),''_'','''')=replace([ETL_Staging].[ETL].[fncharacternumber_Only](LEFT(C1.EMAILADDRESS,PATINDEX(''%@%'',C2.EMAILADDRESS)-1)),''_'','''')', N'Y')
INSERT [DB].[ContactMatchingRules] ([ContactMatchID], [ContactMatchedRule], [SelectFilter], [WhereFilter1], [WhereFilter2], [WhereFilter3], [MatchingRule]) VALUES (17, N'FIRSTNAME & EMAILADDRESS CAN MATCH IF THERE IS NO CONFLICT IN LASTNAME OR GENDER', N'ROW_NUMBER() OVER(PARTITION BY consolidationid,EMAILADDRESS,FIRSTNAME  ORDER BY masterscore desc )ROW_ID,* ', N'FIRSTNAME IS NOT NULL AND  LASTNAME IS NULL AND  EMAILADDRESS_L5 IS NOT NULL', N'FIRSTNAME IS NOT NULL AND  LASTNAME IS NOT NULL AND  EMAILADDRESS_L5 IS NOT NULL', N'C1.EMAILADDRESS=C2.EMAILADDRESS  AND  C1.FIRSTNAME =C2.FIRSTNAME', N'Y')
INSERT [DB].[ContactMatchingRules] ([ContactMatchID], [ContactMatchedRule], [SelectFilter], [WhereFilter1], [WhereFilter2], [WhereFilter3], [MatchingRule]) VALUES (18, N'LASTNAME, TELEPHONE AND INITIAL CANNOT MATCH', N'ROW_NUMBER() OVER(PARTITION BY consolidationid,EMAILADDRESS,LASTNAME,FIRSTNAME_L1 ORDER BY masterscore desc )ROW_ID,* ', N'FIRSTNAME IS NOT NULL AND  LASTNAME IS NOT NULL AND  TELEPHONE_L5 IS NOT NULL', N'FIRSTNAME IS NOT NULL AND  LASTNAME IS NOT NULL AND  TELEPHONE_L5 IS NOT NULL', N'C1.TELEPHONE=C2.TELEPHONE AND  C1.FIRSTNAME_L1=C2.FIRSTNAME_L1 AND  C1.LASTNAME=C2.LASTNAME', N'N')
INSERT [DB].[ContactMatchingRules] ([ContactMatchID], [ContactMatchedRule], [SelectFilter], [WhereFilter1], [WhereFilter2], [WhereFilter3], [MatchingRule]) VALUES (19, N'FIRSTNAME, LASTNAME AND TELEPHONE RIGHT OF 8 ALWAYS MATCH', N'ROW_NUMBER() OVER(PARTITION BY consolidationid,TELEPHONE_L8,FIRSTNAME,LASTNAME  ORDER BY masterscore desc )ROW_ID,* ', N'FIRSTNAME_L1 IS NOT NULL AND  LASTNAME IS NOT NULL AND  TELEPHONE_L5 IS NOT NULL', N'FIRSTNAME_L1 IS NOT NULL AND  LASTNAME IS NOT NULL AND  TELEPHONE_L5 IS NOT NULL', N'C1.TELEPHONE_L8=C2.TELEPHONE_L8 AND  C1.FIRSTNAME =C2.FIRSTNAME AND  C1.LASTNAME=C2.LASTNAME', N'N')
INSERT [DB].[ContactMatchingRules] ([ContactMatchID], [ContactMatchedRule], [SelectFilter], [WhereFilter1], [WhereFilter2], [WhereFilter3], [MatchingRule]) VALUES (20, N'LASTNAME, TELEPHONE AND INITIAL CANNOT MATCH - RIGHT8', N'ROW_NUMBER() OVER(PARTITION BY consolidationid,TELEPHONE_L8,FIRSTNAME_L1,LASTNAME  ORDER BY masterscore desc )ROW_ID,* ', N'FIRSTNAME IS NOT NULL AND  LASTNAME IS NOT NULL AND  TELEPHONE_L5 IS NOT NULL', N'FIRSTNAME IS NOT NULL AND  LASTNAME IS NOT NULL AND  TELEPHONE_L5 IS NOT NULL', N'C1.TELEPHONE_L8=C2.TELEPHONE_L8 AND  C1.FIRSTNAME_L1=C2.FIRSTNAME_L1 AND  C1.LASTNAME=C2.LASTNAME', N'N')
INSERT [DB].[ContactMatchingRules] ([ContactMatchID], [ContactMatchedRule], [SelectFilter], [WhereFilter1], [WhereFilter2], [WhereFilter3], [MatchingRule]) VALUES (21, N'EMAILADDRESS AND FIRSTNAME CAN MATCH IF THERE IS NO CONFLICT ON LASTNAME OR GENDER', N'ROW_NUMBER() OVER(PARTITION BY consolidationid,EMAILADDRESS,FIRSTNAME  ORDER BY masterscore desc )ROW_ID,* ', N'FIRSTNAME_L1 IS NOT NULL AND  LASTNAME IS NULL AND  GENDER IS NOT NULL AND  EMAILADDRESS_L5 IS NOT NULL', N'FIRSTNAME_L1 IS NOT NULL AND  LASTNAME IS NULL AND  GENDER IS NULL  AND  EMAILADDRESS_L5 IS NOT NULL', N'C1.EMAILADDRESS=C2.EMAILADDRESS  AND  C1.FIRSTNAME =C2.FIRSTNAME', N'Y')
INSERT [DB].[ContactMatchingRules] ([ContactMatchID], [ContactMatchedRule], [SelectFilter], [WhereFilter1], [WhereFilter2], [WhereFilter3], [MatchingRule]) VALUES (22, N'EMAILADDRESS AND FIRSTNAME CAN MATCH IF THERE IS NO CONFLICT ON LASTNAME OR GENDER', N'ROW_NUMBER() OVER(PARTITION BY consolidationid,EMAILADDRESS,FIRSTNAME  ORDER BY masterscore desc )ROW_ID,* ', N'FIRSTNAME_L1 IS NOT NULL AND  LASTNAME IS NULL AND  GENDER IS NOT NULL AND  EMAILADDRESS_L5 IS NOT NULL', N'FIRSTNAME_L1 IS NOT NULL AND  LASTNAME IS NULL AND  GENDER IS NOT NULL  AND  EMAILADDRESS_L5 IS NOT NULL', N'C1.EMAILADDRESS=C2.EMAILADDRESS  AND  C1.FIRSTNAME =C2.FIRSTNAME AND  C1.GENDER = C2.GENDER', N'Y')
INSERT [DB].[ContactMatchingRules] ([ContactMatchID], [ContactMatchedRule], [SelectFilter], [WhereFilter1], [WhereFilter2], [WhereFilter3], [MatchingRule]) VALUES (23, N'FIRSTNAME, LASTNAME, ADDRESSLINE1 AND POSTCODE ALWAYS MATCH', N'ROW_NUMBER() OVER(PARTITION BY FIRSTNAME,LASTNAME,CONTACTADDRESS1,CONTACTPOSTCODE ORDER BY CONTACTADDRESS1)ROW_ID ,* ', N'FIRSTNAME_L1 IS NOT NULL AND  LASTNAME IS NOT NULL AND  CONTACTADDRESS1 IS NOT NULL AND  CONTACTPOSTCODE IS NOT NULL', N'FIRSTNAME_L1 IS NOT NULL AND  LASTNAME IS NOT NULL AND  CONTACTADDRESS1 IS NOT NULL AND  CONTACTPOSTCODE IS NOT NULL', N'C1.CONTACTADDRESS1=C2.CONTACTADDRESS1 AND  C1.CONTACTPOSTCODE=C2.CONTACTPOSTCODE AND  C1.LASTNAME=C2.LASTNAME AND  C1.FIRSTNAME=C2.FIRSTNAME', N'Y')
INSERT [DB].[ContactMatchingRules] ([ContactMatchID], [ContactMatchedRule], [SelectFilter], [WhereFilter1], [WhereFilter2], [WhereFilter3], [MatchingRule]) VALUES (24, N'FIRSTNAME, LASTNAME AND TELEPHONE MATCHES EVEN THERE''S CONFLICT ON EMAILADDRESS', N'ROW_NUMBER() OVER(PARTITION BY consolidationid,TELEPHONE,FIRSTNAME,LASTNAME  ORDER BY masterscore desc )ROW_ID,* ', N'FIRSTNAME IS NOT NULL AND  LASTNAME IS NOT NULL AND  TELEPHONE_L5 IS NOT NULL', N'FIRSTNAME IS NOT NULL AND  LASTNAME IS NOT NULL AND  TELEPHONE_L5 IS NOT NULL', N'C1.TELEPHONE=C2.TELEPHONE  AND  C1.FIRSTNAME =C2.FIRSTNAME  AND  C1.LASTNAME=C2.LASTNAME AND  C1.EMAILADDRESS=C2.EMAILADDRESS', N'Y')
INSERT [DB].[ContactMatchingRules] ([ContactMatchID], [ContactMatchedRule], [SelectFilter], [WhereFilter1], [WhereFilter2], [WhereFilter3], [MatchingRule]) VALUES (25, N'EMAILADDRESS AND FIRSTNAME CAN MATCH IF THERE IS NO CONFLICT ON LASTNAME OR GENDER', N'ROW_NUMBER() OVER(PARTITION BY consolidationid,EMAILADDRESS,FIRSTNAME  ORDER BY masterscore desc )ROW_ID,* ', N'FIRSTNAME_L1 IS NOT NULL AND  LASTNAME IS NULL AND  GENDER IS NULL AND  EMAILADDRESS_L5 IS NOT NULL', N'FIRSTNAME_L1 IS NOT NULL AND  LASTNAME IS NULL AND  GENDER IS NOT NULL AND  EMAILADDRESS_L5 IS NOT NULL', N'C1.EMAILADDRESS=C2.EMAILADDRESS  AND  C1.FIRSTNAME =C2.FIRSTNAME', N'Y')
INSERT [DB].[ContactMatchingRules] ([ContactMatchID], [ContactMatchedRule], [SelectFilter], [WhereFilter1], [WhereFilter2], [WhereFilter3], [MatchingRule]) VALUES (26, N'FIRSTNAME, LASTNAME AND EMAILADDRESS CAN MATCH IF THERE IS NO CONFLICT ON LASTNAME OR GENDER', N'ROW_NUMBER() OVER(PARTITION BY consolidationid,EMAILADDRESS,FIRSTNAME,LASTNAME  ORDER BY masterscore desc )ROW_ID,* ', N'FIRSTNAME IS NOT NULL AND  LASTNAME IS NOT NULL AND  EMAILADDRESS_L5 IS NOT NULL AND  GENDER IS NOT NULL', N'FIRSTNAME IS NOT NULL AND  LASTNAME IS NOT NULL AND  EMAILADDRESS_L5 IS NOT NULL AND  GENDER IS NULL', N'C1.EMAILADDRESS=C2.EMAILADDRESS AND  C1.FIRSTNAME =C2.FIRSTNAME AND  C1.LASTNAME=C2.LASTNAME', N'Y')
INSERT [DB].[ContactMatchingRules] ([ContactMatchID], [ContactMatchedRule], [SelectFilter], [WhereFilter1], [WhereFilter2], [WhereFilter3], [MatchingRule]) VALUES (27, N'FIRSTNAME, LASTNAME AND EMAILADDRESS CAN MATCH IF THERE IS NO CONFLICT ON LASTNAME OR GENDER', N'ROW_NUMBER() OVER(PARTITION BY consolidationid,EMAILADDRESS,FIRSTNAME,LASTNAME  ORDER BY masterscore desc )ROW_ID,* ', N'FIRSTNAME IS NOT NULL AND  LASTNAME IS NOT NULL AND  EMAILADDRESS_L5 IS NOT NULL AND  GENDER IS NULL', N'FIRSTNAME IS NOT NULL AND  LASTNAME IS NOT NULL AND  EMAILADDRESS_L5 IS NOT NULL AND  GENDER IS NOT NULL', N'C1.EMAILADDRESS=C2.EMAILADDRESS AND  C1.FIRSTNAME =C2.FIRSTNAME AND  C1.LASTNAME=C2.LASTNAME', N'Y')
INSERT [DB].[ContactMatchingRules] ([ContactMatchID], [ContactMatchedRule], [SelectFilter], [WhereFilter1], [WhereFilter2], [WhereFilter3], [MatchingRule]) VALUES (28, N'MERGE RULE 1', N'ConsolidationID,ParentContactID PID,FIRSTNAME,LASTNAME,ROW_NUMBER() OVER(PARTITION BY ConsolidationID,FIRSTNAME,LASTNAME ORDER BY MASTERLEVEL) RowNo ', N'MasterLevel is not null ', N'Inner Join mergeParent m1 on m1.ConsolidationID=c1.ConsolidationID AND  (m1.FIRSTNAME = c1.FIRSTNAME AND  m1.LASTNAME = c1.LASTNAME) WHERE m1.RowNo = 1 ', N'NULL', N'M')
INSERT [DB].[ContactMatchingRules] ([ContactMatchID], [ContactMatchedRule], [SelectFilter], [WhereFilter1], [WhereFilter2], [WhereFilter3], [MatchingRule]) VALUES (29, N'MERGE RULE 2', N'ConsolidationID,ParentContactID PID, LASTNAME, EmailAddress ,ROW_NUMBER() OVER(PARTITION BY ConsolidationID,LASTNAME,EmailAddress ORDER BY MASTERLEVEL) RowNo ', N'MasterLevel is not null ', N'Inner Join mergeParent m1 on m1.ConsolidationID=c1.ConsolidationID AND  m1.LASTNAME = c1.LASTNAME AND  m1.EmailAddress = c1.EmailAddress where len(ISNULL(c1.FIRSTNAME,'''')) = 0 AND m1.RowNo = 1 ', N'NULL', N'M')
INSERT [DB].[ContactMatchingRules] ([ContactMatchID], [ContactMatchedRule], [SelectFilter], [WhereFilter1], [WhereFilter2], [WhereFilter3], [MatchingRule]) VALUES (30, N'MERGE RULE 3', N'ConsolidationID,ParentContactID PID, FIRSTNAME, LASTNAME, EmailAddress ,ROW_NUMBER() OVER(PARTITION BY ConsolidationID,FIRSTNAME,LASTNAME,EmailAddress ORDER BY MASTERLEVEL) RowNo  ', N'MasterLevel is not null AND  LEN(ISNULL(LASTNAME,'''')) > 1 ', N'Inner Join mergeParent m1 on m1.ConsolidationID=c1.ConsolidationID AND  m1.FIRSTNAME= c1.FIRSTNAME AND  left(m1.LASTNAME,1) = c1.LASTNAME AND  m1.EmailAddress = c1.EmailAddress WHERE m1.RowNo = 1 and LEN(ISNULL(c1.LASTNAME,'''')) = 1', N'NULL', N'M')
INSERT [DB].[ContactMatchingRules] ([ContactMatchID], [ContactMatchedRule], [SelectFilter], [WhereFilter1], [WhereFilter2], [WhereFilter3], [MatchingRule]) VALUES (31, N'MERGE RULE 4', N'ConsolidationID,ParentContactID PID, EmailAddress ,ROW_NUMBER() OVER(PARTITION BY ConsolidationID,EmailAddress ORDER BY MASTERLEVEL) RowNo  ', N'MasterLevel is not null AND  EmailAddress is not null ', N'Inner Join mergeParent m1 on m1.ConsolidationID=c1.ConsolidationID AND   m1.EmailAddress = c1.EmailAddress where len(isnull(c1.FIRSTNAME,'''')) = 0 AND  len(isnull(c1.LASTNAME,'''')) = 0 AND m1.RowNo = 1 ', N'NULL', N'M')
INSERT [DB].[ContactMatchingRules] ([ContactMatchID], [ContactMatchedRule], [SelectFilter], [WhereFilter1], [WhereFilter2], [WhereFilter3], [MatchingRule]) VALUES (32, N'MERGE RULE 5', N'ConsolidationID,ParentContactID PID, FIRSTNAME, LASTNAME, EmailAddress ,ROW_NUMBER() OVER(PARTITION BY ConsolidationID,FIRSTNAME, LASTNAME,EmailAddress ORDER BY MASTERLEVEL) RowNo  ', N'MasterLevel is not null AND  LEN(ISNULL(FIRSTNAME,'''')) = 1 ', N'Inner Join mergeParent m1 on m1.ConsolidationID=c1.ConsolidationID AND  m1.FIRSTNAME= c1.FIRSTNAME AND  m1.LASTNAME = left(c1.FIRSTNAME,1) AND  m1.EmailAddress = c1.EmailAddress WHERE M1.RowNo = 1 ', NULL, NULL)

SET IDENTITY_INSERT [DB].[ContactMatchingRules] OFF
GO

USE [Consolidated_Staging]
GO

ALTER PROCEDURE [DB].[up_Base]

AS

--- Contacts
/*
 For Contact records that have created/updated Consolidated, add the 
record into Base as an Audit record (BaseType A)
*/

INSERT INTO Base.db.Contact (
    Source,
	MarketCode, 
	SourceContactID, 
	EmailAddress, 
	CompanyName, 
	ContactAddress1, 
	ContactAddress2, 
	ContactAddress3, 
	ContactAddress4, 
	ContactTown, 
	ContactCounty, 
	ContactPostCode, 
	ContactCountryCode, 
	ContactCountryName, 
	Salutation, 
	FirstName,
	LastName, 
	Telephone, 
	JobTitle, 
	CreateDate, 
	LastUpdateDate, 
	Password, 
	ValidEmailAddress, 
	HTMLCapable, 
	SoftBounceCount,
	HardBounceCount, 
	LastBounced, 
	MobileNumber, 
	UserName, 
	GroupName, 
	Title, 
	SMSMobile,
	Department,
	AuditDate,
	C_ContactID,
	Status,
	ViperGUID,
	BaseDetail,
	ContactType,
	OrigSourceAccountID,
	OrigSourceOwnerID,
	ContactRole,
	Consolidated_ContactID,
	ThirdParty,
	LastLogin
	)
SELECT DISTINCT 
	cc.Source,
	cc.MarketCode,
	cc.SourceContactID,
	cc.EmailAddress,
	cc.CompanyName,
	left(cc.ContactAddress1,130),
	cc.ContactAddress2,
	cc.ContactAddress3,
	cc.ContactAddress4,
	cc.ContactTown,
	cc.ContactCounty,
	cc.ContactPostCode,
	cc.ContactCountryCode,
	cc.ContactCountryName,
	cc.Salutation,
	cc.FirstName,
	cc.LastName,
	cc.Telephone,
	cc.JobTitle,
	cc.CreateDate,
	cc.LastUpdateDate,
	cc.Password,
	cc.ValidEmailAddress,
	cc.HTMLCapable,
	cc.SoftBounceCount,
	cc.HardBounceCount,
	cc.LastBounced,
	cc.MobileNumber,
	cc.UserName,
	cc.GroupName,
	cc.Title,
	cc.SMSMobile,
	cc.Department,
	GETDATE(),
	cc.C_ContactID,
	cc.Status,
	cc.ViperGUID,
	cc.BaseDetail,
	cc.SourceTable,
	cc.AccountID,
	cc.SourceOwnerID,
	cc.ContactRole,
	cc.Consolidated_ContactID,
	cc.ThirdParty,
	cc.LastLogin
FROM Consolidated_Staging.DB.Contact cc
LEFT JOIN Base.db.Contact bc
ON cc.Source = bc.Source and cc.MarketCode = bc.MarketCode 
and cc.SourceContactID = bc.SourceContactID
WHERE (ISNULL(cc.Source,'') <> ISNULL(bc.Source,'')
	OR ISNULL(cc.MarketCode,'') <> ISNULL(bc.MarketCode,'')
	OR ISNULL(cc.SourceContactID,'') <> ISNULL(bc.SourceContactID,'')
	OR ISNULL(cc.EmailAddress,'') <> ISNULL(bc.EmailAddress,'')
	OR ISNULL(cc.CompanyName,'') <> ISNULL(bc.CompanyName,'')
	OR ISNULL(cc.ContactAddress1,'') <> Left(ISNULL(bc.ContactAddress1,130),'')
	OR ISNULL(cc.ContactAddress2,'') <> ISNULL(bc.ContactAddress2,'')
	OR ISNULL(cc.ContactAddress3,'') <> ISNULL(bc.ContactAddress3,'')
	OR ISNULL(cc.ContactAddress4,'') <> ISNULL(bc.ContactAddress4,'')
	OR ISNULL(cc.ContactTown,'') <> ISNULL(bc.ContactTown,'')
	OR ISNULL(cc.ContactCounty,'') <> ISNULL(bc.ContactCounty,'')
	OR ISNULL(cc.ContactPostCode,'') <> ISNULL(bc.ContactPostCode,'')
	OR ISNULL(cc.ContactCountryCode,'') <> ISNULL(bc.ContactCountryCode,'')
	OR ISNULL(cc.ContactCountryName,'') <> ISNULL(bc.ContactCountryName,'')
	OR ISNULL(cc.Salutation,'') <> ISNULL(bc.Salutation,'')
	OR ISNULL(cc.FirstName,'') <> ISNULL(bc.FirstName,'')
	OR ISNULL(cc.LastName,'') <> ISNULL(bc.LastName,'')
	OR ISNULL(cc.Telephone,'') <> ISNULL(bc.Telephone,'')
	OR ISNULL(cc.JobTitle,'') <> ISNULL(bc.JobTitle,'')
	OR ISNULL(cc.CreateDate,'') <> ISNULL(bc.CreateDate,'')
	OR ISNULL(cc.LastUpdateDate,'') <> ISNULL(bc.LastUpdateDate,'')
	OR ISNULL(cc.[Password],'') <> ISNULL(bc.[Password],'')
	OR ISNULL(cc.ValidEmailAddress,'') <> ISNULL(bc.ValidEmailAddress,'')
	OR ISNULL(cc.HTMLCapable,'') <> ISNULL(bc.HTMLCapable,'')
	OR ISNULL(cc.SoftBounceCount,'') <> ISNULL(bc.SoftBounceCount,'')
	OR ISNULL(cc.HardBounceCount,'') <> ISNULL(bc.HardBounceCount,'')
	OR ISNULL(cc.LastBounced,'') <> ISNULL(bc.LastBounced,'')
	OR ISNULL(cc.MobileNumber,'') <> ISNULL(bc.MobileNumber,'')
	OR ISNULL(cc.UserName,'') <> ISNULL(bc.UserName,'')
	OR ISNULL(cc.GroupName,'') <> ISNULL(bc.GroupName,'')
	OR ISNULL(cc.Title,'') <> ISNULL(bc.Title,'')
	OR ISNULL(cc.SMSMobile,'') <> ISNULL(bc.SMSMobile,'')
	OR ISNULL(cc.Department,'') <> ISNULL(bc.Department,'')
	OR ISNULL(cc.C_ContactID,'') <> ISNULL(bc.C_ContactID,'')
	OR ISNULL(cc.[Status],'') <> ISNULL(bc.[Status],'')
	OR ISNULL(cc.ViperGUID,'') <> ISNULL(bc.ViperGUID,'')
	OR ISNULL(cc.BaseDetail,'') <> ISNULL(bc.BaseDetail,'')
	OR ISNULL(cc.SourceTable,'') <> ISNULL (bc.ContactType,'')  
	OR ISNULL(cc.AccountID,'') <> ISNULL(bc.OrigSourceAccountID,'')
	OR ISNULL(cc.SourceOwnerID,'') <> ISNULL(bc.OrigSourceOwnerID,'')
	OR ISNULL(cc.ContactRole,'') <> ISNULL(bc.ContactRole,'')
	OR ISNULL(cc.Consolidated_ContactID,'') <> ISNULL(bc.Consolidated_ContactID,'')
	OR ISNULL(cc.ThirdParty,'') <> ISNULL(bc.ThirdParty,'')
	OR ISNULL(cc.LastLogin,'') <> ISNULL(bc.LastLogin,'') 
	)


/* for contact records that haven't updated Consolidated, look for an existing R 
record in Base. If it exists then update it if any field has changed and if the
source create/last update date is later */


/* Privacy
*/

INSERT INTO Base.DB.Privacy
(
	MarketCode, 
	Source, 
	FeedName, 
	DPAValue, 
	EmailAddress, 
	CreateDate, 
	LastUpdateDate, 
	IsGlobal, 
	C_ContactDPASettingID,
	SourceContactID,
	BaseDetail
	,ProxyName
	,ProxyRelationship
	,ProxyCompany
	,ProxyMethod
	,ProxyDate
	)
SELECT DISTINCT 
	ce.SourceMarketCode, 
	ce.Source, 
	ce.FeedName, 
	DPAValue, 
	EmailAddress, 
	CreateDate, 
	LastUpdateDate, 
	IsGlobal, 
	C_ContactDPASettingID,
	ce.SourceContactID,
	BaseDetail
	,ProxyName
	,ProxyRelationship
	,ProxyCompany
	,ProxyMethod
	,ProxyDate
FROM Consolidated_Staging.DB.Privacy_Consolidated_Email ce
WHERE C_ContactDPASettingID IS NOT NULL


	
/* Membership
*/

-- Add any membership that have created or updated Membership records. Get this from MembershipConsolidated. Don't
-- add any that have come from Demographics

INSERT INTO Base.db.Membership 
(
	Source, 
	MarketCode, 
	SourceContactID, 
	ProductCode, 
	Status,
	StartDate, 
	EndDate, 
	SubscriptionType, 
	FormSourceTracking, 
	CreateDate, 
	LastUpdateDate, 
	Description,
	LastIssueSent,
	EndIssueCode,
	ReaderType,
	SubEndDate,
	AgeDate,
	DespatchMethod,
	Promocode,
	C_MembershipID,
	ParentProductCode,
	BaseDetail,
	SourceMembershipID,
	AuditDate
)
SELECT DISTINCT 
	mc.Source, 
	mc.MarketCode, 
	mc.SourceContactID, 
	mc.ProductCode, 
	MembershipStatus,
	StartDate, 
	EndDate, 
	MembershipType, 
	FormSourceTracking, 
	CreateDate, 
	LastUpdateDate, 
	Description,
	LastIssueSent,
	EndIssueCode,
	ReaderType,
	SubEndDate,
	AgeDate,
	DespatchMethod,
	Promocode,
	C_MembershipID,
	ParentProductCode,
	BaseDetail,
	SourceMembershipID,
	Getdate()
FROM 
	db.MembershipConsolidated mc
WHERE 
	C_MembershipID IS NOT NULL AND DemographicID IS NULL



/*
	Update the table Base.DB.ContactConsolidatedIDs
	- if a record exists then update it
	- otherwise insert it
*/	

-- first, remove the C_IDs from any existing ContactConsolidatedIDs records

UPDATE Base.DB.ContactConsolidatedIDs
SET C_ContactAddressID = NULL
FROM Base.DB.ContactConsolidatedIDs cc
INNER JOIN Consolidated_Staging.DB.Contact c
ON c.C_ContactAddressID = cc.C_ContactAddressID

UPDATE Base.DB.ContactConsolidatedIDs
SET C_ContactCompanyID = NULL
FROM Base.DB.ContactConsolidatedIDs cc
INNER JOIN Consolidated_Staging.DB.Contact c
ON c.C_ContactCompanyID = cc.C_ContactCompanyID

UPDATE Base.DB.ContactConsolidatedIDs
SET C_ContactTelephoneIDFax = NULL
FROM Base.DB.ContactConsolidatedIDs cc
INNER JOIN Consolidated_Staging.DB.Contact c
ON c.C_ContactTelephoneIDFax = cc.C_ContactTelephoneIDFax

UPDATE Base.DB.ContactConsolidatedIDs
SET C_ContactTelephoneIDMobile = NULL
FROM Base.DB.ContactConsolidatedIDs cc
INNER JOIN Consolidated_Staging.DB.Contact c
ON c.C_ContactTelephoneIDMobile = cc.C_ContactTelephoneIDMobile

UPDATE Base.DB.ContactConsolidatedIDs
SET C_ContactTelephoneIDSMSMobile = NULL
FROM Base.DB.ContactConsolidatedIDs cc
INNER JOIN Consolidated_Staging.DB.Contact c
ON c.C_ContactTelephoneIDSMSMobile = cc.C_ContactTelephoneIDSMSMobile

UPDATE Base.DB.ContactConsolidatedIDs
SET C_ContactTelephoneIDTelephone = NULL
FROM Base.DB.ContactConsolidatedIDs cc
INNER JOIN Consolidated_Staging.DB.Contact c
ON c.C_ContactTelephoneIDTelephone = cc.C_ContactTelephoneIDTelephone

UPDATE Base.DB.ContactConsolidatedIDs
SET C_SourceEmailID = NULL
FROM Base.DB.ContactConsolidatedIDs cc
INNER JOIN Consolidated_Staging.DB.Contact c
ON c.C_SourceEmailID = cc.C_SourceEmailID

UPDATE Base.DB.ContactConsolidatedIDs
SET C_ContactUsernameID = NULL
FROM Base.DB.ContactConsolidatedIDs cc
INNER JOIN Consolidated_Staging.DB.Contact c
ON c.C_ContactUsernameID = cc.C_ContactUsernameID

UPDATE Base.DB.ContactConsolidatedIDs
SET C_ContactEmailID = NULL
FROM Base.DB.ContactConsolidatedIDs cc
INNER JOIN Consolidated_Staging.DB.Contact c
ON c.C_ContactEmailID = cc.C_ContactEmailID

-- then update existing ContactConsolidatedIDs records

UPDATE Base.DB.ContactConsolidatedIDs
SET	
	C_SourceEmailID = a.C_SourceEmailID,
	C_ContactCompanyID = a.C_ContactCompanyID,
	C_ContactID = a.C_ContactID,
	C_ContactTelephoneIDFax = a.C_ContactTelephoneIDFax,
	C_ContactTelephoneIDMobile = a.C_ContactTelephoneIDMobile,
	C_ContactTelephoneIDSMSMobile = a.C_ContactTelephoneIDSMSMobile,
	C_ContactTelephoneIDTelephone = a.C_ContactTelephoneIDTelephone,
	C_ContactAddressID = a.C_ContactAddressID,
	C_ContactEmailID = a.C_ContactEmailID,
	EmailAddress = a.EmailAddress,
	FirstName = a.FirstName,
	LastName = a.LastName,
	ContactAddress1 = a.ContactAddress1,
	ContactPostCode = a.ContactPostCode,
	Telephone = a.Telephone,
	MobileNumber = a.MobileNumber,
	LastUpdateDate = GETDATE()
FROM DB.Contact a
	INNER JOIN Base.DB.ContactConsolidatedIDs b 
	ON a.Source = b.Source
	AND	a.MarketCode = b.MarketCode
	AND	a.SourceContactID = b.SourceContactID
WHERE (ISNULL(b.C_SourceEmailID,'') <> ISNULL(a.C_SourceEmailID,'')
	OR ISNULL(b.C_ContactCompanyID,'') <> ISNULL(a.C_ContactCompanyID,'')
	OR ISNULL(b.C_ContactID,'') <> ISNULL(a.C_ContactID,'')	
	OR ISNULL(b.C_ContactTelephoneIDFax,'') <> ISNULL(a.C_ContactTelephoneIDFax,'')
	OR ISNULL(b.C_ContactTelephoneIDMobile,'') <> ISNULL(a.C_ContactTelephoneIDMobile,'')
	OR ISNULL(b.C_ContactTelephoneIDSMSMobile,'') <> ISNULL(a.C_ContactTelephoneIDSMSMobile,'')
	OR ISNULL(b.C_ContactTelephoneIDTelephone,'') <> ISNULL(a.C_ContactTelephoneIDTelephone,'')
	OR ISNULL(b.C_ContactAddressID,'') <> ISNULL(a.C_ContactAddressID,'')
	OR ISNULL(b.C_ContactEmailID,'') <> ISNULL(a.C_ContactEmailID,'')
	OR ISNULL(b.Title,'') <> ISNULL(a.Title,'')
	OR ISNULL(b.FirstName,'') <> ISNULL(a.FirstName,'')
	OR ISNULL(b.LastName,'') <> ISNULL(a.LastName,'')
	OR ISNULL(b.EmailAddress,'') <> ISNULL(a.EmailAddress,'')
	OR ISNULL(b.ContactAddress1,'') <> ISNULL(a.ContactAddress1,'')
	OR ISNULL(b.ContactPostCode,'') <> ISNULL(a.ContactPostCode,'')
	OR ISNULL(b.Telephone,'') <> ISNULL(a.Telephone,'')
	OR ISNULL(b.MobileNumber,'') <> ISNULL(a.MobileNumber,'') )
	
	
-- update any that were loaded originally from ContactConsolidatedIDs

update 
	base.db.ContactConsolidatedIDs
	set c_contactid = a.C_ContactID
from db.ContactIgnoreBeyondContactMatching a
	INNER JOIN Base.DB.ContactConsolidatedIDs b 
	ON a.Source=b.Source
	AND	a.MarketCode=b.MarketCode
	AND	a.SourceContactID=b.SourceContactID
 where a.C_ContactID <> b.C_ContactID


INSERT INTO ETL_Staging.ETL.Audit (AuditCategoryID,Action,Type,ActionDate)
VALUES (5,'Success','Start - up_ConsolidationGroupID',getdate())


Exec Consolidated_Staging.db.up_ConsolidationGroupID

INSERT INTO ETL_Staging.ETL.Audit (AuditCategoryID,Action,Type,ActionDate)
VALUES (5,'Success','End - up_ConsolidationGroupID',getdate())



INSERT INTO Base.DB.ContactConsolidatedIDs (
	 Source
	,MarketCode
	,SourceContactID
	,C_ContactUsernameID  
	,C_ContactAddressID  
	,C_SourceEmailID  
	,C_ContactID
	,C_ContactCompanyID  
	,C_ContactTelephoneIDFax  
	,C_ContactTelephoneIDTelephone  
	,C_ContactTelephoneIDMobile  
	,C_ContactTelephoneIDSMSMobile 
	,CreateDate
	,C_ContactEmailID
	,ConsolidationGroupID
	,Title
	,FirstName
	,LastName
	,EmailAddress
	,ContactAddress1
	,ContactPostCode
	,Telephone
	,MobileNumber
	)
SELECT Distinct 
	cc.Source,
	cc.MarketCode,
	cc.SourceContactID,
	cc.C_ContactUsernameID, 
	cc.C_ContactAddressID, 
	cc.C_SourceEmailID,
	cc.C_ContactID,
	cc.C_ContactCompanyID,  
	cc.C_ContactTelephoneIDFax,  
	cc.C_ContactTelephoneIDTelephone, 
	cc.C_ContactTelephoneIDMobile , 
	cc.C_ContactTelephoneIDSMSMobile,
	GETDATE(),
	cc.C_ContactEmailID,
	cc.ConsolidationGroupID,
	cc.Title,
	cc.FirstName,
	cc.LastName,
	cc.EmailAddress,
	cc.ContactAddress1,
	cc.ContactPostCode,
	cc.Telephone,
	cc.MobileNumber
FROM db.Contact cc
LEFT JOIN Base.DB.ContactConsolidatedIDs bc 
ON cc.Source=bc.Source 
AND	cc.MarketCode=bc.MarketCode
AND	cc.SourceContactID=bc.SourceContactID
Where bc.Source is null and bc.MarketCode is null and bc.SourceContactID is null 


/*
	Update the table Base.DB.MembershipConsolidatedIDs
	- if a record exists then update it
	- otherwise insert it
*/	

-- first, remove the C_IDs from any existing ContactConsolidatedIDs records

UPDATE Base.DB.MembershipConsolidatedIDs
SET C_MembershipID = NULL
FROM Base.DB.MembershipConsolidatedIDs cc
INNER JOIN Consolidated_Staging.DB.MembershipConsolidated c
ON cc.C_MembershipID = c.C_MembershipID

UPDATE	
	Base.DB.MembershipConsolidatedIDs
SET		
	C_MembershipID=a.C_MembershipID,
	LastUpdateDate= GETDATE(),
	IsDemographic = CASE WHEN a.Demographicid IS NOT NULL THEN 1 END
FROM	
	DB.MembershipConsolidated a
	INNER JOIN Base.DB.MembershipConsolidatedIDs b ON a.Source=b.Source
	AND	a.MarketCode=b.MarketCode
	AND	a.SourceContactID=b.SourceContactID
	AND	a.ProductCode=b.ProductCode
WHERE a.C_MembershipID IS NOT NULL




INSERT INTO 
	Base.DB.MembershipConsolidatedIDs
SELECT DISTINCT 
	a.Source
	,a.MarketCode
	,a.SourceContactID
	,a.ProductCode
	,a.C_MembershipID
	,GETDATE()
	,NULL
	,CASE WHEN a.Demographicid IS NOT NULL THEN 1 END
FROM	
	Consolidated_Staging.db.MembershipConsolidated a
	LEFT JOIN Base.DB.MembershipConsolidatedIDs b ON a.Source=b.Source
	AND	a.MarketCode=b.MarketCode
	AND	a.SourceContactID=b.SourceContactID
	AND	a.ProductCode=b.ProductCode
WHERE	
	b.Source IS NULL
	AND	b.MarketCode IS NULL
	AND	b.SourceContactID IS NULL
	AND	b.ProductCode IS NULL
	AND	a.C_MembershipID IS NOT NULL
	


IF OBJECT_ID('tempdb..#Demographic') IS NOT NULL 
	DROP TABLE #Demographic

SELECT SourceAccountID
	,DemographicID
	,DemographicCode
	,DemographicValue
	,OrigSourceAccountID
	,Source
	,MarketCode
	,CreateDate
	,LastUpdateDate
	,SourceID
INTO #Demographic
FROM
	(SELECT DISTINCT sa.SourceAccountID
		,dc.DemographicID
		,d.DemographicCode
		,d.DemographicValue
		,d.OrigSourceAccountID
		,d.Source
		,d.MarketCode
		,d.CreateDate
		,d.LastUpdateDate
		,s.SourceID
		,ROW_NUMBER() over (partition by SourceAccountID, DemographicID, DemographicValue, s.SourceID  order by isnull(d.lastupdatedate, d.createdate) desc ) rowno
	FROM ETL_Staging.etl.SourceAccountDemographic d 
	INNER JOIN Consolidated.db.Market m
	ON m.MarketCode = d.MarketCode
	INNER JOIN Consolidated.db.DemographicCode dc
	ON d.DemographicCode = dc.DemographicCode
	AND m.MarketID = dc.MarketID 
	INNER JOIN Consolidated.db.SourceAccount sa
	ON d.OrigSourceAccountID = sa.OrigSourceAccountID
	AND sa.MarketID = m.MarketID
	INNER JOIN Consolidated.db.Source s
	ON d.Source = s.SourceCode) x
WHERE rowno = 1

GO


ALTER PROCEDURE [DB].[up_ConsolidatedGetContactID]

AS

IF NOT EXISTS (SELECT * FROM Consolidated_Staging.sys.indexes WHERE Name = 'X_CS_F')
BEGIN	
	CREATE NONCLUSTERED INDEX [X_CS_F] ON [DB].[Contact] ([FirstName] ASC) INCLUDE ( [ContactID])
END	

IF NOT EXISTS (SELECT * FROM Consolidated_Staging.sys.indexes WHERE Name = 'X_CS_L')
BEGIN	
	CREATE NONCLUSTERED INDEX [X_CS_L] ON [DB].[Contact] ([LastName] ASC) INCLUDE ( [ContactID])
END

IF NOT EXISTS (SELECT * FROM Consolidated.sys.indexes WHERE Name = 'X_C_S')
BEGIN	
	CREATE NONCLUSTERED INDEX [X_C_S] ON Consolidated.[DB].[Contact] ([Surname] ASC) INCLUDE ( [ContactID])
END

IF NOT EXISTS (SELECT * FROM Consolidated.sys.indexes WHERE Name = 'X_C_F')
BEGIN	
CREATE NONCLUSTERED INDEX [X_C_F] ON Consolidated.[DB].[Contact] ([Firstname] ASC) INCLUDE ( [ContactID])
END


/*This procedure attempts to find the existing ContactIDs that the SourceContacts match to */

--select ConsolidationID, ParentContactID, MasterLevel, EmailAddress, firstname, lastname from Consolidated_Staging.db.Contact


--update Consolidated_Staging.db.Contact
--set ConsolidationID = ConsolidationID + '|' + cast(ParentContactID as varchar(5))


-- Updating C_ContactID. If a ContactID is being supplied in the ETL table then always use that

;WITH ccid as 
(
SELECT ConsolidationID,MAX(Consolidated_ContactID) MaxID FROM Consolidated_Staging.db.Contact
WHERE Consolidated_ContactID is not null 
GROUP BY ConsolidationID
)
UPDATE c2
SET c2.C_ContactID= c1.MaxID
FROM ccid c1
INNER JOIN Consolidated_Staging.db.Contact c2
ON c1.ConsolidationID = c2.ConsolidationID


IF OBJECT_ID('tempdb..#ContactQuality1') IS NOT NULL DROP TABLE #ContactQuality1

SELECT c.FirstName
	,c.LastName
	,c.MobileNumber
	,c.Telephone
	,c.SMSMobile
	,ETL_STAGING.ETL.fnNumbersOnly(c.MobileNumber) MobileNumber_C
	,ETL_STAGING.ETL.fnNumbersOnly(c.Telephone) Telephone_C
	,ETL_STAGING.ETL.fnNumbersOnly(c.SMSMobile) SMSMobile_C
	,c.ContactAddress1
	,c.ContactPostCode
	,c.ContactID
	,c.ConsolidationID
	,DoNotUseTelephone
	,DoNotUseMobile
	,DoNotUseSMSMobile
	,DoNotUseAddress
INTO #ContactQuality1
FROM DB.Contact c
WHERE DoNotUseName IS NULL
OR EmailAddress IS NOT NULL


-- match on email



IF OBJECT_ID('tempdb..#EmailParentContactID') IS NOT NULL DROP TABLE #EmailParentContactID

select EmailAddress, parentcontactid, consolidationid
into #EmailParentContactID
from
(select EmailAddress, parentcontactid , consolidationid, ROW_NUMBER() over(partition by emailaddress, consolidationid order by masterlevel) rowno
from Consolidated_Staging.db.Contact
where DoNotUseEmail is null
and IsValidEmail = 1) x
where rowno = 1



update db.Contact
set c_contactid = ce.ContactID
FROM db.Contact c
INNER JOIN Consolidated.DB.ContactEmail ce
ON ce.EmailAddress = c.EmailAddress
inner join #EmailParentContactID e
on c.EmailAddress = e.EmailAddress
and c.ParentContactID = e.ParentContactID
and c.ConsolidationID = e.ConsolidationID

-- match on telephone. match on the best record left in the consolidation group ie the one with the hightest MasterLevel
-- don't update the C_ContactID to any C_ContactIDs already matched

INSERT INTO ETL_Staging.ETL.Audit (AuditCategoryID,Action,Type,ActionDate)
VALUES (5,'1','Load - Consolidated GetContactID',getdate())


IF OBJECT_ID('tempdb..#TelephoneParentContactID') IS NOT NULL DROP TABLE #TelephoneParentContactID

select FirstName, LastName, Telephone, ParentContactID,ConsolidationID
into #TelephoneParentContactID
from
(select FirstName, LastName, Telephone, ParentContactID, ConsolidationID
	, ROW_NUMBER() over(partition by FirstName, LastName, Telephone, ConsolidationID order by masterlevel) rowno
from Consolidated_Staging.db.Contact
WHERE TelephoneQuality =1
and DoNotUseName is null
and DoNotUseTelephone is null
and c_contactid is null) x
where rowno = 1

update db.Contact
set c_contactid = cn.ContactID
FROM db.Contact c
INNER JOIN Consolidated.DB.ContactTelephone ct
on c.Telephone = ct.Number
INNER JOIN Consolidated.db.contact cn
on cn.contactid = ct.contactid
and isnull(cn.firstname,'x')+'-'+isnull(cn.surname,'xy') = isnull(c.firstname,'x')+'-'+isnull(c.LastName,'xy')
INNER JOIN #TelephoneParentContactID t
on t.ConsolidationID+t.parentcontactid = c.ConsolidationID+c.parentcontactid
--and t.parentcontactid = c.parentcontactid
LEFT JOIN (SELECT DISTINCT C_CONTACTID FROM db.Contact) c_c
on c_c.C_ContactID = cn.ContactID
where c_c.C_ContactID is null


-- match on address. match on the best record left in the consolidation group ie the one with the hightest MasterLevel
-- don't update the C_ContactID to any C_ContactIDs already matched

INSERT INTO ETL_Staging.ETL.Audit (AuditCategoryID,Action,Type,ActionDate)
VALUES (5,'2','Load - Consolidated GetContactID',getdate())


IF OBJECT_ID('tempdb..#AddressParentContactID') IS NOT NULL DROP TABLE #AddressParentContactID

select FirstName, LastName, ContactAddress1,ContactPostCode, ParentContactID,ConsolidationID
into #AddressParentContactID
from
(select FirstName, LastName, ContactAddress1, ContactPostCode, ParentContactID, ConsolidationID
	, ROW_NUMBER() over(partition by FirstName, LastName, ContactAddress1,ContactPostCode, ConsolidationID order by masterlevel) rowno
from Consolidated_Staging.db.Contact
WHERE DoNotUseName is null
and DoNotUseAddress is null
and c_contactid is null) x
where rowno = 1


IF OBJECT_ID('tempdb..#ContactAddress') IS NOT NULL DROP TABLE #ContactAddress

select distinct cc.Firstname, cc.Surname, a.AddressLine1, a.PostCode, cc.ContactID
into #ContactAddress
FROM Consolidated.DB.Contact cc
INNER JOIN Consolidated.db.ContactAddress ca
on cc.ContactID = ca.ContactID
inner join Consolidated.db.Address a
on a.AddressID = ca.AddressID
where Firstname is not null
and Surname is not null
and AddressLine1 is not null
and Postcode is not null

CREATE NONCLUSTERED INDEX x_Contact
ON [DB].[Contact] ([C_ContactID])


update db.Contact
set c_contactid = ca.ContactID
FROM #ContactAddress ca
inner join db.Contact c
on c.FirstName = ca.FirstName
and c.LastName = ca.Surname
and c.ContactAddress1 = ca.AddressLine1
and c.ContactPostCode = ca.Postcode
inner join #AddressParentContactID ap
on ap.ConsolidationID+ap.parentcontactid = c.ConsolidationID+c.parentcontactid
and ap.parentcontactid = c.parentcontactid
LEFT JOIN (SELECT DISTINCT C_CONTACTID FROM db.Contact (nolock)) c_c
on c_c.C_ContactID = ca.ContactID
where c_c.C_ContactID is null


drop INDEX x_Contact
ON [DB].[Contact]



INSERT INTO ETL_Staging.ETL.Audit (AuditCategoryID,Action,Type,ActionDate)
VALUES (5,'3','Load - Consolidated GetContactID',getdate())


-- if Contact record still doesn't have a c_contactid then update it to the previous value but 
-- only if the C_ContactID hasn't been given to another ParentContactID

update Consolidated_Staging.db.contact 
set c_contactid = c.C_PreviousContactID
from Consolidated_Staging.db.contact c
left join (select C_ContactID from Consolidated_Staging.db.contact) c2
on c.C_PreviousContactID = c2.C_ContactID
where c.c_contactid is null
and c.C_PreviousContactID is not null 
and c2.C_ContactID is null

-- update the contact details from the best contactID

INSERT INTO ETL_Staging.ETL.Audit (AuditCategoryID,Action,Type,ActionDate)
VALUES (5,'4','Load - Consolidated GetContactID',getdate())


IF OBJECT_ID('tempdb..#UpdateContact') IS NOT NULL DROP TABLE #UpdateContact

select *
into #UpdateContact
from
(select FirstName, LastName, Title,C_ContactID,OriginalFirstname,originalsurname, 
ROW_NUMBER() over(partition by C_ContactID order by masterscore desc, isnull(lastupdatedate,createdate) desc) rowno
from Consolidated_Staging.db.Contact) x
where rowno = 1

update Consolidated.db.Contact
set Firstname = cc.FirstName,
Surname = cc.LastName,
Title = cc.Title,
OriginalFirstname = cc.OriginalFirstname,
originalsurname = cc.originalsurname
from Consolidated.db.Contact c
inner join #UpdateContact cc
on C_ContactID = c.ContactID
where isnull(c.firstname,'') <> isnull(cc.firstname,'')
or isnull(c.Surname,'') <> isnull(cc.LastName,'')
or isnull(c.Title,'') <> isnull(cc.Title,'')

INSERT INTO ETL_Staging.ETL.Audit (AuditCategoryID,Action,Type,ActionDate)
VALUES (5,'5','Load - Consolidated GetContactID',getdate())

update Consolidated_Staging.db.Contact
set c_contactid = null
from Consolidated_Staging.db.Contact cc
left join Consolidated.db.Contact c
on c.contactid = cc.C_ContactID
where c.ContactID is null

go



ALTER PROCEDURE [DB].[up_ConsolidatedCreateContactID]


AS

-- Update the existing Contact if it's Source

--IF OBJECT_ID('tempdb..#ContactBestWhenExists') IS NOT NULL 
--	DROP TABLE #ContactBestWhenExists

--SELECT Title, FirstName, LastName Surname, CreateDate, LastUpdateDate, C_ContactID, OriginalFirstName, Originalsurname,
--	 ROW_NUMBER() OVER (PARTITION BY C_ContactID
--						ORDER BY db.higherdate(LastUpdateDate, CreateDate) DESC) AS RowNo
--INTO #ContactBestWhenExists
--FROM db.contact
--WHERE FirstName IS NOT NULL AND LastName IS NOT NULL
--and c_contactid is not null


--UPDATE Consolidated.db.Contact
--SET title = cm.Title,
--FirstName = cm.FirstName,
--Surname = cm.Surname,
--OriginalFirstName = cm.OriginalFirstName,
--OriginalSurname = cm.OriginalSurname,
--SourceCreateDate = cm.CreateDate,
--SourceLastUpdateDate = cm.LastUpdateDate,
--LastUpdateDate = GETDATE() 
--FROM Consolidated.db.Contact ct
--INNER JOIN
--	(SELECT * FROM #ContactBestWhenEXISTS WHERE RowNo = 1) cm
--ON ct.ContactID = cm.C_ContactID
--AND db.higherdate(cm.LastUpdateDate, cm.CreateDate) 
--> db.higherdate(ct.SourceLastUpdateDate, ct.SourceCreateDate)
--AND (ISNULL(ct.FirstName,'') <> ISNULL(cm.FirstName,'')
--OR ISNULL(ct.Surname,'') <> ISNULL(cm.Surname,'')
--OR ISNULL(ct.title,'') <> ISNULL(cm.title,''))

update Consolidated.db.Contact
set ConsolidationID = null, ParentContactID = null
where ConsolidationID is not null or ParentContactID is not null

while (select count(*) from db.Contact WHERE c_ContactID IS NULL and ParentContactID is not null) > 0
begin

IF OBJECT_ID('tempdb..#ContactBestWhenNotExists') IS NOT NULL 
	DROP TABLE #ContactBestWhenNotExists

-- BAU-498 exclude records without a ParentContactID in case the up_ConsolidationGroupSplit fails

SELECT Title, FirstName, LastName Surname,CreateDate, LastUpdateDate , ConsolidationID, OriginalFirstName, Originalsurname,ParentContactid,
ROW_NUMBER() OVER (PARTITION BY ConsolidationID
							ORDER BY isnull(masterscore,0) desc, db.higherdate(LastUpdateDate, CreateDate) DESC) AS RowNo
INTO #ContactBestWhenNotExists
FROM db.Contact
WHERE c_ContactID IS NULL
and ParentContactID is not null

INSERT INTO Consolidated.db.Contact 
	(Title
	,Firstname
	,Surname
	,SourceCreateDate
	,SourceLastUpdateDate
	,ConsolidationID
	,OriginalFirstName
	, Originalsurname
	,ParentContactID)
SELECT Title
	,Firstname
	,Surname
	,CreateDate
	,LastUpdateDate
	,ConsolidationID 
	,OriginalFirstName
	, Originalsurname
	,ParentContactID
FROM #ContactBestWhenNotExists
WHERE RowNo = 1

--select * from Consolidated.db.Contact order by createdate desc

-- update the C_ContactID from the ContactID of the record just created

UPDATE db.Contact
SET C_ContactID = c.ContactID,
	CreatedContact = 1
FROM db.Contact cr
INNER JOIN Consolidated.db.Contact c
ON cr.ConsolidationID = c.ConsolidationID
and cr.ParentContactID = c.ParentContactID
WHERE cr.C_ContactID IS NULL

--select c_contactid, ConsolidationID, parentcontactid from Consolidated_Staging.db.contact 
--select top 3 ConsolidationID, parentcontactid, createdate from Consolidated.db.Contact order by createdate desc

update Consolidated.db.Contact
set ConsolidationID = null, ParentContactID = null
where ConsolidationID is not null or ParentContactID is not null

end


GO

ALTER PROCEDURE [DB].[up_CreateUpdateEmail]

AS


/*This procedure creates and updates Contact, ContactEmail and SourceEmail records */

-- get a single row per Email. Always select the row with the highest highest master level

IF OBJECT_ID('tempdb..#ContactEmailBest') IS NOT NULL 
	DROP TABLE #ContactEmailBest

SELECT C_ContactID
	,EmailAddress
	,CreateDate
	,LastUpdateDate
	,IsValidEmail
	,ContactID
	,ViperGuid
INTO #ContactEmailBest
FROM
	(SELECT C_ContactID
		,EmailAddress
		,CreateDate
		,LastUpdateDate
		,IsValidEmail
		,ContactID
		,ViperGuid
		,ROW_NUMBER() OVER (PARTITION BY EmailAddress 
			ORDER BY isnull(masterlevel,2000), EmailOwner desc, masterscore desc, isnull(LastUpdateDate,CreateDate) DESC) AS RowNo
	FROM db.Contact 
	WHERE EmailAddress IS NOT NULL) x
WHERE RowNo = 1


-- update ContactEmail if the ContactID has changed

UPDATE Consolidated.db.ContactEmail
SET ContactID = ceb.C_ContactID
,LastUpdateDate = GETDATE()
FROM Consolidated.db.ContactEmail ce
INNER JOIN #ContactEmailBest ceb
ON ce.EmailAddress = ceb.EmailAddress
INNER JOIN Consolidated.DB.Contact c
on c.ContactID = ceb.ContactID
WHERE ce.ContactID <> ceb.C_ContactID

-- remove IgnoreBeyondContactMatching records 

-- update ContactEmail if GUID has changed but don't update it to a null

--UPDATE Consolidated.db.ContactEmail
--SET ViperGUID = ceb.ViperGUID
--,LastUpdateDate = GETDATE()
--FROM Consolidated.db.ContactEmail ce
--INNER JOIN #ContactEmailBest ceb
--ON ce.EmailAddress = ceb.EmailAddress
--WHERE (ceb.ViperGUID IS NOT NULL AND ce.ViperGUID IS NOT NULL) OR ceb.ViperGUID <> ce.ViperGUID

-- create new ContactEmail records where the EmailAddress doesn't already exist.

INSERT INTO Consolidated.db.ContactEmail 
(ContactID
,EmailAddress
,SourceCreateDate
,SourceLastUpdateDate
,IsValid
,ViperGUID
,C_ContactID)
SELECT c.C_ContactID
		,c.EmailAddress
		,c.CreateDate
		,c.LastUpdateDate
		,c.IsValidEmail
		,c.ViperGUID
		,c.ContactID
FROM #ContactEmailBest c
LEFT JOIN Consolidated.db.ContactEmail ce
ON c.EmailAddress = ce.EmailAddress
inner join Consolidated.db.Contact cn
on cn.ContactID = c.C_ContactID
WHERE ce.EmailAddress IS NULL

-- get the current ContactEmailID by joining on the email

UPDATE Consolidated_Staging.DB.Contact
SET C_ContactEmailID = ce.ContactEmailID
FROM Consolidated_Staging.DB.Contact c
INNER JOIN Consolidated.DB.ContactEmail ce
ON c.EmailAddress = ce.EmailAddress

-- put those records that were loaded from Base.db.ContactConsolidatedIDs into a separate table but only if the C_ContactID has changed 
-- (the only thing that can change.)

truncate table Consolidated_Staging.db.ContactIgnoreBeyondContactMatching

insert into Consolidated_Staging.db.ContactIgnoreBeyondContactMatching (SourceContactID, MarketCode, Source, C_ContactID)
select SourceContactID, MarketCode, Source, C_ContactID from Consolidated_Staging.db.Contact
where c_contactid <> C_PreviousContactID

-- then delete them.

 delete from Consolidated_Staging.db.Contact where IgnoreBeyondContactMatching = 1

 -- is the new ContactEmailID different from the old ContactEmailID and has it been updated more recents? If so, update its Membership
-- records to the new ContactEmailID

UPDATE Consolidated.DB.Membership
SET ContactEmailID = c.C_ContactEmailID,
LastUpdateDate = GETDATE(),
EmailLastUpdateDate = GETDATE()
FROM db.Contact c
INNER JOIN Consolidated.DB.Membership m
ON C_PreviousContactEmailID = m.ContactEmailID
WHERE c.C_ContactEmailID <> c.C_PreviousContactEmailID
AND M.SourceID = c.SourceID

-- duplidates will be deleted by up_ConsolidatedMembership


/* for each source Contact record with an email, find the values required by the SourceEmail record
 this and C_SourceEmailID (unless there are more than one existing SourceContact records already, in which all should be.)
 */

 -- at this point remove all records that are IgnoreBeyondContactMatching



TRUNCATE TABLE db.SourceEmail

INSERT INTO Consolidated_Staging.DB.SourceEmail
           (SourceID
           ,ContactEmailID
           ,MarketID
           ,HardBounceCount
           ,SoftBounceCount
           ,IsValid
           ,SourceCreateDate
           ,SourceLastUpdateDate
           ,SourceEmailID
           ,S_ContactID
           ,GreatestDate
           ,Status
           ,ThirdParty )
SELECT SourceID
	,ContactEmailID
	,CASE WHEN ParentMarketID IS NULL THEN MarketID ELSE ParentMarketID END MarketID
	,HardBounceCount
	,SoftBounceCount
	,CASE WHEN SourceID not in (1,56) THEN NULL ELSE ValidEmailAddress END
	,cr.CreateDate
	,cr.LastUpdateDate
	,cr.C_SourceEmailID
	,cr.ContactID S_ContactID
	,GreatestDate
	,cr.Status
	,cr.ThirdParty
FROM db.Contact cr
LEFT JOIN Consolidated.db.ContactEmail ce
ON cr.EmailAddress = ce.EmailAddress
WHERE cr.EmailAddress IS NOT NULL OR C_SourceEmailID IS NOT NULL

-- if the ContactEmailID is null then that means the source record no longer has an email

DELETE Consolidated.db.SourceEmail
FROM db.SourceEmail s
INNER JOIN Consolidated.db.SourceEmail se
ON s.SourceEmailID = se.SourceEmailID
WHERE db.higherdate(s.SourceCreateDate, s.SourceLastUpdatedate) > 
db.higherdate(se.SourceCreateDate, se.SourceLastUpdateDate)
AND s.ContactEmailID IS NULL

-- if the source Contact record has created a SourceEmail record before then update this record but only if 
-- any of the values are different (except SourceLastUpdateDate) and the record has been updated more recently in the source system
-- any records that have been updated get the ContactID of the contact record that updated it

UPDATE Consolidated.db.SourceEmail
SET SourceID = se.SourceID, 
ContactEmailID = se.ContactEmailID, 
MarketID = se.MarketID,
HardBounceCount = se.HardBounceCount, 
SoftBounceCount = se.SoftBounceCount, 
IsValid = se.IsValid,
SourceCreateDate = se.SourceCreateDate, 
SourceLastUpDateDate = se.SourceLastUpdateDate,
LastUpdateDate = GETDATE(), 
S_ContactID = se.S_ContactID,
Status = se.Status,
ThirdPartyID = Tp.ThirdPartyID  
FROM Consolidated.db.SourceEmail cse
INNER JOIN db.SourceEmail se
ON cse.SourceEmailID = se.SourceEmailID
Left Join Consolidated.db.ThirdParty Tp On se.ThirdParty = Tp.Name  
WHERE (cse.SourceID <> se.SourceID
or cse.ContactEmailID <> se.ContactEmailID
or cse.MarketID <> se.MarketID
or ISNULL(cse.HardBounceCount,'') <> ISNULL(se.HardBounceCount,'')
or ISNULL(cse.SoftBounceCount,'') <> ISNULL(se.SoftBounceCount,'')
or ISNULL(cse.IsValid,'') <> ISNULL(se.IsValid,'')
or ISNULL(cse.SourceCreateDate,'') <> ISNULL(se.SourceCreateDate,'')
or ISNULL(cse.ThirdPartyID,'') <> ISNULL(Tp.ThirdPartyID,''))
AND GreatestDate >= isnull( cse.SourceLastUpdateDate,cse.SourceCreateDate)
AND se.ContactEmailID IS NOT NULL

-- delete any duplicates that this update has created

IF OBJECT_ID('tempdb..#SourceEmailDelete') IS NOT NULL 
	DROP TABLE #SourceEmailDelete

SELECT x.SourceEmailID
INTO #SourceEmailDelete
FROM 
	(SELECT c.SourceEmailID, ROW_NUMBER() over(partition by se.ContactEmailID, se.MarketID, se.SourceID
	ORDER BY isnull(c.SourceLastUpdateDate, c.SourceCreateDate) desc) rowno
	FROM (SELECT DISTINCT contactemailid, marketid, sourceid from db.SourceEmail) se
	INNER JOIN Consolidated.DB.SourceEmail c
	ON SE.ContactEmailID = c.ContactEmailID
	AND SE.MarketID = C.MarketID
	AND se.SourceID = c.SourceID) x
WHERE ROWNO <> 1

DELETE Consolidated.DB.SourceEmail 
FROM Consolidated.DB.SourceEmail se
INNER JOIN #SourceEmailDelete sed
ON se.SourceEmailID = sed.SourceEmailID

		
-- consolidate the SourceEmail records

TRUNCATE TABLE db.SourceEmailConsolidated

INSERT INTO db.SourceEmailConsolidated (SourceID
	,ContactEmailID
	,MarketID
	,HardBounceCount
	,SoftBounceCount
	,IsValid
	,SourceCreateDate
	,SourceLastUpdateDate
	,S_ContactID
	,GreatestDate
	,Status
	,ThirdParty )
SELECT se.SourceID
	,se.ContactEmailID
	,se.MarketID
	,se.HardBounceCount
	,se.SoftBounceCount
	,se.IsValid
	,se.SourceCreateDate
	,se.SourceLastUpdateDate
	,S_ContactID
	,GreatestDate
	,Status
	,se.ThirdParty
FROM db.SourceEmail se
INNER JOIN
	(SELECT MAX(S_ContactID) MaxS_ContactID
	FROM db.SourceEmail se
	INNER JOIN
		(SELECT SourceID, MarketID, ContactEmailID, MAX(GreatestDate) MaxGreatestDate
		FROM db.SourceEmail
		WHERE SourceEmailID IS NULL
		GROUP BY SourceID, MarketID, ContactEmailID) sem
	ON se.SourceID = sem.SourceID
	AND se.MarketID = sem.MarketID
	AND se.ContactEmailID = sem.ContactEmailID
	AND se.GreatestDate = sem.MaxGreatestDate
	WHERE SourceEmailID IS NULL
	GROUP BY se.SourceID, se.MarketID, se.ContactEmailID) sem
ON se.S_ContactID = sem.MaxS_ContactID

-- if the ContactEmailID/SourceID/MarketID already exists, then update this record, but only if any field has changed except update date

UPDATE Consolidated.db.SourceEmail
SET HardBounceCount = sec.HardBounceCount,
SoftBounceCount = sec.SoftBounceCount,
IsValid = sec.IsValid,
SourceCreateDate = sec.SourceCreateDate,
SourceLastUpdateDate = sec.SourceLastUpdateDate,
LastUpdateDate = GETDATE(),
S_ContactID = sec.S_ContactID,
Status = sec.Status
FROM Consolidated.db.SourceEmail se
INNER JOIN db.SourceEmailConsolidated sec
ON se.ContactEmailID = sec.ContactEmailID
AND se.MarketID = sec.MarketID
AND se.SourceID = sec.SourceID
Left Join Consolidated.db.ThirdParty Tp on sec.ThirdParty = tp.Name
WHERE sec.GreatestDate > ISNULL(se.SourceLastUpdatedate, se.SourceCreateDate) 
AND (ISNULL(sec.HardBounceCount,'') <> ISNULL(se.HardBounceCount,'')
OR ISNULL(sec.SoftBounceCount,'') <> ISNULL(se.SoftBounceCount,'')
OR ISNULL(sec.IsValid,'') <> ISNULL(se.IsValid,'') )


-- Update ThirdPartyID

UPDATE Consolidated.db.SourceEmail
SET ThirdPartyID = Tp.ThirdPartyID
FROM Consolidated.db.SourceEmail se
INNER JOIN db.SourceEmailConsolidated sec
ON se.ContactEmailID = sec.ContactEmailID
AND se.MarketID = sec.MarketID
AND se.SourceID = sec.SourceID
Left Join Consolidated.db.ThirdParty Tp on sec.ThirdParty = tp.Name
WHERE ISNULL(se.ThirdPartyID,'') <> ISNULL(Tp.ThirdPartyID,'')

-- insert new records into SourceEmail table

INSERT INTO Consolidated.db.SourceEmail (SourceID
	,ContactEmailID
	,MarketID
	,HardBounceCount
	,SoftBounceCount
	,IsValid
	,SourceCreateDate
	,SourceLastUpdateDate
	,S_ContactID
	,Status
	,ThirdPartyID )
SELECT sec.SourceID
	,sec.ContactEmailID
	,sec.MarketID
	,sec.HardBounceCount
	,sec.SoftBounceCount
	,sec.IsValid
	,sec.SourceCreateDate
	,sec.SourceLastUpdateDate
	,sec.S_ContactID
	,sec.Status
	,Tp.ThirdPartyID
FROM db.SourceEmailConsolidated sec
LEFT JOIN Consolidated.db.SourceEmail se
ON se.ContactEmailID = sec.ContactEmailID
AND se.MarketID = sec.MarketID
AND se.SourceID = sec.SourceID
Left Join Consolidated.db.ThirdParty Tp on sec.ThirdParty = tp.Name
WHERE se.SourceEmailID IS NULL


-- remove the C_SourceEmailID values from the Contact table. They will get repopulated in a bit from the SourceEmail table

UPDATE db.Contact
SET C_SourceEmailID = NULL
WHERE C_SourceEmailID IS NOT NULL

-- get the SourceEmailID just created and update the Source contact record that created it

UPDATE db.Contact
SET C_SourceEmailID = s.SourceEmailID
FROM db.Contact c
INNER JOIN Consolidated.db.SourceEmail s
ON c.ContactID = s.S_ContactID

-- remove the S_ContactIDs, they have served their purpose

UPDATE Consolidated.db.SourceEmail
SET S_ContactID = NULL
WHERE S_ContactID IS NOT NULL

-- remove the ConsolidationID from the Contact record, it has served its purpose

UPDATE Consolidated.db.Contact SET ConsolidationID = NULL WHERE ConsolidationID IS NOT NULL

-- load suppressions

INSERT INTO Consolidated.DB.SuppressEmail (Status
	,SuppressEmail
	,CreateDate
	,UserName
	,SuppressReasonID)
SELECT Status
	,EmailAddress
	,CreateDate
	,Source
	,SuppressReasonID
FROM
	(SELECT 'y' Status
		,S.EmailAddress
		,GETDATE() CreateDate
		,s.Source
		,sr.SuppressReasonID
		,ROW_NUMBER() OVER(PARTITION BY s.EmailAddress ORDER BY sr.SuppressReasonID desc) RowNo
	FROM ETL_Staging.ETL.Suppression s
	LEFT JOIN Consolidated.DB.SuppressEmail se
	ON S.EmailAddress = SE.SuppressEmail
	LEFT JOIN Consolidated.DB.SuppressReason sr
	ON sr.SuppressReason = s.SuppressReason
	WHERE se.SuppressEmail IS NULL) x
WHERE RowNo = 1

UPDATE Consolidated.DB.SuppressEmail 
SET Status = 'y'
,UserName = s.Source
,SuppressReasonID = sr.SuppressReasonID
FROM ETL_Staging.ETL.Suppression s
INNER JOIN Consolidated.DB.SuppressEmail se
ON S.EmailAddress = SE.SuppressEmail
LEFT JOIN Consolidated.DB.SuppressReason sr
	ON sr.SuppressReason = s.SuppressReason
WHERE se.Status <> 'Y'




GO


ALTER PROCEDURE [DB].[up_ConsolidateContacts]


AS

-- Load JobTitle into the Demographic etl_staging table

INSERT INTO ETL_Staging.ETL.Demographic (Source, MarketCode, SourceContactID, DemographicCode,
DemographicValue, CreateDate, LastUPDATEDate)
SELECT Source, MarketCode, SourceContactID, 'JOBTITLE' DemographicCode, JobTitle, CreateDate, LastUPDATEDate 
FROM ETL_Staging.ETL.Contact WHERE JobTitle IS NOT NULL


IF OBJECT_ID('tempdb..#es') IS NOT NULL DROP TABLE #es

select EmailAddress
into #es
from ETL_Staging.etl.Contact
where EmailAddress is not null
group by EmailAddress

IF OBJECT_ID('tempdb..#d') IS NOT NULL DROP TABLE #d

select distinct cc.ConsolidationGroupID
into #d
from #es c
inner join base.db.ContactConsolidatedIDs cc
on c.EmailAddress = cc.EmailAddress
where cc.ConsolidationGroupID is not null

--select c.source
--	,c.SourceContactID
--	,c.MarketCode
--	,c.EmailAddress
--	,c.FirstName
--	,c.LastName
--	,c.ContactAddress1
--	,c.ContactPostCode
--	,c.Telephone
--	,c.CreateDate
--	,c.LastUpdateDate
--into 
--from base.db.ContactConsolidatedIDs c
--left join ETL_Staging.etl.contact cc
--on c.Source = cc.Source
--and c.MarketCode = cc.MarketCode
--and c.SourceContactID = cc.SourceContactID
--inner join #d d
--on d.ConsolidationGroupID = c.ConsolidationGroupID









-- dedupe on SourceContactID, Source and Market



IF OBJECT_ID('tempdb..#ContactDupes') IS NOT NULL 
	DROP TABLE #ContactDupes
	
SELECT *, 0 IgnoreBeyondContactMatching,
ROW_NUMBER() OVER 
(PARTITION BY Source, SourceContactID, MarketCode
        ORDER BY Consolidated_staging.db.HigherDate(CreateDate,LastUPDATEDate) desc) RowNo
	INTO #ContactDupes
FROM ETL_Staging.ETL.Contact  

insert into #ContactDupes
(source
	,SourceContactID
	,MarketCode
	,EmailAddress
	,FirstName
	,LastName
	,ContactAddress1
	,ContactPostCode
	,Telephone
	,CreateDate
	,LastUpdateDate
	,IgnoreBeyondContactMatching
	,Rowno)
select c.source
	,c.SourceContactID
	,c.MarketCode
	,c.EmailAddress
	,c.FirstName
	,c.LastName
	,c.ContactAddress1
	,c.ContactPostCode
	,c.Telephone
	,c.CreateDate
	,c.LastUpdateDate
	,1 IgnoreBeyondContactMatching
	,1 Rowno
from base.db.ContactConsolidatedIDs c
left join ETL_Staging.etl.contact cc
on c.Source = cc.Source
and c.MarketCode = cc.MarketCode
and c.SourceContactID = cc.SourceContactID
inner join #d d
on d.ConsolidationGroupID = c.ConsolidationGroupID
where cc.Source is null


-- clean the name up

-- find firstname/last name combinations that don't already exist

IF OBJECT_ID('tempdb..#DistinctNamesETLStaging') IS NOT NULL 
	DROP TABLE #DistinctNamesETLStaging

select distinct FirstName, LastName 
into #DistinctNamesETLStaging 
from #ContactDupes

IF OBJECT_ID('tempdb..#DistinctNamesConsolidated') IS NOT NULL 
	DROP TABLE #DistinctNamesConsolidated

select distinct OriginalFirstName, OriginalSurName 
into #DistinctNamesConsolidated 
from Consolidated.db.Contact


IF OBJECT_ID('tempdb..#CleanedName') IS NOT NULL 
	DROP TABLE #CleanedName

SELECT c.FirstName, c.LastName 
INTO #CleanedName
FROM #DistinctNamesETLStaging c 
LEFT JOIN #DistinctNamesConsolidated cc 
ON isnull(c.FirstName,'') = isnull(cc.OriginalFirstName,'') 
AND isnull(c.LastName,'') = isnull(cc.OriginalSurName,'')
WHERE cc.OriginalFirstName is null

ALTER TABLE #CleanedName add 
CleanedFirstName nvarchar(255),
CleanedSurname nvarchar(255)



exec Consolidated_Staging.db.up_CleanName '#CleanedName','FirstName','CleanedFirstName','LastName','CleanedSurname'

IF OBJECT_ID('tempdb..#DistinctNamesConsolidated') IS NOT NULL 
	DROP TABLE #DistinctNamesConsolidated


/*load Contact file to Contact. Also lookup the SourceID and MarketID. If the record has
no CreateDate or LastDate then use a dummy date
Shuffle AddressLines along in cases where AddressLine1 is null and AddressLine2 is not null */

-- union 

IF OBJECT_ID('tempdb..#Contact') IS NOT NULL 
	DROP TABLE #Contact

select ContactID
,Source
,MarketCode
,SourceContactID
,EmailAddress
,CompanyName
,REPLACE(REPLACE(ContactAddress1,CHAR(10),''),CHAR(13),'') ContactAddress1
,REPLACE(REPLACE(ContactAddress2,CHAR(10),''),CHAR(13),'') ContactAddress2
,REPLACE(REPLACE(ContactAddress3,CHAR(10),''),CHAR(13),'') ContactAddress3
,REPLACE(REPLACE(ContactAddress4,CHAR(10),''),CHAR(13),'') ContactAddress4
,REPLACE(REPLACE(ContactTown,CHAR(10),''),CHAR(13),'') ContactTown
,REPLACE(REPLACE(ContactCounty,CHAR(10),''),CHAR(13),'') ContactCounty
,REPLACE(REPLACE(ContactPostCode,CHAR(10),''),CHAR(13),'') ContactPostCode
,REPLACE(REPLACE(ContactCountryCode,CHAR(10),''),CHAR(13),'') ContactCountryCode
,REPLACE(REPLACE(ContactCountryName,CHAR(10),''),CHAR(13),'') ContactCountryName
,Salutation
,FirstName
,LastName
,Telephone
,JobTitle
,Password
,ValidEmailAddress
,HTMLCapable
,SoftBounceCount
,HardBounceCount
,LastBounced
,MobileNumber
,UserName
,GroupName
,Title
,Status
,AddressType
,Fax
,SMSMobile
,Department
,ViperGUID
,BaseDetail
,CreateDate
,LastUpdateDate
,ContactType
,LeadSourceMostRecent
,OriginalLeadSource
,ConvertedDate
,ConvertedSourceContactID
,SourceOpportunityID
,CreatedBySourceOwnerID
,ReasonForLoss
,OrigSourceAccountID
,OrigSourceOwnerID
,ContactRole
,Consolidated_ContactID
,ThirdParty
,LastLogin
,KeyDecisionMaker
,IgnoreBeyondContactMatching
into #Contact 
from #ContactDupes 
WHERE RowNo = 1 
AND (ContactAddress1 IS NOT NULL 
OR ContactAddress2 IS NULL) 
union
select ContactID
,Source
,MarketCode
,SourceContactID
,EmailAddress
,CompanyName
,REPLACE(REPLACE(ContactAddress2,CHAR(10),''),CHAR(13),'')
,REPLACE(REPLACE(ContactAddress3,CHAR(10),''),CHAR(13),'')
,REPLACE(REPLACE(ContactAddress4,CHAR(10),''),CHAR(13),'')
,null
,REPLACE(REPLACE(ContactTown,CHAR(10),''),CHAR(13),'')
,REPLACE(REPLACE(ContactCounty,CHAR(10),''),CHAR(13),'')
,REPLACE(REPLACE(ContactPostCode,CHAR(10),''),CHAR(13),'')
,REPLACE(REPLACE(ContactCountryCode,CHAR(10),''),CHAR(13),'')
,REPLACE(REPLACE(ContactCountryName,CHAR(10),''),CHAR(13),'')
,Salutation
,FirstName
,LastName
,Telephone
,JobTitle
,Password
,ValidEmailAddress
,HTMLCapable
,SoftBounceCount
,HardBounceCount
,LastBounced
,MobileNumber
,UserName
,GroupName
,Title
,Status
,AddressType
,Fax
,SMSMobile
,Department
,ViperGUID
,BaseDetail
,CreateDate
,LastUpdateDate
,ContactType
,LeadSourceMostRecent
,OriginalLeadSource
,ConvertedDate
,ConvertedSourceContactID
,SourceOpportunityID
,CreatedBySourceOwnerID
,ReasonForLoss
,OrigSourceAccountID
,OrigSourceOwnerID 
,ContactRole
,Consolidated_ContactID
,ThirdParty
,LastLogin
,KeyDecisionMaker
,IgnoreBeyondContactMatching
from #ContactDupes 
WHERE RowNo = 1 
AND ContactAddress1 IS NULL 
AND ContactAddress2 IS NOT NULL
-- join

IF OBJECT_ID('tempdb..#CleanName') IS NOT NULL 
	DROP TABLE #CleanName

SELECT FirstName, LastName, MAX(CleanedFirstName) CleanedFirstName, MAX(CleanedSurname) CleanedSurname
into #CleanName
        FROM	
                (SELECT isnull(FirstName,'?%�5tt?Ee')FirstName, isnull(LastName,'?%�5tt?Ee')LastName, CleanedFirstName, CleanedSurname
		   FROM #CleanedName
		   --where CleanedSurname = 'Hinchley'
		   UNION
		   SELECT isnull(OriginalFirstName,'?%�5tt?Ee'), isnull(OriginalSurName,'?%�5tt?Ee') , Firstname, Surname
		   FROM Consolidated.db.Contact
		   --where surname = 'Hinchley'
		   ) X
	       GROUP BY firstName, LastName

		
---- combined #CleanedName and Consolidated.db.contact

--IF OBJECT_ID('tempdb..#CleanedName2') IS NOT NULL 
--	DROP TABLE #CleanedName2

--select firstname, lastname, max(cleanedfirstname) cleanedfirstname, max(cleanedsurname) cleanedsurname
--into #CleanedName2
--from
--(select firstname, lastname, cleanedfirstname, cleanedsurname
--from #CleanedName
--union
--select OriginalFirstname, OriginalSurname,Firstname, Surname
--from Consolidated.db.Contact) x
--group by firstname, lastname


IF OBJECT_ID('tempdb..#Contact2') IS NOT NULL 
	DROP TABLE #Contact2

select distinct ContactID
        ,c.Source
        ,SourceID
        ,c.MarketCode
        ,MarketID
        ,SourceContactID
        ,EmailAddress
        ,CompanyName
     	,ContactAddress1
        ,ContactAddress2
        ,ContactAddress3
        ,ContactAddress4
        ,ContactTown
        ,ContactCounty
        ,ContactPostCode
	,ContactCountryCode
        ,ContactCountryName
        ,Salutation
        ,CleanedFirstName
        ,CleanedSurname
        ,Telephone
        ,JobTitle	
	,CASE WHEN CreateDate IS NULL AND LastUPDATEDate IS NULL THEN '19500101' ELSE CreateDate END CreateDate
	,LastUPDATEDate
        ,Password
        ,ValidEmailAddress
        ,HTMLCapable
        ,SoftBounceCount
        ,HardBounceCount
        ,LastBounced
	,MobileNumber
        ,GroupName
        ,UserName
        ,Title
        ,CreateDate CreateDateForHigherDate
        ,LastUpdateDate LastUpdateDateForHigherDate
        ,AddressType
        ,SMSMobile, Fax, Department
        ,CASE WHEN v.ValueToIgnore1 IS NOT NULL OR v2.ValueToIgnore1 IS NOT NULL THEN 1 END DoNotUseEmail
	,vNameFirstOnly.ValueToIgnore1 ValueToIgnore1NameFirstOnly
	,CASE WHEN vTelephone.ValueToIgnore1 IS NOT NULL THEN 1 END DoNotUseTelephone
	,CASE WHEN vMobile.ValueToIgnore1 IS NOT NULL THEN 1 END DoNotUseMobile
	,CASE WHEN vSMSMobile.ValueToIgnore1 IS NOT NULL THEN 1 END DoNotUseSMSMobile
	,CASE WHEN vAddress.ValueToIgnore1 IS NOT NULL THEN 1 END DoNotUseAddress
	,c.Status
        ,ViperGUID
        ,ParentMarketID
        ,BaseDetail
        ,ContactType
    ,LeadSourceMostRecent
    ,OriginalLeadSource
    ,ConvertedDate
    ,ConvertedSourceContactID
    ,SourceOpportunityID
    ,CreatedBySourceOwnerID
    ,ReasonForLoss
    ,OrigSourceAccountID
         ,c.FirstName
         ,c.LastName
         ,OrigSourceOwnerID
		 ,ContactRole
		 ,Consolidated_ContactID
		 ,ThirdParty
		 ,LastLogin
		 ,KeyDecisionMaker
		 ,IgnoreBeyondContactMatching
into #Contact2
from #Contact c
INNER JOIN Consolidated.db.Market m 
ON c.Marketcode = m.MarketCode
INNER JOIN Consolidated.db.Source s 
ON c.Source = s.SourceCode
LEFT JOIN DB.ValuesToIgnoreInConsolidation v 
ON v.ValueToIgnore1 = c.EmailAddress 
AND v.TypeOfValue = 'e'
LEFT JOIN DB.ValuesToIgnoreInConsolidation v2 
ON v2.ValueToIgnore1 = case when charindex('@',c.EmailAddress) > 1 then substring(c.EmailAddress,1,charindex('@',c.EmailAddress)-1) end 
AND v2.TypeOfValue = 'r'
LEFT JOIN (SELECT DISTINCT ValueToIgnore1 FROM db.ValuesToIgnoreInConsolidation WHERE TypeOfValue = 'n') vNameFirstOnly 
ON c.FirstName = vNameFirstOnly.ValueToIgnore1
LEFT JOIN DB.ValuesToIgnoreInConsolidation vTelephone 
ON vTelephone.ValueToIgnore1 = c.Telephone 
AND vTelephone.TypeOfValue = 't'
LEFT JOIN DB.ValuesToIgnoreInConsolidation vMobile 
ON vMobile.ValueToIgnore1 = c.MobileNumber 
AND vMobile.TypeOfValue = 't'
LEFT JOIN DB.ValuesToIgnoreInConsolidation vSMSMobile 
ON vSMSMobile.ValueToIgnore1 = c.SMSMobile 
AND vSMSMobile.TypeOfValue = 't'
LEFT JOIN DB.ValuesToIgnoreInConsolidation vAddress 
ON vAddress.ValueToIgnore1 = c.ContactAddress1 
AND vAddress.ValueToIgnore2 = c.ContactPostCode 
AND vAddress.TypeOfValue = 'a'
LEFT JOIN 
        #CleanName cleanname 
ON cleanname.FirstName = isnull(c.FirstName,'?%�5tt?Ee') 
AND cleanname.LastName = isnull(c.LastName,'?%�5tt?Ee')


IF OBJECT_ID('tempdb..#Contact') IS NOT NULL 
	DROP TABLE #Contact

-- apply functions

TRUNCATE TABLE DB.Contact


INSERT INTO DB.Contact (Source
,SourceID
,MarketCode
,MarketID
,SourceContactID
,EmailAddress
,CompanyName
,ContactAddress1
,ContactAddress2
,ContactAddress3
,ContactAddress4
,ContactTown
,ContactCounty
,ContactPostCode
,ContactCountryCode
,ContactCountryName
,Salutation
,FirstName
,LastName
,Telephone
,JobTitle
,CreateDate
,LastUpdateDate
,Password
,ValidEmailAddress
,HTMLCapable
,SoftBounceCount
,HardBounceCount
,LastBounced
,MobileNumber
,GroupName
,UserName
,Title
,GreatestDate
,AddressType
,SMSMobile
,Fax
,Department
,AddressQuality
,TelephoneQuality
,MobileQuality
,SMSQuality
,IsValidEmail
,DoNotUseEmail
,DoNotUseName
,DoNotUseTelephone
,DoNotUseMobile
,DoNotUseSMSMobile
,DoNotUseAddress
,Status
,ViperGUID
,ParentMarketID
,BaseDetail
,[SourceTable]
,[LeadSourceMostRecent]
,[OriginalLeadSource]
,[ConvertedDate]
,[ConvertedSourceContactID]
,[SourceOpportunityID]
,[CreatedBySourceOwnerID]
,[ReasonForLoss]
,[AccountID]
,OriginalFirstName
,OriginalSurname
,SourceOwnerID
,ContactRole
,Consolidated_ContactID
,ThirdParty
,LastLogin
,KeyDecisionMaker
,IgnoreBeyondContactMatching
)
select Source
,SourceID
,MarketCode
,MarketID
,SourceContactID
,EmailAddress
,CompanyName
,ContactAddress1
,ContactAddress2
,ContactAddress3
,ContactAddress4
,ContactTown
,ContactCounty
,ContactPostCode
,ContactCountryCode
,ContactCountryName
,left(Salutation,10)
,CleanedFirstName
,CleanedSurname
,Telephone
,JobTitle
,CreateDate
,LastUPDATEDate
,Password
,ValidEmailAddress
,HTMLCapable
,SoftBounceCount
,HardBounceCount
,LastBounced
,MobileNumber
,GroupName
,UserName
,Title
,ISNULL(db.higherdate(CreateDateForHigherDate,LastUpdateDateForHigherDate),'19500101')
,AddressType
,SMSMobile, Fax, Department
,null
,db.fn_GetTelephoneQualityScore(Telephone) TelephoneQuality
,db.fn_GetTelephoneQualityScore(MobileNumber) MobileQuality
,db.fn_GetTelephoneQualityScore(SMSMobile) SMSQuality
,Presentation_Staging.DB.fn_EmailValidation(EmailAddress
        	,ISNULL(ISNULL(LastUpdateDate,CreateDate),GETDATE())) IsValidEmail
                , DoNotUseEmail
                ,CASE 
                        WHEN ValueToIgnore1NameFirstOnly IS NOT NULL OR
                        (FirstName IS NULL AND LastName IS NULL) OR 
                        LEN(FirstName) <> LEN( db.fn_RemoveNonAlpha(FirstName)) OR
                        LEN(REPLACE(FirstName,'.','')) < 2 OR
                        LEN(REPLACE(LastName,'.','')) < 2
                        THEN 1 END DoNotUseName
           , DoNotUseTelephone
           , DoNotUseMobile
           , DoNotUseSMSMobile
           , DoNotUseAddress
           ,Status
           ,ViperGUID
           ,ParentMarketID
           ,BaseDetail
           ,ContactType
           ,LeadSourceMostRecent
           ,OriginalLeadSource
           ,ConvertedDate
           ,ConvertedSourceContactID
           ,SourceOpportunityID
           ,CreatedBySourceOwnerID
           ,ReasonForLoss
           ,OrigSourceAccountID
           ,FirstName
           ,LastName
           ,OrigSourceOwnerID
		   ,ContactRole
		   ,Consolidated_ContactID
		   ,ThirdParty
		   ,LastLogin
		   ,KeyDecisionMaker
		   ,IgnoreBeyondContactMatching
from #Contact2

IF OBJECT_ID('tempdb..#Contact2') IS NOT NULL 
	DROP TABLE #Contact2

--ALTER INDEX x_contact_lastname_telephone ON DB.Contact REBUILD

Exec DB.up_EmailOwner 'Consolidated_Staging.DB.Contact','EmailAddress','FirstName','LastName','EmailOwner'

UPDATE Consolidated_Staging.DB.Contact SET MasterScore = CASE WHEN ISNULL(EmailOwner,0) > 0 THEN ISNULL(EmailOwner,0)+30 ELSE ISNULL(EmailOwner,0) END+
														 CASE WHEN len(ISNULL(OriginalFirstName,'')) > 1 THEN 3 ELSE 0 END+
														 CASE WHEN len(ISNULL(OriginalSurName,'')) > 1 THEN  3 ELSE 0 END+
														 CASE WHEN len(ISNULL(ContactAddress1,'')) > 0 and len(ISNULL(ContactPostCode,'')) > 0 THEN 1 ELSE 0  END+
														 CASE WHEN TelephoneQuality = 1 THEN 1 ELSE 0 END 
														 FROM Consolidated_Staging.DB.Contact 


-- Load records into channel tables -----------------

TRUNCATE TABLE DB.Channel_Email

INSERT INTO DB.Channel_Email
SELECT DISTINCT EmailAddress
FROM DB.Contact
WHERE EmailAddress IS NOT NULL
AND DoNotUseEmail IS NULL
AND IsValidEmail = 1

TRUNCATE TABLE DB.Channel_Telephone

INSERT INTO DB.Channel_Telephone (Telephone, LastName, FirstName)
SELECT DISTINCT Telephone, LastName, FirstName
FROM DB.Contact
WHERE Telephone IS NOT NULL
AND DoNotUseTelephone IS NULL
AND TelephoneQuality = 1
AND DoNotUseName IS NULL
UNION
SELECT DISTINCT MobileNumber, LastName, FirstName
FROM DB.Contact
WHERE MobileNumber IS NOT NULL
AND DoNotUseMobile IS NULL
AND DoNotUseName IS NULL
AND MobileQuality = 1
UNION
SELECT DISTINCT SMSMobile, LastName, FirstName
FROM DB.Contact
WHERE SMSMobile IS NOT NULL
AND DoNotUseSMSMobile IS NULL
AND DoNotUseName IS NULL
AND SMSQuality = 1

TRUNCATE TABLE DB.Channel_Address

INSERT INTO DB.Channel_Address (AddressKey,FirstName,LastName)
SELECT DISTINCT ContactAddress1 + '|' + ContactPostCode, FirstName, LastName
FROM DB.Contact
WHERE len(ContactAddress1) >3  AND len(ContactPostCode)>3
AND LastName IS NOT NULL AND FirstName IS NOT NULL
AND DoNotUseName IS NULL
AND DoNotUseAddress IS NULL


-- load records into Channel_Contact tables ----------------------------------

TRUNCATE TABLE DB.Channel_EmailContact

INSERT INTO DB.Channel_EmailContact
SELECT ContactID, EmailID
FROM DB.Contact c
INNER JOIN DB.Channel_Email ce
ON c.EmailAddress = ce.Email

TRUNCATE TABLE DB.Channel_TelephoneContact

INSERT INTO DB.Channel_TelephoneContact
SELECT c.ContactID, t.TelephoneID
FROM DB.Contact c
INNER JOIN DB.Channel_Telephone t
ON c.LastName = t.LastName
AND c.Telephone = t.Telephone
AND c.FirstName = t.FirstName
UNION
SELECT c.ContactID, t.TelephoneID
FROM DB.Contact c
INNER JOIN DB.Channel_Telephone t
ON c.LastName = t.LastName
AND c.MobileNumber = t.Telephone
AND c.FirstName = t.FirstName
UNION
SELECT c.ContactID, t.TelephoneID
FROM DB.Contact c
INNER JOIN DB.Channel_Telephone t
ON c.LastName = t.LastName
AND c.SMSMobile = t.Telephone
AND c.FirstName = t.FirstName

TRUNCATE TABLE DB.Channel_AddressContact

INSERT INTO DB.Channel_AddressContact
SELECT Contactid, Addressid
FROM DB.Contact c
INNER JOIN DB.Channel_Address a
ON ContactAddress1 + '|' + ContactPostCode = addresskey
AND c.FirstName = a.FirstName
AND c.lastname = a.LastName

/* populate Contact_Channel_Consolidation
This will be used to identify which contacts share the same channels 
Exclude BASubs emails because they are 'account' emails ie the same email is used across multiple emails*/

TRUNCATE TABLE DB.Contact_Channel_Consolidation

INSERT INTO DB.Contact_Channel_Consolidation (Contactid, EmailID, TelephoneID, AddressID,SourceContactID)
SELECT c.ContactID, EmailID, TelephoneID, AddressID, Source + SourceContactID
FROM DB.Contact c
LEFT JOIN DB.Channel_EmailContact ce
ON c.ContactID = ce.ContactID
LEFT JOIN DB.Channel_TelephoneContact tc
ON tc.ContactID = c.ContactID
LEFT JOIN DB.Channel_AddressContact ca
ON c.ContactID = ca.ContactID

EXEC db.up_Consolidation


/* As part of the enhanced consolidation work, 
   we won't allow to update ConsolidationIDs with underscores  
*/

----UPDATE DB.Contact_Channel_Consolidation
----SET ConsolidationID = CONVERT(VARCHAR(10),cc.ConsolidationID)+'_'+CONVERT(VARCHAR(10),ps.contactwithinconsolidationID)
----FROM DB.Contact_Channel_Consolidation cc
----inner join db.Contact c
----on cc.ContactID = c.ContactID
----INNER JOIN ETL_Staging.etl.ProspectSoftConsolidation ps
----ON c.SourceContactID = ps.SourceContactID
----and c.source = 'prospectsoft crm'


----update [DB].[Contact_Channel_Consolidation] 
----set ConsolidationID = d.ConsolidationID + '_1'
----from [DB].[Contact_Channel_Consolidation] d
----inner join
----       (select distinct left(consolidationid,CHARINDEX('_',consolidationid)-1) ConsolidationID
----       from [DB].[Contact_Channel_Consolidation]
----       where consolidationid like '%[_]1') x
----on d.ConsolidationID = x.ConsolidationID
----where d.ConsolidationID not like '%[_]%'

-- UPDATE the Contact with the ConsolidationID

UPDATE DB.Contact
SET ConsolidationID = cc.ConsolidationID
FROM DB.Contact c
INNER JOIN DB.Contact_Channel_Consolidation cc
ON c.ContactID = cc.ContactID


--DQ - 31 
update m2 set C_MasterRecord =  m1.ConsolidationID from 
(select ConsolidationID,max(MasterScore) m_score from DB.Contact
group by ConsolidationID) m1,
(select * from (select C_MasterRecord,contactid,MasterScore,ConsolidationID,
                       DENSE_RANK() over (partition by MasterScore,ConsolidationID 
                                          order by MasterScore,coalesce(LastUpdateDate,CreateDate) desc) rec_order   
          from DB.Contact) m3
where rec_order = 1) m2
where m1.ConsolidationID = m2.ConsolidationID and m1.m_score = m2.MasterScore


--DQ - 35


Update C set Gender = G.Gender from Consolidated_Staging.DB.Contact C
Inner Join Consolidated_Staging.DB.Gender G
ON C.Title = G.Name 
Where C.Title is not null and G.MatchedOn = 'Title'
and C.Gender is null  --461260

Update C set Gender = G.Gender from Consolidated_Staging.DB.Contact C
Inner Join Consolidated_Staging.DB.Gender G
ON C.OriginalFirstName = G.Name 
Where C.OriginalFirstName is not null and G.MatchedOn = 'FirstName'
and C.Gender is null --15406065

--Step 1
Update C set Gender = G.Gender from Consolidated_Staging.DB.Contact C
Inner Join Consolidated_Staging.DB.Gender G
ON C.OriginalFirstName = G.Name 
Where C.OriginalFirstName is not null and G.MatchedOn = 'Title'
and C.Gender is null --2016

--Step 2
Update C set Gender = 'M' from Consolidated_Staging.DB.Contact C
where Gender is null and OriginalFirstName like 'Mr[ .]%'

--Step 3
Update C set Gender = 'F' from Consolidated_Staging.DB.Contact C
where Gender is null and OriginalFirstName like 'Mrs[ .]%'

--Step 4
Update C set Gender = G.Gender from Consolidated_Staging.DB.Contact C
Inner Join Consolidated_Staging.DB.Gender G
ON LEFT(FirstName,PATINDEX('% %',C.FirstName)) = G.Name 
Where C.FirstName is not null and C.Gender is null and C.FirstName like '% %' 

--Step 4
Update C set Gender = G.Gender from Consolidated_Staging.DB.Contact C
Inner Join Consolidated_Staging.DB.Gender G
ON LEFT(OriginalFirstName,PATINDEX('% %',C.OriginalFirstName)) = G.Name 
Where C.OriginalFirstName is not null and C.Gender is null and C.OriginalFirstName like '% %' 


--Step 5
Update C set Gender = G.Gender from Consolidated_Staging.DB.Contact C
Inner Join Consolidated_Staging.DB.Gender G
ON SUBSTRING(C.OriginalFirstName,PATINDEX('% %',C.OriginalFirstName)+1,LEN(C.OriginalFirstName)) = G.Name 
Where C.OriginalFirstName is not null and C.Gender is null and C.OriginalFirstName like '% %'
AND LEN(LEFT(OriginalFirstName,PATINDEX('% %',C.OriginalFirstName))) < 3

--Step 6
Update C set Gender = G.Gender from Consolidated_Staging.DB.Contact C
Inner Join Consolidated_Staging.DB.Gender G
ON LEFT(OriginalFirstName,PATINDEX('%.%',C.OriginalFirstName)-1) = G.Name 
Where C.OriginalFirstName is not null and C.Gender is null and C.OriginalFirstName like '%.%' 


--Step 7
Update C set Gender = G.Gender from Consolidated_Staging.DB.Contact C
Inner Join Consolidated_Staging.DB.Gender G
ON SUBSTRING(C.OriginalFirstName,PATINDEX('%.%',C.OriginalFirstName)+1,LEN(C.OriginalFirstName)) = G.Name 
Where C.OriginalFirstName is not null and C.Gender is null and C.OriginalFirstName like '%.%'
AND LEN(LEFT(OriginalFirstName,PATINDEX('%.%',C.OriginalFirstName))) < 3

--Step 8
Update C set Gender = G.Gender from Consolidated_Staging.DB.Contact C
Inner Join Consolidated_Staging.DB.Gender G
ON LEFT(OriginalFirstName,PATINDEX('%-%',C.OriginalFirstName)-1) = G.Name 
Where C.OriginalFirstName is not null and C.Gender is null and C.OriginalFirstName like '%-%' 

--SELECT LEFT('Kim-Soon',PATINDEX('%-%','Kim-Soon')-1) 

--Step 9
Update C set Gender = G.Gender from Consolidated_Staging.DB.Contact C
Inner Join Consolidated_Staging.DB.Gender G
ON SUBSTRING(C.OriginalFirstName,PATINDEX('%-%',C.OriginalFirstName)+1,LEN(C.OriginalFirstName)) = G.Name 
Where C.OriginalFirstName is not null and C.Gender is null and C.OriginalFirstName like '%-%'
AND LEN(LEFT(OriginalFirstName,PATINDEX('%-%',C.OriginalFirstName))) < 3





GO

--++
USE [Consolidated_Staging]
GO

/****** Object:  StoredProcedure [DB].[up_NewContactID]    Script Date: 11/14/2017 15:05:34 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


USE [Consolidated_Staging]
GO
/****** Object:  StoredProcedure [DB].[up_Load]    Script Date: 11/14/2017 15:06:10 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

ALTER PROCEDURE [DB].[up_Load]

AS

SET NOCOUNT ON
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

DECLARE @$prog VARCHAR(50), 
        @$errno INT, 
        @$errmsg VARCHAR(4000), 
        @$proc_section_nm VARCHAR(50),
        @$row_cnt INT,
        @$error_db_name VARCHAR(50)

SELECT @$errno = 0, 
       @$errmsg = NULL, 
       @$proc_section_nm = NULL,
       @$prog = LEFT(OBJECT_NAME(@@PROCID),50), 
       @$row_cnt = NULL,
       @$error_db_name = DB_NAME()

BEGIN TRY


Insert into Consolidated.db.MembershipAttribute (MembershipAttribute)
Select distinct m.MembershipAttribute
from ETL_Staging.ETL.MembershipAttribute m
left join Consolidated.DB.MembershipAttribute p
on m.MembershipAttribute = p.MembershipAttribute
where p.MembershipAttribute is null;
	
INSERT INTO ETL_Staging.ETL.Audit (AuditCategoryID,Action,Type,ActionDate)
VALUES (5,'Success','Load - Begin',getdate())

EXEC ETL_Staging.ETL.AMPS_ETLUpdate

INSERT INTO ETL_Staging.ETL.Audit (AuditCategoryID,Action,Type,ActionDate)
VALUES (5,'Success','Load - AMPS',getdate())

EXEC ETL_Staging.ETL.up_ETLSourceCounts

EXEC ETL_Staging.ETL.up_ContactExceptions
EXEC ETL_Staging.ETL.up_MembershipExceptions
EXEC ETL_Staging.ETL.up_DemographicExceptions
EXEC ETL_Staging.ETL.up_EmailMetricsExceptions
EXEC ETL_Staging.ETL.up_PrivacyDenormalisedExceptions
EXEC ETL_Staging.ETL.up_PrivacyNormalisedExceptions

INSERT INTO ETL_Staging.ETL.Audit (AuditCategoryID,Action,Type,ActionDate)
VALUES (5,'Success','Load - Exceptions',getdate())


EXEC Consolidated.DB.up_InsertOwner

INSERT INTO ETL_Staging.ETL.Audit (AuditCategoryID,Action,Type,ActionDate)
VALUES (5,'Success','Load - SF Objects Owner',getdate())

EXEC Consolidated.DB.up_InsertAddress

INSERT INTO ETL_Staging.ETL.Audit (AuditCategoryID,Action,Type,ActionDate)
VALUES (5,'Success','Load - SF Objects Address',getdate())

EXEC Consolidated.DB.up_InsertAccount

INSERT INTO ETL_Staging.ETL.Audit (AuditCategoryID,Action,Type,ActionDate)
VALUES (5,'Success','Load - SF Objects Account',getdate())

EXEC Consolidated.DB.up_InsertCampaign 

INSERT INTO ETL_Staging.ETL.Audit (AuditCategoryID,Action,Type,ActionDate)
VALUES (5,'Success','Load - SF Objects Campaign',getdate())

EXEC Consolidated_Staging.DB.up_ConsolidatedAccountDemographic

INSERT INTO ETL_Staging.ETL.Audit (AuditCategoryID,Action,Type,ActionDate)
VALUES (5,'Success','Load - SF Objects AccountDemographic',getdate())


EXEC db.up_ConsolidateContacts  

INSERT INTO ETL_Staging.ETL.Audit (AuditCategoryID,Action,Type,ActionDate)
VALUES (5,'Success','Load - Consolidated Contacts',getdate())

EXEC db.up_ConsolidatedGetPreviousID  

INSERT INTO ETL_Staging.ETL.Audit (AuditCategoryID,Action,Type,ActionDate)
VALUES (5,'Success','Load - Consolidated GetPreviousID',getdate())

EXEC [DB].[up_ConsolidationGroupSplit]

INSERT INTO ETL_Staging.ETL.Audit (AuditCategoryID,Action,Type,ActionDate)
VALUES (5,'Success','Load - Consolidation Group Split',getdate())


EXEC db.up_ConsolidatedGetContactID  

INSERT INTO ETL_Staging.ETL.Audit (AuditCategoryID,Action,Type,ActionDate)
VALUES (5,'Success','Load - Consolidated GetContactID',getdate())

EXEC db.up_ConsolidatedCreateContactID

INSERT INTO ETL_Staging.ETL.Audit (AuditCategoryID,Action,Type,ActionDate)
VALUES (5,'Success','Load - Consolidated CreateContactIDs',getdate())

EXEC db.up_CreateUpdateEmail

INSERT INTO ETL_Staging.ETL.Audit (AuditCategoryID,Action,Type,ActionDate)
VALUES (5,'Success','Load - Consolidated Email',getdate())

EXEC Consolidated.DB.up_EmailSourceLastLoginDate

INSERT INTO ETL_Staging.ETL.Audit (AuditCategoryID,Action,Type,ActionDate)
VALUES (5,'Success','Load - EmailSourceLastLoginDate',getdate())

EXEC db.up_ConsolidatedMembership

INSERT INTO ETL_Staging.ETL.Audit (AuditCategoryID,Action,Type,ActionDate)
VALUES (5,'Success','Load - Consolidated Membership',getdate())

EXEC db.up_ConsolidatedDPAEmail

INSERT INTO ETL_Staging.ETL.Audit (AuditCategoryID,Action,Type,ActionDate)
VALUES (5,'Success','Load - Consolidated DPA Email',getdate())

EXEC db.up_ConsolidatedCompany

INSERT INTO ETL_Staging.ETL.Audit (AuditCategoryID,Action,Type,ActionDate)
VALUES (5,'Success','Load - Consolidated Company',getdate())

EXEC db.up_ConsolidatedAddress

INSERT INTO ETL_Staging.ETL.Audit (AuditCategoryID,Action,Type,ActionDate)
VALUES (5,'Success','Load - Consolidated Address',getdate())

EXEC db.up_ConsolidatedDemographic

INSERT INTO ETL_Staging.ETL.Audit (AuditCategoryID,Action,Type,ActionDate)
VALUES (5,'Success','Load - Consolidated Demographic',getdate())

EXEC db.up_ConsolidatedTelephone

INSERT INTO ETL_Staging.ETL.Audit (AuditCategoryID,Action,Type,ActionDate)
VALUES (5,'Success','Load - Consolidated Telephone',getdate())

EXEC DB.up_ConsolidatedDPATelemarketing

INSERT INTO ETL_Staging.ETL.Audit (AuditCategoryID,Action,Type,ActionDate)
VALUES (5,'Success','Load - Consolidated DPA Telemarketing',getdate())

exec db.up_ConsolidatedDPASMS

EXEC Consolidated.DB.up_InsertMembership

INSERT INTO ETL_Staging.ETL.Audit (AuditCategoryID,Action,Type,ActionDate)
VALUES (5,'Success','Load - Consolidated DB Membership',getdate())

Exec Consolidated.DB.up_InsertOpportunity

INSERT INTO ETL_Staging.ETL.Audit (AuditCategoryID,Action,Type,ActionDate)
VALUES (5,'Success','Load - Consolidated DB SourceContact',getdate())


EXEC DB.up_ConsolidatedDPADirectMail

INSERT INTO ETL_Staging.ETL.Audit (AuditCategoryID,Action,Type,ActionDate)
VALUES (5,'Success','Load - Consolidated DPA Direct Mail',getdate())

EXEC  Consolidated.DB.up_InsertSourceOpportunityProductInterest

INSERT INTO ETL_Staging.ETL.Audit (AuditCategoryID,Action,Type,ActionDate)
VALUES (5,'Success','Load - Consolidated SourceOpportunityProductInterest',getdate())

EXEC  Consolidated.DB.[up_InsertQuote]

INSERT INTO ETL_Staging.ETL.Audit (AuditCategoryID,Action,Type,ActionDate)
VALUES (5,'Success','Load - Consolidated InsertQuote',getdate())


EXEC  Consolidated.DB.up_InsertSourceSaleItem

INSERT INTO ETL_Staging.ETL.Audit (AuditCategoryID,Action,Type,ActionDate)
VALUES (5,'Success','Load - Consolidated SourceSaleItem',getdate())

EXEC DB.[up_UpdateDeletedDate]

INSERT INTO ETL_Staging.ETL.Audit (AuditCategoryID,Action,Type,ActionDate)
VALUES (5,'Success','Load - UpdateDeletedDate',getdate())


EXEC db.usp_Insert_Email_Metrics

INSERT INTO ETL_Staging.ETL.Audit (AuditCategoryID,Action,Type,ActionDate)
VALUES (5,'Success','Load - Consolidated Email_Metrics',getdate())

EXEC db.up_Events

INSERT INTO ETL_Staging.ETL.Audit (AuditCategoryID,Action,Type,ActionDate)
VALUES (5,'Success','Load - Consolidated Events',getdate())

EXEC db.up_Base

INSERT INTO ETL_Staging.ETL.Audit (AuditCategoryID,Action,Type,ActionDate)
VALUES (5,'Success','Load - Base',getdate())

EXEC Consolidated.db.up_PopulateKeyDimensionsObjects

INSERT INTO ETL_Staging.ETL.Audit (AuditCategoryID,Action,Type,ActionDate)
VALUES (5,'Success','Load - KeyDimensionsObjects',getdate())


END TRY

BEGIN CATCH

		SET @$errmsg = LEFT('Error ' +
		CASE
			WHEN @$errno > 0 THEN 
				CAST(@$errno as VARCHAR)
			ELSE 
				CAST(ERROR_NUMBER() AS VARCHAR)
		END + ' in proc ' + ISNULL(@$prog,' ') + ' ' + 
		CASE 
			WHEN @$errno > 0 THEN 
				ISNULL(@$errmsg,' ') 
			ELSE 
				ISNULL(@$errmsg,' ') + ISNULL(ERROR_MESSAGE(),'')
		END ,4000)


	RAISERROR (@$errmsg, 16, 1)


	EXEC dbo.ERROR_LOG_2005 @ERROR_LOG_PROGRAM_NM = @$prog,  
							@ERROR_LOG_PROGRAM_SECTION_NM = @$proc_section_nm,
							@ERROR_LOG_ERROR_NO = @$errno,  
							@ERROR_LOG_ERROR_DSC = @$errmsg,
							@ERROR_DB_NAME = @$error_db_name

	IF(ISNULL(@$errno,0) = 0)
	BEGIN
		SET @$errno = ERROR_NUMBER()
	END

END CATCH

SET NOCOUNT OFF

RETURN  @$errno

GO



select * from db.contact